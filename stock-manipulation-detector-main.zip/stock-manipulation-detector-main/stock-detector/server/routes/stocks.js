// server/routes/stocks.js
const express = require("express");
const router = express.Router();
const { getLiveState, getRecentTicks } = require("../services/redisClient");
const { getWatchlist, addToWatchlist } = require("../services/supabaseClient");
const { WATCHLIST } = require("../services/priceIngestion");

// GET /api/stocks — list all watched symbols with live prices
router.get("/", async (req, res) => {
  try {
    const results = await Promise.all(
      WATCHLIST.map(async (symbol) => {
        const state = await getLiveState(symbol);
        return { symbol, ...state };
      })
    );
    res.json(results);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/stocks/:symbol — live price for one symbol
router.get("/:symbol", async (req, res) => {
  try {
    const state = await getLiveState(req.params.symbol.toUpperCase());
    if (!state || !state.price) {
      return res.status(404).json({ error: "Symbol not found or no data yet" });
    }
    res.json({ symbol: req.params.symbol.toUpperCase(), ...state });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/stocks/:symbol/history — recent ticks from Redis (for chart)
router.get("/:symbol/history", async (req, res) => {
  try {
    const count = parseInt(req.query.count || "100");
    const ticks = await getRecentTicks(req.params.symbol.toUpperCase(), count);
    res.json(ticks);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/stocks/watchlist
router.get("/watchlist/all", async (req, res) => {
  try {
    const list = await getWatchlist();
    res.json(list);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
