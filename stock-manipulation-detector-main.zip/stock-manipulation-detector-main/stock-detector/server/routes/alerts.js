// server/routes/alerts.js
const express = require("express");
const router = express.Router();
const { getAlerts } = require("../services/supabaseClient");

// GET /api/alerts — fetch recent alerts
// Query params: symbol, limit, since (ISO date string)
router.get("/", async (req, res) => {
  try {
    const { symbol, limit = "50", since } = req.query;
    const alerts = await getAlerts({
      symbol,
      limit: parseInt(limit),
      since,
    });
    res.json(alerts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
