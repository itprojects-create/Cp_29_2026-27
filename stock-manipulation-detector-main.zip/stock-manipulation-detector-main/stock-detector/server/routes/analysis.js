// server/routes/analysis.js
const express = require("express");
const router = express.Router();
const { callLangchainAnalysis } = require("../services/mlBridge");
const { updateAlertWithAnalysis } = require("../services/supabaseClient");
const logger = require("../services/logger");

/**
 * POST /api/analyze
 * Body: { alertId, symbol, alert_type, price, volume, ensemble_score, features }
 *
 * Triggers LangChain agent deep analysis.
 * Called by analyst clicking "AI Analyze" on dashboard.
 * NOT called automatically — this is on-demand only.
 */
router.post("/", async (req, res) => {
  const { alertId, symbol, alert_type, price, volume, ensemble_score } = req.body;

  if (!symbol || !alert_type) {
    return res.status(400).json({ error: "symbol and alert_type required" });
  }

  logger.info(`LangChain analysis requested: ${symbol} ${alert_type}`);

  try {
    const result = await callLangchainAnalysis({
      symbol,
      alert_type,
      price,
      volume,
      ensemble_score,
      context: `${symbol} flagged for ${alert_type}. Price: ${price}, Volume: ${volume}, Score: ${ensemble_score}`,
    });

    if (alertId && result?.analysis) {
      await updateAlertWithAnalysis(alertId, result.analysis);
    }

    res.json(result);
  } catch (err) {
    logger.error("Analysis endpoint error:", err.message);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
