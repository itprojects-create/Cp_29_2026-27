// server/index.js
// Entry point for the Node.js backend.
// Wires together: Express, Socket.IO, Redis, Supabase, ML bridge, ingestion.

require("dotenv").config({ path: "../.env" });
const express = require("express");
const { createServer } = require("http");
const { Server } = require("socket.io");
const cors = require("cors");

const logger = require("./services/logger");
const { redisSub } = require("./services/redisClient");
const { startIngestion, processTick } = require("./services/priceIngestion");
const { getMLHealth } = require("./services/mlBridge");
const { initSocketHandler } = require("./socket/socketHandler");
const alertsRouter = require("./routes/alerts");
const stocksRouter = require("./routes/stocks");
const analysisRouter = require("./routes/analysis");

const app = express();
const httpServer = createServer(app);

// ── Socket.IO setup ───────────────────────────────────────────────────────
const io = new Server(httpServer, {
  cors: {
    origin: process.env.CLIENT_URL || "http://localhost:5173",
    methods: ["GET", "POST"],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
});

// ── Middleware ────────────────────────────────────────────────────────────
app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5173" }));
app.use(express.json());

// Request logging in dev
if (process.env.NODE_ENV !== "production") {
  app.use((req, res, next) => {
    if (!req.path.includes("/internal/")) {
      logger.debug(`${req.method} ${req.path}`);
    }
    next();
  });
}

// ── REST Routes ───────────────────────────────────────────────────────────
app.use("/api/alerts", alertsRouter);
app.use("/api/stocks", stocksRouter);
app.use("/api/analyze", analysisRouter);

// Health check — useful for monitoring and frontend connection check
app.get("/health", async (req, res) => {
  const mlHealth = await getMLHealth();
  res.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    ml_service: mlHealth,
    environment: process.env.NODE_ENV,
  });
});

// ── Internal tick endpoint ────────────────────────────────────────────────
// Python Breeze forwarder (ml-service/breeze_forwarder.py) POSTs here
// for every tick it receives from Breeze WebSocket.
// This keeps Breeze SDK in Python while tick routing stays in Node.
app.post("/internal/tick", async (req, res) => {
  const tick = req.body;

  // Basic validation
  if (!tick.symbol || !tick.price || !tick.volume) {
    return res.status(400).json({ error: "Invalid tick: missing symbol/price/volume" });
  }

  // Normalise symbol to uppercase
  tick.symbol = tick.symbol.toUpperCase();
  tick.timestamp = tick.timestamp || new Date().toISOString();
  tick.source = "breeze";

  await processTick(tick, io);
  res.json({ ok: true });
});

// ── Socket.IO handler ─────────────────────────────────────────────────────
initSocketHandler(io, redisSub);

// ── Start ingestion ───────────────────────────────────────────────────────
startIngestion(io);

// ── Start server ──────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;
httpServer.listen(PORT, () => {
  logger.info(`Server running on port ${PORT}`);
  logger.info(`Mode: ${process.env.NODE_ENV || "development"}`);
  logger.info(`ML service: ${process.env.ML_SERVICE_URL || "http://localhost:8000"}`);
});

// Graceful shutdown
process.on("SIGTERM", () => {
  logger.info("SIGTERM received — shutting down");
  httpServer.close(() => process.exit(0));
});
