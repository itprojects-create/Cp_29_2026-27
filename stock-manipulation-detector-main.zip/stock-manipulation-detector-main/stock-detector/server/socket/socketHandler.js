// server/socket/socketHandler.js
// Manages Socket.IO connections, room subscriptions, and alert broadcasting.

const logger = require("../services/logger");
const { getLiveState } = require("../services/redisClient");

function initSocketHandler(io, redisSub) {
  // ── Redis → Socket.IO bridge ─────────────────────────────────────────
  // Subscribe to alert:new channel published by Python ML service
  redisSub.subscribe("alert:new", (err) => {
    if (err) logger.error("Redis subscribe error:", err.message);
    else logger.info("Subscribed to Redis alert:new channel");
  });

  redisSub.on("message", async (channel, message) => {
    if (channel !== "alert:new") return;

    let alert;
    try {
      alert = JSON.parse(message);
    } catch {
      logger.error("Invalid alert JSON from Redis");
      return;
    }

    // Broadcast to all clients watching this symbol
    io.to(`room:${alert.symbol}`).emit("alert", alert);

    // Also broadcast to "all alerts" room for the dashboard feed
    io.to("room:ALL").emit("alert", alert);

    logger.info(`Alert broadcast: ${alert.symbol} ${alert.alert_type} score=${alert.ensemble_score}`);
  });

  // ── Client connection handling ────────────────────────────────────────
  io.on("connection", (socket) => {
    logger.debug(`Client connected: ${socket.id}`);

    // Client subscribes to a specific symbol's room
    socket.on("subscribe", async (symbol) => {
      socket.join(`room:${symbol}`);
      logger.debug(`${socket.id} joined room:${symbol}`);

      // Send current live state immediately on subscribe
      try {
        const state = await getLiveState(symbol);
        if (state && state.price) {
          socket.emit("live_state", { symbol, ...state });
        }
      } catch {}
    });

    // Client unsubscribes from a symbol
    socket.on("unsubscribe", (symbol) => {
      socket.leave(`room:${symbol}`);
      logger.debug(`${socket.id} left room:${symbol}`);
    });

    // Client wants all alerts feed
    socket.on("subscribe_all", () => {
      socket.join("room:ALL");
    });

    socket.on("disconnect", (reason) => {
      logger.debug(`Client disconnected: ${socket.id} (${reason})`);
    });

    socket.on("error", (err) => {
      logger.error(`Socket error for ${socket.id}:`, err.message);
    });
  });

  logger.info("Socket.IO handler initialised");
}

module.exports = { initSocketHandler };
