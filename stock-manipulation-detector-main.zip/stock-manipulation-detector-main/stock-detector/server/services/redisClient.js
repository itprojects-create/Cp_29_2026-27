// server/services/redisClient.js
// Redis pub and sub MUST be separate ioredis instances.
// A Redis connection in subscribe mode cannot publish.

const Redis = require("ioredis");
const logger = require("./logger");

const REDIS_URL =
  process.env.REDIS_CLOUD_URL ||
  process.env.REDIS_URL ||
  "redis://localhost:6379";

// Publisher — used by Node to publish ticks and forward alerts
const redisPub = new Redis(REDIS_URL, {
  retryStrategy: (times) => Math.min(times * 100, 3000),
  keepAlive: 10000, // send keepalive probe every 10s — well under the 30s reset window
  connectTimeout: 10000,
  lazyConnect: false,
});

const redisSub = new Redis(REDIS_URL, {
  retryStrategy: (times) => Math.min(times * 100, 3000),
  keepAlive: 10000,
  connectTimeout: 10000,
  lazyConnect: false,
});

function formatRedisError(err) {
  return err?.stack || err?.message || String(err);
}

redisPub.on("connect", () => logger.info("Redis publisher connected"));
redisPub.on("ready", () => logger.info("Redis publisher ready"));
redisPub.on("error", (e) =>
  logger.error(`Redis publisher error: ${formatRedisError(e)}`),
);
redisSub.on("connect", () => logger.info("Redis subscriber connected"));
redisSub.on("ready", () => logger.info("Redis subscriber ready"));
redisSub.on("error", (e) =>
  logger.error(`Redis subscriber error: ${formatRedisError(e)}`),
);

// ── Redis helper functions ────────────────────────────────────────────────

/**
 * Publish a normalised tick to the tick channel for this symbol.
 * ML service is subscribed to tick:SYMBOL.
 */
async function publishTick(tick) {
  // tick = { symbol, price, volume, high, low, timestamp }
  await redisPub.publish(`tick:${tick.symbol}`, JSON.stringify(tick));
}

/**
 * Update rolling price history in a sorted set.
 * Score = timestamp in ms so ZRANGE returns chronological order.
 * Keep last 100 ticks only (cheap sliding window for ML features).
 */
async function updatePriceHistory(tick) {
  const key = `prices:${tick.symbol}`;
  const score = Date.now();
  await redisPub.zadd(key, score, JSON.stringify(tick));
  // Trim to last 100 entries
  await redisPub.zremrangebyrank(key, 0, -101);
}

/**
 * Update the live state hash for a symbol.
 * Frontend queries this for current price without hitting Supabase.
 */
async function updateLiveState(tick) {
  await redisPub.hset(`state:${tick.symbol}`, {
    price: tick.price,
    volume: tick.volume,
    high: tick.high || tick.price,
    low: tick.low || tick.price,
    last_updated: tick.timestamp,
  });
}

/**
 * Get the last N ticks for a symbol from sorted set.
 * Used by ML service and also by REST API for charts.
 */
async function getRecentTicks(symbol, count = 100) {
  const raw = await redisPub.zrange(`prices:${symbol}`, -count, -1);
  return raw.map((r) => JSON.parse(r));
}

/**
 * Get current live state for a symbol.
 */
async function getLiveState(symbol) {
  return await redisPub.hgetall(`state:${symbol}`);
}

module.exports = {
  redisPub,
  redisSub,
  publishTick,
  updatePriceHistory,
  updateLiveState,
  getRecentTicks,
  getLiveState,
};
