// server/services/mlBridge.js
// Sends ticks to Python ML service and handles alert responses.
// Uses axios with short timeout so slow ML never blocks ingestion.

const axios = require("axios");
const logger = require("./logger");

const ML_BASE = process.env.ML_SERVICE_URL || "http://localhost:8000";

// Axios instance with conservative timeouts
const mlAxios = axios.create({
  baseURL: ML_BASE,
  timeout: 500, // 500ms — if ML is slow, skip this tick
  headers: { "Content-Type": "application/json" },
});

/**
 * Forward a tick to ML service for anomaly scoring.
 * Returns the ML response or null if service is unavailable.
 *
 * Called for every tick — must be fast.
 */
async function callMLService(tick) {
  try {
    const { data } = await mlAxios.post("/ingest", tick);
    return data;
  } catch (err) {
    if (err.code === "ECONNREFUSED") {
      // ML service not running — silent skip in dev
      return null;
    }
    if (err.code === "ECONNABORTED") {
      // Timeout — ML is busy, skip this tick
      return null;
    }
    logger.debug("ML service error:", err.message);
    return null;
  }
}

/**
 * Trigger LangChain deep analysis on a specific alert.
 * Called by analyst via /api/analyze endpoint.
 * Timeout is 30 seconds — LangChain takes 3-8 seconds normally.
 */
async function callLangchainAnalysis(alertContext) {
  try {
    const { data } = await axios.post(`${ML_BASE}/analyze`, alertContext, {
      timeout: 30000,
      headers: { "Content-Type": "application/json" },
    });
    return data;
  } catch (err) {
    logger.error("LangChain analysis error:", err.message);
    throw new Error(`Analysis failed: ${err.message}`);
  }
}

/**
 * Get ML service health — used by /health endpoint.
 */
async function getMLHealth() {
  try {
    const { data } = await mlAxios.get("/health", { timeout: 2000 });
    return { online: true, ...data };
  } catch {
    return { online: false };
  }
}

/**
 * Trigger manual retraining of Isolation Forest for a symbol.
 * Called when enough new data has accumulated.
 */
async function triggerRetrain(symbol) {
  try {
    const { data } = await mlAxios.post(`/retrain/${symbol}`, {}, { timeout: 60000 });
    return data;
  } catch (err) {
    logger.error(`Retrain error for ${symbol}:`, err.message);
    return null;
  }
}

module.exports = { callMLService, callLangchainAnalysis, getMLHealth, triggerRetrain };
