// server/services/supabaseClient.js
const { createClient } = require("@supabase/supabase-js");
const ws = require("ws");
const logger = require("./logger");

if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_KEY) {
  logger.warn("Supabase env vars missing — DB operations will fail");
}

const supabase = createClient(
  process.env.SUPABASE_URL || "",
  process.env.SUPABASE_SERVICE_KEY || "",
  {
    auth: { persistSession: false },
    realtime: { transport: ws },
  }
);

// ── Alert operations ──────────────────────────────────────────────────────

/**
 * Save a new alert to Supabase.
 * Called every time ML service fires an anomaly.
 */
async function saveAlert(alertData) {
  const { data, error } = await supabase
    .from("alerts")
    .insert({
      symbol: alertData.symbol,
      alert_type: alertData.alert_type,
      severity: alertData.severity,
      level: alertData.level,
      price_at_alert: alertData.price,
      volume_at_alert: alertData.volume,
      if_score: alertData.if_score,
      rf_score: alertData.rf_score,
      ensemble_score: alertData.ensemble_score,
      raw_features: alertData.raw_features || {},
      social_score: alertData.social_score || null,
      social_evidence: alertData.social_evidence || null,
    })
    .select()
    .single();

  if (error) {
    logger.error("Supabase saveAlert error:", error.message);
    return null;
  }
  return data;
}

/**
 * Update an existing alert with LangChain analysis result.
 * Called after analyst triggers AI analysis.
 */
async function updateAlertWithAnalysis(alertId, analysis) {
  const { error } = await supabase
    .from("alerts")
    .update({ langchain_analysis: analysis })
    .eq("id", alertId);

  if (error) logger.error("Supabase updateAlert error:", error.message);
}

/**
 * Fetch recent alerts, optionally filtered by symbol.
 */
async function getAlerts({ symbol, limit = 50, since } = {}) {
  let query = supabase
    .from("alerts")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(limit);

  if (symbol) query = query.eq("symbol", symbol);
  if (since) query = query.gt("created_at", since);

  const { data, error } = await query;
  if (error) {
    logger.error("Supabase getAlerts error:", error.message);
    return [];
  }
  return data;
}

// ── Tick operations ───────────────────────────────────────────────────────

/**
 * Save a price tick for historical archive.
 * We do NOT await this — fire and forget to keep ingestion fast.
 */
function saveTick(tick) {
  supabase
    .from("price_ticks")
    .insert({
      symbol: tick.symbol,
      price: tick.price,
      volume: tick.volume,
      high: tick.high || null,
      low: tick.low || null,
      timestamp: tick.timestamp,
    })
    .then(({ error }) => {
      if (error) logger.error("Supabase saveTick error:", JSON.stringify(error));
    });
}

// ── Watchlist operations ──────────────────────────────────────────────────

async function getWatchlist() {
  const { data, error } = await supabase.from("watchlist").select("*");
  if (error) {
    logger.error("Supabase getWatchlist error:", error.message);
    return [];
  }
  return data;
}

async function addToWatchlist(symbol, companyName) {
  const { data, error } = await supabase
    .from("watchlist")
    .upsert({ symbol, company_name: companyName })
    .select()
    .single();

  if (error) {
    logger.error("Supabase addToWatchlist error:", error.message);
    return null;
  }
  return data;
}

module.exports = {
  supabase,
  saveAlert,
  updateAlertWithAnalysis,
  getAlerts,
  saveTick,
  getWatchlist,
  addToWatchlist,
};
