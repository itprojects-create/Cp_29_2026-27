// server/services/priceIngestion.js
// Primary:    Angel One SmartAPI WebSocket — free, real NSE live ticks
//             Run: python ml-service/angelone_forwarder.py
//             It connects SmartWebSocketV2 and POSTs each tick to /internal/tick
// Fallback:   stock-nse-india npm polling every 5 seconds (no API key needed)
// Simulation: Random walk for dev/demo when neither is running

const logger = require("./logger");
const { publishTick, updatePriceHistory, updateLiveState } = require("./redisClient");
const { saveTick } = require("./supabaseClient");
const { callMLService } = require("./mlBridge");

const WATCHLIST = [
  "RELIANCE", "HDFCBANK", "INFY", "TCS", "ICICIBANK",
  "KOTAKBANK", "SBIN", "AXISBANK", "BAJFINANCE", "WIPRO",
  "ZOMATO", "NYKAA", "PAYTM", "ADANIENT", "YESBANK",
];

// In-memory price state for simulation fallback
const priceState = {};
WATCHLIST.forEach((sym) => {
  priceState[sym] = { price: 100 + Math.random() * 2000, pumped: false };
});

// ── Main entry point ──────────────────────────────────────────────────────
function startIngestion(io) {
  if (process.env.ANGELONE_API_KEY) {
    logger.info("Angel One mode: waiting for python forwarder");
  } else if (process.env.DISABLE_SIMULATION === "true") {
    logger.info("Simulation explicitly disabled — waiting for manual ticks only");
    // Do nothing — only /internal/tick POSTs (from demo_runner.py) will feed the system
  } else if (process.env.NODE_ENV !== "production") {
    logger.warn("No Angel One key — starting simulation mode");
    startSimulation(io);
  } else {
    logger.error("Production requires ANGELONE_API_KEY");
    process.exit(1);
  }
}

// ── NSE Polling fallback ──────────────────────────────────────────────────
function startPolling(io) {
  let NseIndia;
  try {
    NseIndia = require("stock-nse-india").NseIndia;
  } catch {
    logger.warn("stock-nse-india not installed — starting simulation");
    startSimulation(io);
    return;
  }
  const nse = new NseIndia();
  logger.info("NSE polling started (5s intervals)");

  async function pollAll() {
    for (const symbol of WATCHLIST) {
      try {
        const details = await nse.getEquityDetails(symbol);
        const info = details?.priceInfo;
        if (!info) continue;
        const tick = {
          symbol,
          price:     parseFloat(info.lastPrice),
          volume:    parseInt(info.totalTradedVolume || 0),
          high:      parseFloat(info.intraDayHighLow?.max || info.lastPrice),
          low:       parseFloat(info.intraDayHighLow?.min || info.lastPrice),
          timestamp: new Date().toISOString(),
          source:    "nse_poll",
        };
        await processTick(tick, io);
      } catch {}
    }
  }
  pollAll();
  setInterval(pollAll, 5000);
}

// ── Simulation mode ───────────────────────────────────────────────────────
function startSimulation(io) {
  logger.info("Simulation: generating synthetic NSE ticks (replace with Angel One forwarder)");
  setInterval(async () => {
    const symbol = WATCHLIST[Math.floor(Math.random() * WATCHLIST.length)];
    const prev = priceState[symbol];
    const isPump = Math.random() < 0.02;
    const isDump = prev.pumped && Math.random() < 0.35;
    const price = Math.max(1,
      prev.price + (isDump ? -prev.price * 0.06 : isPump ? prev.price * 0.05 : (Math.random() - 0.5) * prev.price * 0.004)
    );
    const volume = Math.floor((500000 + Math.random() * 2000000) * (isPump ? 6 : isDump ? 3 : 1));
    priceState[symbol] = { price, pumped: isPump || (prev.pumped && !isDump) };
    await processTick({
      symbol, price: parseFloat(price.toFixed(2)), volume,
      high: parseFloat((price * 1.002).toFixed(2)),
      low:  parseFloat((price * 0.998).toFixed(2)),
      timestamp: new Date().toISOString(), source: "simulation",
    }, io);
  }, 400);
}

// ── Core tick processor ───────────────────────────────────────────────────
async function processTick(tick, io) {
  try {
    await publishTick(tick);
    await updatePriceHistory(tick);
    await updateLiveState(tick);
    if (io) {
      io.to(`room:${tick.symbol}`).emit("tick", {
        symbol: tick.symbol, price: tick.price,
        volume: tick.volume, timestamp: tick.timestamp,
      });
    }
    callMLService(tick).catch(() => {});
    saveTick(tick);
  } catch (err) {
    logger.error("processTick error:", err.message);
  }
}

module.exports = { startIngestion, processTick, WATCHLIST };
