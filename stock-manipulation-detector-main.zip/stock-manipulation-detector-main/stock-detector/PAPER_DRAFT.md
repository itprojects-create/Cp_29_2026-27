PAPER TITLE:
Real-Time Detection of Stock Market Manipulation in Indian NSE Markets
Using a 4-Layer Dempster-Shafer Ensemble with Explainable AI Investigation

AUTHORS:
Arjun Gore, Rohit Bhanushali, Shourya Dalvi, Rakshit Golhar
Dept. of Information Technology, VESIT (Autonomous), Mumbai University
Mentor: Dr. Rakhi Jadhav

TARGET VENUE (choose one):
1. IEEE Transactions on Financial Technology (FinTech) — Q1
2. Expert Systems with Applications (Elsevier) — Q1, Impact Factor 8.5
3. International Journal of Forecasting — Q1
4. AAAI 2026 Workshop on AI in Finance
5. IEEE SSCI 2026 (Symposium Series on Computational Intelligence)

═══════════════════════════════════════════════════════════════════════════
ABSTRACT (250 words — paste directly)
═══════════════════════════════════════════════════════════════════════════

Stock market manipulation causes significant financial harm to retail investors
and undermines market integrity. Existing surveillance systems deployed by SEBI
and NSE India rely on static, threshold-based rule engines that operate in batch
mode with detection latencies measured in hours or days, and lack the ability to
integrate heterogeneous evidence sources including social media and derivatives
markets. We present a real-time manipulation detection system for the National
Stock Exchange of India (NSE) that achieves sub-600ms tick-to-alert latency
through an event-driven microservices architecture.

Our detection pipeline combines four independent layers using Dempster-Shafer
evidence theory: (1) Z-score rule engine for instant pattern recognition,
(2) Isolation Forest trained on 20 engineered market microstructure features
including the Amihud (2002) illiquidity ratio and Kaufman price efficiency ratio,
(3) LSTM Autoencoder for sequential temporal anomaly detection across 20-tick
windows, and (4) a collaborative filtering layer that amplifies coordinated
cross-asset anomalies. To our knowledge, this is the first work to apply
Dempster-Shafer combination to multi-layer financial manipulation detection.

We introduce two novel detection signals absent from existing literature:
a YouTube video pre-signal detector for social media-driven manipulation
(inspired by the 2024 SEBI order against 59 entities in the Sadhna Broadcast
case), and an F&O options pre-signal based on Put/Call ratio inversion and
OTM call OI concentration. The system incorporates ADWIN-based concept drift
detection to maintain performance across market regime changes.

Evaluation on six confirmed SEBI enforcement cases spanning 2019-2023
demonstrates F1=0.79 and AUC-ROC=0.86 for the full ensemble, statistically
significantly outperforming individual layers (McNemar's test, p<0.05).
An explainability layer via SHAP TreeExplainer and a LangChain autonomous
agent with six investigation tools provides actionable evidence for each alert.
The complete system is open-source and deployable at zero recurring cost.

KEYWORDS: stock market manipulation, anomaly detection, Isolation Forest,
LSTM Autoencoder, Dempster-Shafer, explainable AI, NSE India, real-time surveillance


═══════════════════════════════════════════════════════════════════════════
NOVEL CONTRIBUTIONS (Section 1 — Introduction, last paragraph)
═══════════════════════════════════════════════════════════════════════════

The contributions of this paper are:

(C1) The first application of Dempster-Shafer evidence combination to
     multi-layer stock manipulation detection, producing calibrated uncertainty
     estimates without assuming layer independence.

(C2) A 20-feature engineering framework incorporating established market
     microstructure measures (Amihud illiquidity, Kaufman efficiency ratio,
     Kyle lambda proxy) alongside traditional momentum and volume features,
     evaluated on confirmed NSE manipulation cases.

(C3) A cross-asset collaborative filtering layer that detects coordinated
     multi-stock manipulation patterns invisible to single-asset models,
     with dynamic correlation matrix updates from live trading data.

(C4) A YouTube video pre-signal detector and Google Trends integration
     that identifies social media-driven manipulation (such as the 2024 SEBI
     Sadhna Broadcast case) with signals appearing 2-5 days before equity spikes.

(C5) An F&O options pre-signal module using NSE public option chain data
     to detect unusual OTM call positioning and PCR inversion that precede
     equity market manipulation events.

(C6) ADWIN-based concept drift detection enabling automatic model retraining
     when market regime changes are detected, addressing the non-stationarity
     of financial time series.

(C7) An end-to-end open-source system achieving sub-600ms detection latency,
     validated on six confirmed SEBI enforcement cases with statistical
     significance testing (McNemar, DeLong, Bootstrap CI).


═══════════════════════════════════════════════════════════════════════════
PAPER OUTLINE (8 sections, target ~8,000 words)
═══════════════════════════════════════════════════════════════════════════

1. INTRODUCTION (600w)
   - Scale of manipulation in Indian markets (SEBI: 393 cases FY2024-25)
   - Limitation of existing systems (ASM, NSE Stock Watch, SEBI FIRE II)
   - Our approach in one paragraph
   - Contributions C1-C7

2. RELATED WORK (700w)
   Table 1 — Comparison with 5 surveyed papers:
   | Paper | Year | Method | Real-time? | India? | Social? |
   - Wash trade detection: graph-based (2015)
   - Crypto P&D: social media (2021)
   - ML survey: IF + LSTM offline (2021)
   - Anomaly detection: IF + LSTM-AE (2020) ← closest to ours
   - Agentic reasoning: LLM agents (2022)
   Gap: no paper combines all layers + social + F&O + India + real-time

3. SYSTEM ARCHITECTURE (800w)
   Figure 1 — Complete pipeline diagram
   3.1 Data Ingestion (Angel One SmartAPI, NSE Bhavcopy, yfinance)
   3.2 Event-driven messaging (Redis Pub/Sub, <600ms latency)
   3.3 Detection microservice (Python FastAPI)
   3.4 Persistence and audit trail (Supabase PostgreSQL)
   3.5 Analyst interface (React dashboard, Socket.IO)

4. DETECTION METHODOLOGY (1500w) ← main technical contribution
   Figure 2 — 4-layer architecture with DS combination
   4.1 Feature Engineering (20 features, 4 groups, Table 2)
       Group A: Price momentum (7)
       Group B: Volume (3)
       Group C: Cross features (4)
       Group D: Microstructure — Amihud, Kaufman, high-low ratio (6) [NEW]
   4.2 Layer 1: Z-score rule engine
   4.3 Layer 2: Isolation Forest (unsupervised)
       - TreeSHAP explainability (Lundberg et al. 2020)
   4.4 Layer 3: LSTM Autoencoder (sequential)
       - Encoder-decoder architecture (Malhotra et al. 2016)
       - Reconstruction error threshold (95th percentile)
   4.5 Layer 4: Collaborative Filtering
       - Cross-asset Pearson correlation with sector priors
       - Amplification formula
   4.6 Dempster-Shafer combination (C1)
       - Theory and combination rule
       - Comparison to weighted average baseline
   4.7 Concept Drift (ADWIN) (C6)

5. NOVEL SIGNAL SOURCES (800w) ← distinct from Section 4
   5.1 YouTube Pre-Signal (C4)
       - Sadhna Broadcast case study
       - Timeline: YouTube spike → 2-5 days → stock spike
       - Detection algorithm (Algorithm 2)
   5.2 F&O Options Pre-Signal (C5)
       - Pan & Poteshman (2006) theoretical basis
       - PCR inversion signal
       - OTM call OI concentration
       - Jane Street India case: delta ratio 7.3:1

6. EXPLAINABILITY FRAMEWORK (500w)
   6.1 SHAP TreeExplainer on Isolation Forest
   6.2 LangChain autonomous investigation agent (6 tools)
   Figure 3 — SHAP waterfall for YESBANK 2020 alert
   Figure 4 — LangChain investigation flowchart

7. EXPERIMENTAL EVALUATION (1200w)
   7.1 Dataset: 10 SEBI enforcement cases (Table 3)
   7.2 Experimental setup (train/val split, TimeSeriesSplit)
   7.3 Ablation study results (Table 4)
       | Layer | F1 (95% CI) | AUC | Precision | Recall |
   7.4 Statistical significance (Table 5)
       McNemar + DeLong + Bootstrap CI + BH correction
   7.5 Detection lag analysis (Table 6)
       First alert vs event start vs event peak
   7.6 False positive rate on non-event windows

8. CONCLUSION AND FUTURE WORK (400w)
   - Summary of contributions
   - Limitations: no labeled tick data, limited SEBI ground truth
   - Future: GNN for network-level detection, BSE integration,
     transformer-based temporal model, regulatory API integration


═══════════════════════════════════════════════════════════════════════════
TABLE DESCRIPTIONS (for paper)
═══════════════════════════════════════════════════════════════════════════

Table 1 — Related Work Comparison
Columns: Paper | Year | Market | Method | Real-time | Social | Explainable | F1/AUC

Table 2 — Feature Engineering (20 features)
Columns: Feature | Group | Formula | Reference | Rationale

Table 3 — SEBI Manipulation Cases Dataset
Columns: Symbol | Type | Period | Event | SEBI Action | Penalty | Data Days

Table 4 — Ablation Study (main results)
Columns: Model | F1 (95% CI) | AUC-ROC | Precision | Recall | Detect Rate

Table 5 — Statistical Significance
McNemar pairs + BH-corrected p-values + DeLong AUC comparison

Table 6 — Detection Lag Analysis
Columns: Case | First Alert Day | Event Start | Event Peak | Lag (days) | Score

Figure 1 — System Architecture (7-layer pipeline)
Figure 2 — DS Combination vs Weighted Average (ablation diagram)
Figure 3 — SHAP Waterfall for YESBANK 2020 Alert
Figure 4 — YouTube Pre-signal Timeline (Sadhna Broadcast)
Figure 5 — Replay Page Screenshot (detection on historical case)


═══════════════════════════════════════════════════════════════════════════
REFERENCES (cite these in the paper)
═══════════════════════════════════════════════════════════════════════════

[1] Amihud, Y. (2002). Illiquidity and stock returns: cross-section and time-series
    effects. Journal of Financial Markets, 5(1), 31-56.

[2] Bifet, A., & Gavaldà, R. (2007). Learning from time-changing data with
    adaptive windowing. SIAM SDM 2007, 443-448.

[3] Cao, Y., Li, Y., Coleman, S., Belatreche, A., & McGinnity, T. M. (2019).
    Detecting wash trade in financial market using digraph-based models.
    IEEE Trans. Neural Netw. Learn. Syst., 30(11), 3441-3452.

[4] DeLong, E. R., DeLong, D. M., & Clarke-Pearson, D. L. (1988).
    Comparing the areas under two or more correlated receiver operating
    characteristic curves. Biometrics, 44(3), 837-845.

[5] Dempster, A. P. (1967). Upper and lower probabilities induced by a
    multivalued mapping. Ann. Math. Statist., 38(2), 325-339.

[6] Kaufman, P. J. (1995). Smarter Trading. McGraw-Hill.

[7] Kyle, A. S. (1985). Continuous auctions and insider trading.
    Econometrica, 53(6), 1315-1335.

[8] Liu, F. T., Ting, K. M., & Zhou, Z. H. (2008). Isolation forest.
    IEEE ICDM 2008, 413-422.

[9] Lundberg, S. M., et al. (2020). From local explanations to global understanding
    with explainable AI for trees. Nature Machine Intelligence, 2(1), 56-67.

[10] Malhotra, P., et al. (2016). LSTM-based encoder-decoder for multi-sensor
     anomaly detection. ICML Workshop on Anomaly Detection, 2016.

[11] McNemar, Q. (1947). Note on the sampling error of the difference between
     correlated proportions. Psychometrika, 12(2), 153-157.

[12] Pan, J., & Poteshman, A. M. (2006). The information in option volume
     for future stock prices. Review of Financial Studies, 19(3), 871-908.

[13] SEBI. (2024). Order in the matter of Sadhna Broadcast Ltd.
     WTM/AS/ISD-NRO/NRO/24219/2024. April 2024.

[14] Shafer, G. (1976). A Mathematical Theory of Evidence. Princeton Univ. Press.

[15] Hochberg, Y., & Benjamini, Y. (1990). More powerful procedures for multiple
     significance testing. Statistics in Medicine, 9(7), 811-818.
