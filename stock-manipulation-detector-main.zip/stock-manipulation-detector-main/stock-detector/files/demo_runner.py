#!/usr/bin/env python3
# ml-service/demo/demo_runner.py — COMPLETE REPLACEMENT FILE
import time, json, argparse, requests, random
from datetime import datetime
from loguru import logger

NODE_URL = "http://localhost:3001/internal/tick"
ML_URL   = "http://localhost:8000"

def send_tick(tick, silent=False):
    try:
        r = requests.post(NODE_URL, json=tick, timeout=1.0)
        if r.status_code == 200:
            return r.json()
    except requests.exceptions.ConnectionError:
        if not silent:
            logger.error(f"Node.js not running. Start: cd server && npm run dev")
        return None
    except Exception:
        pass
    return None

def trigger_analysis(symbol, ml_result, tick):
    logger.info(f"\n  🤖 Triggering AI analysis for {symbol}...")
    try:
        r = requests.post(f"{ML_URL}/analyze", json={
            "symbol": symbol, "alert_type": "ML_ANOMALY",
            "price": tick["price"], "volume": tick["volume"],
            "ensemble_score": ml_result.get("ensemble_score", 0),
            "if_score": ml_result.get("if_score", 0),
            "rf_score": ml_result.get("rf_score", 0),
        }, timeout=30)
        if r.status_code == 200:
            d = r.json()
            logger.info(f"  ┌─ AI VERDICT ─────────────────────────────────")
            logger.info(f"  │ Probability:  {d.get('manipulation_probability',0)}/100")
            logger.info(f"  │ Type:         {d.get('manipulation_type','?')}")
            logger.info(f"  │ Action:       {d.get('recommended_action','?')}")
            for ev in d.get("evidence", [])[:3]:
                logger.info(f"  │  • {ev[:80]}")
            logger.info(f"  └──────────────────────────────────────────────\n")
    except Exception as e:
        logger.warning(f"  AI analysis: {e}")

# ── Scenario 1: Pump & Dump ───────────────────────────────────────────────
def run_pump_dump(speed=0.4, analyze=False):
    logger.info("\n" + "="*60)
    logger.info("SCENARIO: PUMP & DUMP — SUZLON Style")
    logger.info("Phase 1 (1-25):  Quiet  |  Phase 2 (26-55): +12% 15x vol  |  Phase 3 (56-75): -20% crash")
    logger.info("="*60)
    time.sleep(2)

    rng = random.Random(42)
    base_price = 35.0; base_vol = 500_000; symbol = "SUZLON"
    alert_fired = False; first_tick = None

    phases = [(25, 0.0001, 0.8, "normal"), (30, 0.004, 15.0, "pump"), (20, -0.011, 8.0, "dump")]
    tick_num = 0
    for phase_len, drift, vol_mul, label in phases:
        if label == "pump": logger.info("\n  🚀 PUMP STARTING — watch dashboard!\n")
        if label == "dump": logger.info("\n  📉 DUMP PHASE\n")
        for _ in range(phase_len):
            base_price = max(0.5, base_price * (1 + drift + rng.gauss(0, 0.0006)))
            volume = int(base_vol * vol_mul * rng.uniform(0.7, 1.3))
            tick = {"symbol": symbol, "price": round(base_price,2), "volume": volume,
                    "high": round(base_price*1.008,2), "low": round(base_price*0.992,2),
                    "timestamp": datetime.utcnow().isoformat(), "source": f"demo_{label}"}
            result = send_tick(tick)
            if result and result.get("ensemble_score", 0) > 0:
                flag = "🚨" if result.get("should_alert") else "  "
                logger.info(f"  {flag} tick={tick_num:>3}  {label:<8}  ₹{base_price:>7.2f}"
                            f"  vol={volume/1e6:.2f}M  score={result['ensemble_score']:.3f}  [{result['level']}]")
                if result.get("should_alert") and not alert_fired:
                    alert_fired = True; first_tick = tick_num
                    logger.info(f"\n  ✅ FIRST ALERT tick={tick_num}  score={result['ensemble_score']:.3f}\n")
                    if analyze and result["level"] in ("HIGH","CRITICAL"):
                        trigger_analysis(symbol, result, tick)
            time.sleep(speed); tick_num += 1
    logger.info(f"\n  Done. First alert: tick {first_tick if alert_fired else 'NONE'}\n")

# ── Scenario 2: Celebrity YouTube Pump (HIGHLIGHT) ────────────────────────
def run_celebrity_pump(speed=0.35, analyze=False):
    logger.info("\n" + "="*60)
    logger.info("🎬 SCENARIO: CELEBRITY YOUTUBE PUMP")
    logger.info("   Arshad Warsi / Sadhna Broadcast Pattern")
    logger.info("="*60)
    logger.info("""
REAL CASE (SEBI April 2024):
  • 59 entities barred including Bollywood actor Arshad Warsi
  • YouTube channels posted FAKE Adani takeover news
  • 90 LAKH+ views funded by Rs 5.8cr Google Ads
  • Stock: Rs 20 → Rs 120 (+500%) in 3 months
  • SEBI penalty: Rs 58.01 crore

DEMO TIMELINE:
  ticks  1-20:  Stock quiet at Rs 20, no social signal
  ticks 21-35:  YouTube campaign STARTS  ← OUR PRE-SIGNAL FIRES
  ticks 36-60:  Price surges, volume 30x (stock follows social by 15 ticks)
  ticks 61-75:  Promoters dump, crash to Rs 30
""")
    time.sleep(3)

    rng = random.Random(7)
    base_price = 20.0; base_vol = 50_000; symbol = "SADHNA_DEMO"
    alert_fired = False; first_tick = None
    YOUTUBE_START = 21; PUMP_START = 36; DUMP_START = 61

    for tick_num in range(80):
        if tick_num < YOUTUBE_START:
            label = "quiet"; drift = rng.gauss(0.0001, 0.004); vol_mul = rng.uniform(0.7,1.3)
            yt_views = 0; st_bull = rng.randint(48,55)
        elif tick_num < PUMP_START:
            label = "youtube_presignal"
            progress = (tick_num - YOUTUBE_START) / (PUMP_START - YOUTUBE_START)
            drift = rng.gauss(0.001, 0.005); vol_mul = rng.uniform(1.0, 2.5)
            yt_views = int(500_000 * (progress**1.8) * rng.uniform(0.6,1.4))
            st_bull = int(60 + progress*20)
            if tick_num == YOUTUBE_START:
                logger.info(f"\n  📺 tick={tick_num}: YOUTUBE CAMPAIGN STARTS")
                logger.info(f"     'The Advisor' posts first video — social pre-signal active\n")
        elif tick_num < DUMP_START:
            label = "pump"
            progress = (tick_num - PUMP_START) / (DUMP_START - PUMP_START)
            drift = 0.018 + progress*0.01 + rng.gauss(0,0.008)
            vol_mul = 8 + progress*22 + rng.uniform(-2,2)
            yt_views = int(2_000_000 * (1-progress*0.3) * rng.uniform(0.5,1.5))
            st_bull = int(min(95, 82 + progress*8))
            if tick_num == PUMP_START:
                logger.info(f"\n  🚀 tick={tick_num}: STOCK STARTS PUMPING")
                logger.info(f"     Social lag = {tick_num - YOUTUBE_START} ticks after YouTube start\n")
        else:
            label = "dump"; drift = -0.025 + rng.gauss(0, 0.012)
            vol_mul = rng.uniform(6,12); yt_views = 0; st_bull = rng.randint(25,40)
            if tick_num == DUMP_START:
                logger.info(f"\n  📉 tick={tick_num}: PROMOTERS DUMPING — SEBI investigates\n")

        base_price = max(15.0, min(90.0 if tick_num < DUMP_START else 999, base_price*(1+drift)))
        volume = int(base_vol * vol_mul)
        tick = {"symbol": symbol, "price": round(base_price,2), "volume": volume,
                "high": round(base_price*1.01,2), "low": round(base_price*0.99,2),
                "timestamp": datetime.utcnow().isoformat(), "source": f"demo_{label}"}

        result = send_tick(tick)
        if result and result.get("ensemble_score", 0) > 0:
            flag = "🚨" if result.get("should_alert") else "  "
            logger.info(f"  {flag} tick={tick_num:>3}  {label:<18}  ₹{base_price:>6.1f}"
                        f"  score={result['ensemble_score']:.3f}  [{result['level']}]"
                        f"  YT={yt_views//1000:>4}K  ST={st_bull}%bull")
            if result.get("should_alert") and not alert_fired:
                alert_fired = True; first_tick = tick_num
                lag_from_yt = tick_num - YOUTUBE_START
                lag_to_pump = PUMP_START - tick_num
                logger.info(f"\n  ✅ FIRST ALERT tick={tick_num}  score={result['ensemble_score']:.3f}")
                logger.info(f"     YouTube started {lag_from_yt} ticks ago")
                if lag_to_pump > 0:
                    logger.info(f"     ⭐ Alert fired {lag_to_pump} ticks BEFORE price pump!")
                    logger.info(f"     → Social pre-signal detection working!\n")
                if analyze and result["level"] in ("HIGH","CRITICAL"):
                    trigger_analysis(symbol, result, tick)
        time.sleep(speed)

    logger.info(f"\n{'='*60}")
    logger.info(f"🎬 CELEBRITY PUMP COMPLETE")
    if alert_fired:
        lag = PUMP_START - first_tick
        logger.info(f"  First alert: tick {first_tick} | YouTube start: tick {YOUTUBE_START}")
        if lag > 0:
            logger.info(f"  ⭐ Pre-signal: {lag} ticks before price pump (Sadhna pattern!)")
    logger.info(f"{'='*60}\n")

# ── Scenario 3: Coordinated Buy ───────────────────────────────────────────
def run_coordinated_buy(speed=0.4, analyze=False):
    logger.info("\n" + "="*60)
    logger.info("SCENARIO: COORDINATED BUY — YESBANK + SBIN (CF Demo)")
    logger.info("Both move together → Collaborative Filter amplifies score")
    logger.info("="*60)
    time.sleep(1)

    rng = random.Random(13)
    prices = {"YESBANK": 21.5, "SBIN": 820.0}
    volumes = {"YESBANK": 15_000_000, "SBIN": 8_000_000}
    alert_fired = False

    phases = [
        (15, {"YESBANK":0.0001,"SBIN":0.0001}, {"YESBANK":1.0,"SBIN":1.0},   "normal"),
        (55, {"YESBANK":0.0015,"SBIN":0.0009}, {"YESBANK":8.5,"SBIN":4.0},   "coord_buy"),
        (10, {"YESBANK":-0.002,"SBIN":-0.001}, {"YESBANK":3.0,"SBIN":2.0},   "dump"),
    ]

    tick_num = 0
    for phase_len, drifts, vol_muls, label in phases:
        for _ in range(phase_len):
            for sym in ["YESBANK","SBIN"]:
                prices[sym] = max(1, prices[sym]*(1+drifts[sym]+rng.gauss(0,0.0005)))
                vol = int(volumes[sym]*vol_muls[sym]*rng.uniform(0.7,1.3))
                tick = {"symbol":sym,"price":round(prices[sym],2),"volume":vol,
                        "high":round(prices[sym]*1.004,2),"low":round(prices[sym]*0.996,2),
                        "timestamp":datetime.utcnow().isoformat(),"source":f"demo_{label}"}
                result = send_tick(tick, silent=(sym=="SBIN"))
                if result and result.get("should_alert") and sym=="YESBANK":
                    cf = result.get("cf_signal",""); peers = result.get("co_moving_peers",[])
                    logger.info(f"  🚨 tick={tick_num:>3}  YESBANK  ₹{prices['YESBANK']:.2f}"
                                f"  score={result['ensemble_score']:.3f}  CF={cf}  peers={peers}")
                    if not alert_fired:
                        alert_fired = True
                        if analyze: trigger_analysis(sym, result, tick)
            time.sleep(speed/2); tick_num += 1
    logger.info(f"\n  Done. CF co-movement detected: {alert_fired}\n")

# ── Scenario 4: Short Attack ──────────────────────────────────────────────
def run_short_attack(speed=0.4, analyze=False):
    logger.info("\n" + "="*60)
    logger.info("SCENARIO: SHORT ATTACK — ADANIENT")
    logger.info("="*60)
    time.sleep(1)

    rng = random.Random(99)
    base_price = 2400.0; base_vol = 3_000_000; symbol = "ADANIENT"
    first_alert = None
    phases = [(10,0.0001,1.0,"normal"),(45,-0.0028,6.0,"short_attack"),(15,-0.005,10.0,"accelerated")]

    tick_num = 0
    for phase_len, drift, vol_mul, label in phases:
        for _ in range(phase_len):
            base_price = max(100, base_price*(1+drift+rng.gauss(0,0.0007)))
            volume = int(base_vol*vol_mul*rng.uniform(0.6,1.4))
            tick = {"symbol":symbol,"price":round(base_price,2),"volume":volume,
                    "high":round(base_price*1.004,2),"low":round(base_price*0.996,2),
                    "timestamp":datetime.utcnow().isoformat(),"source":f"demo_{label}"}
            result = send_tick(tick)
            if result and result.get("should_alert"):
                logger.info(f"  🚨 tick={tick_num:>3}  ₹{base_price:.0f}"
                            f"  score={result['ensemble_score']:.3f}  [{result['level']}]")
                if first_alert is None:
                    first_alert = tick_num
                    if analyze: trigger_analysis(symbol, result, tick)
            time.sleep(speed); tick_num += 1
    logger.info(f"\n  Done. First alert: tick {first_alert}\n")

# ── Scenario 5: Normal day ────────────────────────────────────────────────
def run_normal(speed=0.3):
    logger.info("\n" + "="*60)
    logger.info("SCENARIO: NORMAL DAY — RELIANCE (should NOT alert)")
    logger.info("="*60)
    rng = random.Random(5)
    base_price = 2456.0; base_vol = 3_500_000; fp = 0

    for tick_num in range(80):
        base_price = max(100, base_price*(1+rng.gauss(0,0.0004)))
        volume = int(base_vol*rng.uniform(0.7,1.3))
        tick = {"symbol":"RELIANCE","price":round(base_price,2),"volume":volume,
                "high":round(base_price*1.002,2),"low":round(base_price*0.998,2),
                "timestamp":datetime.utcnow().isoformat(),"source":"demo_normal"}
        result = send_tick(tick)
        if result and result.get("should_alert"):
            logger.warning(f"  ⚠️  tick={tick_num} FALSE POSITIVE score={result['ensemble_score']:.3f}")
            fp += 1
        elif result and result.get("ensemble_score",0)>0:
            logger.info(f"  ✓  tick={tick_num:>3}  ₹{base_price:.2f}  score={result['ensemble_score']:.3f}  [NONE]")
        time.sleep(speed)

    msg = "✅ No false positives!" if fp==0 else f"⚠️  {fp} false positives"
    logger.info(f"\n  {msg}\n")

# ── All ────────────────────────────────────────────────────────────────────
def run_all(speed=0.35, analyze=False):
    for fn, nm in [(run_normal,"normal"),(run_pump_dump,"pump_dump"),
                   (run_celebrity_pump,"celebrity_pump"),(run_coordinated_buy,"coord_buy"),
                   (run_short_attack,"short_attack")]:
        logger.info(f"\n>>> Running: {nm}")
        fn(speed, analyze) if fn not in (run_normal,) else fn(speed)
        time.sleep(3)
    logger.info("✅ ALL COMPLETE")

# ── Main ──────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenario", default="celebrity_pump",
        choices=["pump_dump","celebrity_pump","coordinated_buy","short_attack","normal","all"])
    parser.add_argument("--speed",   type=float, default=0.4)
    parser.add_argument("--analyze", action="store_true")
    args = parser.parse_args()

    logger.info("="*60)
    logger.info("MARKET SENTINEL — DEMO MODE")
    logger.info(f"Dashboard: http://localhost:5173")
    logger.info("="*60)

    try:
        h = requests.get(f"{ML_URL}/health", timeout=3).json()
        logger.info(f"ML: online | IF={h['layers']['isolation_forest']}")
    except Exception:
        logger.warning("ML service offline — start: uvicorn main:app --port 8000 --reload")

    time.sleep(1)
    fns = {"pump_dump":run_pump_dump,"celebrity_pump":run_celebrity_pump,
           "coordinated_buy":run_coordinated_buy,"short_attack":run_short_attack,
           "normal":run_normal,"all":run_all}
    fn = fns[args.scenario]
    fn(args.speed, args.analyze) if args.scenario != "normal" else fn(args.speed)
