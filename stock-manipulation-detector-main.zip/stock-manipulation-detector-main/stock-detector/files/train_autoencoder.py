#!/usr/bin/env python3
# ml-service/trainer/train_autoencoder.py
# COMPLETE FILE
#
# Trains vanilla feedforward autoencoder using sklearn MLPRegressor.
# No PyTorch required — works on any Windows/Mac/Linux machine.
# Training time: ~30-60 seconds.
#
# Run: python trainer/train_autoencoder.py
# Output: models/vanilla_ae_encoder.pkl
#         models/vanilla_ae_decoder.pkl
#         models/vanilla_ae_scaler.pkl
#         models/vanilla_ae_threshold.pkl

import sys, numpy as np, joblib
from pathlib import Path
from loguru import logger
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

sys.path.insert(0, str(Path(__file__).parent.parent))
from detector.features  import extract_features, FEATURE_NAMES, FEAT_DIM, WINDOW
from trainer.download_data import load_all
from trainer.label_events  import label_dataframe

MODELS_DIR = Path(__file__).parent.parent / "models"
MODELS_DIR.mkdir(exist_ok=True)

BOTTLENECK_DIM = 6   # Latent space size (compress 20 → 6)


def build_normal_features(all_data: dict) -> np.ndarray:
    """
    Extract feature vectors from NORMAL trading days only.
    These are the training samples for the autoencoder.
    """
    logger.info("Building feature matrix from normal trading data...")
    rows = []

    for symbol, raw_df in all_data.items():
        if raw_df is None or len(raw_df) < WINDOW + 10:
            continue
        df = label_dataframe(raw_df, symbol).sort_index()

        for i in range(WINDOW + 1, len(df)):
            # Skip manipulation days — only train on normal
            if df.iloc[i]["label"] == 1:
                continue

            hist = [
                {
                    "price":  float(df.iloc[j]["close"]),
                    "volume": int(df.iloc[j]["volume"]),
                    "high":   float(df.iloc[j].get("high", df.iloc[j]["close"])),
                    "low":    float(df.iloc[j].get("low",  df.iloc[j]["close"])),
                }
                for j in range(max(0, i - WINDOW - 1), i)
            ]
            row = df.iloc[i]
            feats = extract_features(
                float(row["close"]), int(row["volume"]),
                float(row.get("high", row["close"])),
                float(row.get("low",  row["close"])),
                hist,
            )
            if feats is not None:
                rows.append(feats.flatten())

        logger.info(f"  {symbol}: extracted features from normal days")

    if not rows:
        raise ValueError("No feature rows built. Run download_data.py first.")

    X = np.array(rows, dtype=np.float32)
    logger.info(f"Normal feature matrix: {X.shape} ({X.shape[0]:,} rows × {X.shape[1]} features)")
    return X


def train():
    logger.info("=" * 60)
    logger.info("VANILLA AUTOENCODER TRAINING (sklearn, no PyTorch)")
    logger.info(f"Architecture: {FEAT_DIM} → 16 → {BOTTLENECK_DIM} → 16 → {FEAT_DIM}")
    logger.info("=" * 60)

    # Load data
    all_data = load_all()
    if not all_data:
        logger.error("No data. Run: python trainer/download_data.py first")
        sys.exit(1)

    X = build_normal_features(all_data)

    # Scale features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Train/val split (time-ordered — no shuffle to preserve temporal integrity)
    split_idx = int(len(X_scaled) * 0.85)
    X_train   = X_scaled[:split_idx]
    X_val     = X_scaled[split_idx:]
    logger.info(f"Train: {len(X_train):,}  Val: {len(X_val):,}")

    # ── Train Encoder: FEAT_DIM → 16 → BOTTLENECK_DIM ──────────────────
    # MLPRegressor configured as encoder (input → compressed)
    logger.info("\nTraining Encoder (20 → 16 → 6)...")
    encoder = MLPRegressor(
        hidden_layer_sizes=(16,),           # One hidden layer
        activation="tanh",                  # Tanh works well for autoencoders
        solver="adam",
        alpha=1e-4,                         # L2 regularisation
        learning_rate_init=1e-3,
        max_iter=200,
        random_state=42,
        verbose=False,
        early_stopping=True,
        validation_fraction=0.1,
        n_iter_no_change=15,
    )
    # Encoder: train to predict bottleneck from full features
    # We use PCA initialisation for the bottleneck targets
    from sklearn.decomposition import PCA
    pca   = PCA(n_components=BOTTLENECK_DIM, random_state=42)
    Z_train = pca.fit_transform(X_train)    # Initial bottleneck targets
    encoder.fit(X_train, Z_train)
    Z_train_enc = encoder.predict(X_train)  # Actual encoder output
    logger.info(f"  Encoder trained. Train R²={encoder.score(X_train, Z_train):.4f}")

    # ── Train Decoder: BOTTLENECK_DIM → 16 → FEAT_DIM ──────────────────
    logger.info("Training Decoder (6 → 16 → 20)...")
    decoder = MLPRegressor(
        hidden_layer_sizes=(16,),
        activation="tanh",
        solver="adam",
        alpha=1e-4,
        learning_rate_init=1e-3,
        max_iter=300,
        random_state=42,
        verbose=False,
        early_stopping=True,
        validation_fraction=0.1,
        n_iter_no_change=15,
    )
    # Decoder: train to reconstruct original from bottleneck
    decoder.fit(Z_train_enc, X_train)
    logger.info(f"  Decoder trained. Train R²={decoder.score(Z_train_enc, X_train):.4f}")

    # ── Evaluate reconstruction error on validation set ─────────────────
    logger.info("\nComputing reconstruction errors...")
    Z_val   = encoder.predict(X_val)
    X_recon = decoder.predict(Z_val)

    # Per-sample MSE
    errors = np.mean((X_val - X_recon) ** 2, axis=1)

    logger.info(f"  Val MSE — mean: {errors.mean():.6f}  std: {errors.std():.6f}")
    logger.info(f"  Val MSE — 50th: {np.percentile(errors,50):.6f}")
    logger.info(f"  Val MSE — 90th: {np.percentile(errors,90):.6f}")
    logger.info(f"  Val MSE — 95th: {np.percentile(errors,95):.6f}  ← threshold")
    logger.info(f"  Val MSE — 99th: {np.percentile(errors,99):.6f}")

    threshold = float(np.percentile(errors, 95))

    # Also check: what score do manipulation days get?
    # Load full dataset including manipulation days for comparison
    logger.info("\nChecking anomaly score separation...")
    manip_rows = []
    for symbol, raw_df in all_data.items():
        if raw_df is None: continue
        df = label_dataframe(raw_df, symbol).sort_index()
        for i in range(WINDOW + 1, len(df)):
            if df.iloc[i]["label"] != 1: continue
            hist = [
                {"price": float(df.iloc[j]["close"]), "volume": int(df.iloc[j]["volume"]),
                 "high": float(df.iloc[j].get("high", df.iloc[j]["close"])),
                 "low":  float(df.iloc[j].get("low",  df.iloc[j]["close"]))}
                for j in range(max(0, i-WINDOW-1), i)
            ]
            row = df.iloc[i]
            feats = extract_features(float(row["close"]), int(row["volume"]),
                                      float(row.get("high", row["close"])),
                                      float(row.get("low",  row["close"])), hist)
            if feats is not None:
                manip_rows.append(feats.flatten())

    if manip_rows:
        X_manip  = scaler.transform(np.array(manip_rows, dtype=np.float32))
        Z_manip  = encoder.predict(X_manip)
        Xr_manip = decoder.predict(Z_manip)
        manip_errors = np.mean((X_manip - Xr_manip) ** 2, axis=1)
        logger.info(f"  Normal errors (val):      mean={errors.mean():.4f}")
        logger.info(f"  Manipulation errors:       mean={manip_errors.mean():.4f}")
        logger.info(f"  Separation ratio: {manip_errors.mean() / errors.mean():.2f}x")
        logger.info(f"  (>1.5x = good separation, >2x = excellent)")

    # ── Save everything ─────────────────────────────────────────────────
    joblib.dump(encoder,   MODELS_DIR / "vanilla_ae_encoder.pkl")
    joblib.dump(decoder,   MODELS_DIR / "vanilla_ae_decoder.pkl")
    joblib.dump(scaler,    MODELS_DIR / "vanilla_ae_scaler.pkl")
    joblib.dump(threshold, MODELS_DIR / "vanilla_ae_threshold.pkl")

    logger.info("\n✅ Vanilla Autoencoder saved:")
    logger.info(f"   models/vanilla_ae_encoder.pkl")
    logger.info(f"   models/vanilla_ae_decoder.pkl")
    logger.info(f"   models/vanilla_ae_scaler.pkl")
    logger.info(f"   models/vanilla_ae_threshold.pkl  (threshold={threshold:.6f})")
    logger.info("\nNext: uvicorn main:app --port 8000 --reload")


if __name__ == "__main__":
    train()
