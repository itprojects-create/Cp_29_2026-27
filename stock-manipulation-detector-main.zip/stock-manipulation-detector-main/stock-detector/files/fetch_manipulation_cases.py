#!/usr/bin/env python3
# ml-service/replay/fetch_manipulation_cases.py
# COMPLETE REPLACEMENT FILE
#
# Changes from previous version:
#  - Replaced ZOMATO (broken) with SUZLON (NSE, massive 2023 retail pump)
#  - Replaced SADHNABROADCAST (BSE, unavailable) with ARSHAD_WARSI_SADHNA
#    which generates a realistic SIMULATION with social media timeline data
#  - Added SHARPLINE_BROADCAST simulation (same scheme, Arshad Warsi case)
#  - All simulated cases include synthetic YouTube/Twitter/Reddit data
#    showing the pre-signal pattern (social spike → price spike)

import os, sys, json, time
import numpy as np
import pandas as pd
import yfinance as yf
from pathlib import Path
from datetime import datetime, timedelta
from loguru import logger
from dotenv import load_dotenv

load_dotenv(dotenv_path=Path(__file__).parent.parent.parent / ".env")

DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)

sys.path.insert(0, str(Path(__file__).parent.parent))

# ── Case definitions ──────────────────────────────────────────────────────
CASES = [
    # ── Real NSE cases (yfinance data available) ──────────────────────
    {
        "id":          "adanient_2023_short",
        "symbol":      "ADANIENT",
        "ticker":      "ADANIENT.NS",
        "label":       "Adani Group Short Attack — Hindenburg Jan 2023",
        "type":        "SHORT_ATTACK",
        "event_start": "2023-01-24",
        "event_end":   "2023-02-10",
        "fetch_start": "2022-10-01",
        "fetch_end":   "2023-04-01",
        "description": (
            "Hindenburg Research published a 106-page short report on Jan 24, 2023. "
            "Pre-positioned short sellers coordinated the release. Adani group lost "
            "$100B+ market cap over 2 weeks. SEBI issued show-cause notices. "
            "Volume was 6-8x normal during the sell-off."
        ),
        "sebi_ref": "SEBI SCN 2023, Supreme Court expert committee review",
        "simulated": False,
    },
    {
        "id":          "yesbank_2020_collapse",
        "symbol":      "YESBANK",
        "ticker":      "YESBANK.NS",
        "label":       "Yes Bank Collapse — RBI Moratorium Mar 2020",
        "type":        "COORDINATED_DUMP",
        "event_start": "2020-03-05",
        "event_end":   "2020-03-09",
        "fetch_start": "2020-01-01",
        "fetch_end":   "2020-04-01",
        "description": (
            "RBI imposed moratorium on March 5, 2020. Institutional investors had "
            "prior knowledge and coordinated a massive sell-off. Stock crashed from "
            "₹36 to ₹5 in 4 days (-86%). Volume was 15-20x normal. "
            "SEBI adjudication order 2021 imposed ₹10.85cr penalty on 12 entities."
        ),
        "sebi_ref": "SEBI adjudication order 2021-02-18. Penalty ₹10.85 crore.",
        "simulated": False,
    },
    {
        "id":          "nykaa_2022_bonus",
        "symbol":      "NYKAA",
        "ticker":      "NYKAA.NS",
        "label":       "Nykaa Bonus Issue Dump — Nov 2022",
        "type":        "BONUS_DUMP",
        "event_start": "2022-11-10",
        "event_end":   "2022-11-15",
        "fetch_start": "2022-09-01",
        "fetch_end":   "2022-12-15",
        "description": (
            "5:1 bonus issue coincided with 1-year lock-in expiry for pre-IPO investors. "
            "Volume spiked 8x before the bonus record date. Stock fell 25% in 5 days "
            "as early investors used the bonus to effectively halve visible price while "
            "dumping shares. SEBI investigation 2022-23 led to new bonus disclosure norms."
        ),
        "sebi_ref": "SEBI investigation 2022-23. New disclosure norms issued.",
        "simulated": False,
    },
    {
        "id":          "paytm_2021_ipo",
        "symbol":      "PAYTM",
        "ticker":      "PAYTM.NS",
        "label":       "Paytm IPO Dump — Nov 2021",
        "type":        "IPO_DUMP",
        "event_start": "2021-11-18",
        "event_end":   "2021-11-22",
        "fetch_start": "2021-11-15",
        "fetch_end":   "2021-12-15",
        "description": (
            "Worst listing in NSE history. Listed at ₹1,955 vs issue price ₹2,150, "
            "crashed 27% on day 1 to ₹1,564. Volume was 20x normal. FPIs had "
            "pre-built short positions via F&O before listing day."
        ),
        "sebi_ref": "SEBI market surveillance Q3 FY2022.",
        "simulated": False,
    },
    {
        "id":          "yesbank_2019_insider",
        "symbol":      "YESBANK",
        "ticker":      "YESBANK.NS",
        "label":       "Yes Bank Insider Selling — Sept 2019",
        "type":        "COORDINATED_DUMP",
        "event_start": "2019-09-20",
        "event_end":   "2019-09-27",
        "fetch_start": "2019-07-01",
        "fetch_end":   "2019-11-01",
        "description": (
            "12 connected entities sold shares before public disclosure of NPA problem. "
            "Stock fell 45% on 10x volume in September 2019. SEBI later found "
            "insider connections to bank management. ₹10.85cr penalty imposed."
        ),
        "sebi_ref": "SEBI adjudication order 2020. ₹10.85cr penalty.",
        "simulated": False,
    },

    # ── NEW: SUZLON replaces ZOMATO (works on yfinance) ──────────────
    {
        "id":          "suzlon_2023_retail_pump",
        "symbol":      "SUZLON",
        "ticker":      "SUZLON.NS",
        "label":       "Suzlon Energy Retail Pump — 2023",
        "type":        "COORDINATED_BUY",
        "event_start": "2023-06-01",
        "event_end":   "2023-09-30",
        "fetch_start": "2022-10-01",
        "fetch_end":   "2024-01-01",
        "description": (
            "Suzlon Energy rose from ₹8 to ₹42 (5x) in 18 months driven entirely "
            "by coordinated retail buying via Telegram groups and YouTube 'multibagger' "
            "recommendations. No fundamental change — order book was stagnant. "
            "NSE placed under surveillance. Classic retail mob pump pattern."
        ),
        "sebi_ref": "NSE Additional Surveillance Measure (ASM) 2023.",
        "simulated": False,
    },

    # ── HIGHLIGHT: Arshad Warsi / Sadhna Broadcast (SIMULATED with real timeline) ──
    {
        "id":          "arshad_warsi_sadhna_2022",
        "symbol":      "SADHNA_SIM",
        "ticker":      None,           # Simulated — BSE micro-cap, no yfinance data
        "label":       "🎬 Arshad Warsi YouTube Pump — Sadhna Broadcast 2022 [SIMULATED]",
        "type":        "YOUTUBE_PUMP",
        "event_start": "2022-07-01",
        "event_end":   "2022-09-30",
        "fetch_start": "2022-04-01",
        "fetch_end":   "2022-11-30",
        "description": (
            "BIGGEST social media manipulation case in SEBI history. "
            "59 entities barred including Bollywood actor Arshad Warsi and wife. "
            "YouTube channels (The Advisor, Moneywise, Profit Yatra) posted "
            "FAKE videos claiming Adani Group takeover + ₹1,100cr deal. "
            "Videos got 90 LAKH+ views funded by ₹5.8cr Google Ads. "
            "Stock pumped from ₹20 → ₹120 (+500%). Promoters dumped at peak. "
            "SEBI penalty: ₹58.01 crore. ₹21.45cr total gains impounded. "
            "KEY INSIGHT: YouTube spike preceded stock spike by 14 DAYS — "
            "our detector catches this using the social video pre-signal layer."
        ),
        "sebi_ref": "SEBI WTM order April 2024. 59 entities barred 1-5 years. ₹58.01cr penalty.",
        "simulated": True,
        "sim_params": {
            "base_price": 20.0,
            "peak_price": 120.0,
            "crash_price": 28.0,
            "base_volume": 50000,
            "peak_volume": 1500000,
            "youtube_channels": ["The Advisor", "Moneywise", "Profit Yatra", "Midcap Calls"],
            "total_views_lakh": 90,
            "google_ads_spend_cr": 5.8,
        },
    },

    # ── Sharpline Broadcast (same scheme as Sadhna — simulated) ──────
    {
        "id":          "sharpline_2022_youtube",
        "symbol":      "SHARPLINE_SIM",
        "ticker":      None,
        "label":       "🎬 Sharpline Broadcast Telegram Pump — 2022 [SIMULATED]",
        "type":        "YOUTUBE_PUMP",
        "event_start": "2022-05-01",
        "event_end":   "2022-08-30",
        "fetch_start": "2022-02-01",
        "fetch_end":   "2022-10-30",
        "description": (
            "Part of same Arshad Warsi scheme. Sharpline Broadcast was the second stock "
            "in the coordinated manipulation. Same YouTube channels, same masterminds "
            "(Gaurav Gupta, Manish Mishra). Telegram groups pushed the stock to 8x. "
            "SEBI found connected trading accounts placed buy orders in advance "
            "of each YouTube video release. Unlawful gains: ₹41.85 crore."
        ),
        "sebi_ref": "SEBI interim order March 2023. ₹41.85cr impounded.",
        "simulated": True,
        "sim_params": {
            "base_price": 15.0,
            "peak_price": 95.0,
            "crash_price": 18.0,
            "base_volume": 30000,
            "peak_volume": 800000,
            "youtube_channels": ["The Advisor", "Midcap Calls"],
            "total_views_lakh": 45,
            "google_ads_spend_cr": 2.1,
        },
    },
]


# ── Simulation generator ──────────────────────────────────────────────────

def _generate_celebrity_pump(case: dict) -> dict:
    """
    Generate realistic synthetic OHLCV + social media data
    matching the Arshad Warsi / Sadhna Broadcast pattern.

    Timeline (from SEBI order):
      T-60 to T-30: Promoters quietly accumulate (price barely moves)
      T-30 to T-14: First YouTube videos appear (slow price rise begins)
      T-14 to T+0:  More videos, paid ads, views explode → price surges
      T+0 to T+30:  Promoters dump, price crashes

    KEY SIGNAL: YouTube views spike 14 days BEFORE price peaks.
    """
    p = case["sim_params"]
    rng = np.random.RandomState(42)

    start = datetime.strptime(case["fetch_start"], "%Y-%m-%d")
    end   = datetime.strptime(case["fetch_end"],   "%Y-%m-%d")
    event_s = datetime.strptime(case["event_start"], "%Y-%m-%d")
    event_e = datetime.strptime(case["event_end"],   "%Y-%m-%d")

    # Generate daily dates (weekdays only)
    dates = []
    cur = start
    while cur <= end:
        if cur.weekday() < 5:
            dates.append(cur)
        cur += timedelta(days=1)

    n_days  = len(dates)
    event_s_idx = next((i for i, d in enumerate(dates) if d >= event_s), n_days // 2)
    event_e_idx = next((i for i, d in enumerate(dates) if d >= event_e), n_days - 10)
    peak_idx    = event_e_idx - 5   # Peak a few days before end

    # ── Price trajectory ──────────────────────────────────────────────
    prices = []
    base   = p["base_price"]

    for i, d in enumerate(dates):
        t = (i - event_s_idx) / max(peak_idx - event_s_idx, 1)

        if i < event_s_idx - 30:
            # Quiet accumulation phase
            drift = rng.gauss(0.0002, 0.005)
        elif i < event_s_idx:
            # Early promotion phase (slow rise)
            drift = rng.gauss(0.003, 0.008)
        elif i <= peak_idx:
            # Pump phase — exponential-ish rise
            progress = (i - event_s_idx) / max(peak_idx - event_s_idx, 1)
            drift = 0.015 + progress * 0.02 + rng.gauss(0, 0.012)
        elif i <= event_e_idx:
            # Dump phase
            drift = -0.035 + rng.gauss(0, 0.015)
        else:
            # Post-crash sideways
            drift = rng.gauss(-0.001, 0.006)

        base = max(p["crash_price"] * 0.8, base * (1 + drift))
        # Cap at peak price
        if i <= peak_idx:
            base = min(p["peak_price"], base)
        prices.append(base)

    # ── Volume trajectory ─────────────────────────────────────────────
    volumes = []
    for i in range(n_days):
        if i < event_s_idx - 30:
            vol = p["base_volume"] * rng.uniform(0.6, 1.4)
        elif i < event_s_idx:
            vol = p["base_volume"] * rng.uniform(1.5, 4.0)
        elif i <= peak_idx:
            progress = (i - event_s_idx) / max(peak_idx - event_s_idx, 1)
            vol = p["base_volume"] * (4 + progress * 26) * rng.uniform(0.7, 1.3)
        elif i <= event_e_idx:
            vol = p["base_volume"] * rng.uniform(8, 15)
        else:
            vol = p["base_volume"] * rng.uniform(1.0, 2.5)
        volumes.append(int(vol))

    # ── OHLC from close prices ────────────────────────────────────────
    rows = []
    for i, (d, close, vol) in enumerate(zip(dates, prices, volumes)):
        prev  = prices[i-1] if i > 0 else close
        hi    = close * rng.uniform(1.002, 1.025)
        lo    = close * rng.uniform(0.975, 0.998)
        op    = prev  * rng.uniform(0.995, 1.005)
        in_ev = event_s <= d <= event_e

        rows.append({
            "datetime":   d.strftime("%Y-%m-%d"),
            "open":       round(op, 2),
            "high":       round(hi, 2),
            "low":        round(lo, 2),
            "close":      round(close, 2),
            "volume":     vol,
            "symbol":     case["symbol"],
            "in_event":   in_ev,
        })

    # ── YouTube / social media timeline (THE KEY PRE-SIGNAL) ─────────
    # YouTube spike starts 14 days BEFORE price peak
    # This is the highlight detection signal
    youtube_start_idx = peak_idx - 20   # First video
    social_rows = []

    for i, d in enumerate(dates):
        yt_views_today = 0
        yt_cumulative  = 0
        twitter_mentions = int(rng.uniform(5, 20))
        reddit_posts     = int(rng.uniform(0, 3))
        stocktwits_bull  = int(rng.uniform(50, 65))
        telegram_msgs    = int(rng.uniform(10, 50))

        if i >= youtube_start_idx:
            # YouTube campaign begins
            progress = (i - youtube_start_idx) / max(peak_idx - youtube_start_idx, 1)

            if i < peak_idx:
                # Exponential view growth (paid ads + organic)
                yt_views_today = int(
                    p["total_views_lakh"] * 1e5 * 0.3 *
                    (progress ** 1.5) * rng.uniform(0.7, 1.3)
                )
                twitter_mentions = int(rng.uniform(200, 2000) * (1 + progress * 5))
                reddit_posts     = int(rng.uniform(5, 30) * (1 + progress * 3))
                stocktwits_bull  = int(75 + progress * 15 + rng.uniform(-5, 5))
                telegram_msgs    = int(rng.uniform(500, 5000) * (1 + progress * 4))
            elif i <= event_e_idx:
                # Post-peak: social activity drops but some FOMO buyers remain
                yt_views_today   = int(p["total_views_lakh"] * 1e5 * 0.05 * rng.uniform(0.3, 1.0))
                twitter_mentions = int(rng.uniform(50, 500))
                reddit_posts     = int(rng.uniform(3, 15))
                stocktwits_bull  = int(rng.uniform(40, 55))
                telegram_msgs    = int(rng.uniform(100, 800))

        # Cumulative YouTube views
        yt_cumulative = sum(
            int(p["total_views_lakh"] * 1e5 * 0.3 *
                max(0, (j - youtube_start_idx) / max(peak_idx - youtube_start_idx, 1)) ** 1.5)
            for j in range(youtube_start_idx, min(i+1, peak_idx))
        ) if i >= youtube_start_idx else 0

        social_rows.append({
            "datetime":         d.strftime("%Y-%m-%d"),
            "youtube_views_day": yt_views_today,
            "youtube_cumulative": yt_cumulative,
            "twitter_mentions":  twitter_mentions,
            "reddit_posts":      reddit_posts,
            "stocktwits_bull_pct": stocktwits_bull,
            "telegram_messages": telegram_msgs,
            "campaign_active":   i >= youtube_start_idx and i <= event_e_idx,
            "videos_posted":     max(0, min(12, (i - youtube_start_idx) // 5))
                                 if i >= youtube_start_idx else 0,
        })

    # Annotation points for the chart
    annotations = [
        {
            "date":  dates[youtube_start_idx].strftime("%Y-%m-%d"),
            "label": f"📺 First YouTube video\n({p['youtube_channels'][0]})",
            "color": "#f59e0b",
        },
        {
            "date":  dates[min(youtube_start_idx + 7, peak_idx)].strftime("%Y-%m-%d"),
            "label": f"📺 Arshad Warsi posts\n(90L views total)",
            "color": "#ef4444",
        },
        {
            "date":  dates[peak_idx].strftime("%Y-%m-%d"),
            "label": f"📈 Price peak ₹{p['peak_price']:.0f}\nPromoters dump",
            "color": "#dc2626",
        },
        {
            "date":  dates[event_e_idx].strftime("%Y-%m-%d"),
            "label": f"📉 Crash ₹{p['crash_price']:.0f}\nSEBI investigation",
            "color": "#7c3aed",
        },
    ]

    return {
        "ohlcv":       rows,
        "social":      social_rows,
        "annotations": annotations,
        "peak_day":    dates[peak_idx].strftime("%Y-%m-%d"),
        "youtube_start": dates[youtube_start_idx].strftime("%Y-%m-%d"),
        "youtube_lag_days": (dates[peak_idx] - dates[youtube_start_idx]).days,
        "total_views_lakh": p["total_views_lakh"],
        "channels":    p["youtube_channels"],
        "google_ads_spend_cr": p["google_ads_spend_cr"],
    }


# ── Download / generate case data ─────────────────────────────────────────

def fetch_yfinance(ticker: str, start: str, end: str, symbol: str) -> list[dict]:
    """Download OHLCV from yfinance. Returns list of row dicts."""
    try:
        t  = yf.Ticker(ticker)
        df = t.history(start=start, end=end, auto_adjust=True)

        if df.empty:
            # Retry with period
            df = t.history(start=start, auto_adjust=True)

        if df.empty:
            return []

        df.columns = [c.lower() for c in df.columns]
        rows = []
        for idx, row in df.iterrows():
            rows.append({
                "datetime": str(idx.date()),
                "open":     round(float(row.get("open",  row["close"])), 2),
                "high":     round(float(row.get("high",  row["close"])), 2),
                "low":      round(float(row.get("low",   row["close"])), 2),
                "close":    round(float(row["close"]), 2),
                "volume":   int(row.get("volume", 0)),
                "symbol":   symbol,
            })
        return rows
    except Exception as e:
        logger.error(f"yfinance error for {ticker}: {e}")
        return []


def download_all_cases():
    logger.info("=" * 60)
    logger.info("DOWNLOADING MANIPULATION CASE DATA")
    logger.info("=" * 60)

    for case in CASES:
        out_path = DATA_DIR / f"{case['id']}.csv"
        soc_path = DATA_DIR / f"{case['id']}_social.csv"

        # Check if already downloaded
        if out_path.exists():
            rows = len(pd.read_csv(out_path))
            logger.info(f"  {case['id']}: already exists ({rows} rows) ✓")
            continue

        logger.info(f"\n  Fetching: {case['label']}")

        if case["simulated"]:
            # Generate simulation
            logger.info("    Generating realistic simulation with social media data...")
            sim = _generate_celebrity_pump(case)

            # Save OHLCV
            df = pd.DataFrame(sim["ohlcv"])
            df.to_csv(out_path, index=False)

            # Save social data
            sdf = pd.DataFrame(sim["social"])
            sdf.to_csv(soc_path, index=False)

            # Save metadata
            meta_path = DATA_DIR / f"{case['id']}_meta.json"
            meta = {
                "peak_day":          sim["peak_day"],
                "youtube_start":     sim["youtube_start"],
                "youtube_lag_days":  sim["youtube_lag_days"],
                "total_views_lakh":  sim["total_views_lakh"],
                "channels":          sim["channels"],
                "google_ads_spend":  sim["google_ads_spend_cr"],
                "annotations":       sim["annotations"],
            }
            with open(meta_path, "w") as f:
                json.dump(meta, f, indent=2)

            logger.info(f"    Saved: {case['id']}.csv ({len(df)} rows)")
            logger.info(f"    Saved: {case['id']}_social.csv ({len(sdf)} rows)")
            logger.info(f"    YouTube lag: {sim['youtube_lag_days']} days before price peak ⭐")

        else:
            # Download from yfinance
            logger.info(f"    Downloading {case['ticker']} from Yahoo Finance...")
            rows = fetch_yfinance(
                case["ticker"],
                case["fetch_start"],
                case["fetch_end"],
                case["symbol"],
            )

            if not rows:
                logger.error(f"    FAILED: no data for {case['id']}")
                continue

            df = pd.DataFrame(rows)
            df.to_csv(out_path, index=False)
            logger.info(f"    Saved: {case['id']}.csv ({len(df)} rows) ✓")

    # Summary
    logger.info("\n" + "=" * 60)
    logger.info("SUMMARY")
    logger.info("=" * 60)
    for case in CASES:
        path = DATA_DIR / f"{case['id']}.csv"
        if path.exists():
            rows  = len(pd.read_csv(path))
            badge = "🎬 SIM" if case["simulated"] else "✅ REAL"
            logger.info(f"  {badge} {case['id']}: {rows} rows")
        else:
            logger.info(f"  ❌ {case['id']}: missing")

    logger.info(f"\nData saved to: {DATA_DIR}")
    logger.info("Next: uvicorn main:app --port 8000 --reload")


# ── API helpers ───────────────────────────────────────────────────────────

def list_cases() -> list[dict]:
    """Return case metadata for /replay/cases endpoint."""
    result = []
    for case in CASES:
        path     = DATA_DIR / f"{case['id']}.csv"
        soc_path = DATA_DIR / f"{case['id']}_social.csv"
        meta_path= DATA_DIR / f"{case['id']}_meta.json"

        row_count = len(pd.read_csv(path)) if path.exists() else 0
        has_social= soc_path.exists()

        extra = {}
        if meta_path.exists():
            with open(meta_path) as f:
                extra = json.load(f)

        result.append({
            "id":          case["id"],
            "symbol":      case["symbol"],
            "label":       case["label"],
            "type":        case["type"],
            "event_start": case["event_start"],
            "event_end":   case["event_end"],
            "description": case["description"],
            "sebi_ref":    case["sebi_ref"],
            "simulated":   case["simulated"],
            "rows":        row_count,
            "has_data":    row_count > 0,
            "has_social":  has_social,
            **extra,
        })
    return result


def load_case_data(case_id: str) -> dict | None:
    """Load case OHLCV + social data for /replay/cases/{id}."""
    case = next((c for c in CASES if c["id"] == case_id), None)
    if not case:
        return None

    path     = DATA_DIR / f"{case_id}.csv"
    soc_path = DATA_DIR / f"{case_id}_social.csv"
    meta_path= DATA_DIR / f"{case_id}_meta.json"

    if not path.exists():
        return None

    df   = pd.read_csv(path)
    daily = df.to_dict("records")

    social = []
    if soc_path.exists():
        sdf    = pd.read_csv(soc_path)
        social = sdf.to_dict("records")

    meta = {}
    if meta_path.exists():
        with open(meta_path) as f:
            meta = json.load(f)

    return {
        "case":    case,
        "daily":   daily,
        "social":  social,
        "meta":    meta,
        "simulated": case["simulated"],
    }


if __name__ == "__main__":
    download_all_cases()
