// src/pages/ReplayPage.jsx
// Shows historical confirmed manipulation cases.
// For each case: OHLCV chart with manipulation window highlighted,
// ML anomaly scores overlaid, detection stats, and case narrative.
import React, { useState, useEffect, useRef, useCallback } from "react";
import axios from "axios";

const API = import.meta.env.VITE_SERVER_URL || "http://localhost:3001";
const ML = "http://localhost:8000";

const C = {
  bg: "#f5f4f0",
  surface: "#ffffff",
  border: "#e8e7e3",
  text: "#1a1a18",
  muted: "#888884",
  faint: "#b8b7b3",
  green: "#16a34a",
  red: "#dc2626",
  amber: "#d97706",
  blue: "#2563eb",
  purple: "#7c3aed",
  teal: "#0d9488",
};

const TYPE_CONFIG = {
  SHORT_ATTACK: { color: C.red, label: "Short Attack", bg: "#fef2f2" },
  IPO_PUMP: { color: C.amber, label: "IPO Pump", bg: "#fffbeb" },
  IPO_DUMP: { color: C.purple, label: "IPO Dump", bg: "#faf5ff" },
  BONUS_DUMP: { color: C.teal, label: "Bonus Dump", bg: "#f0fdfa" },
  COORDINATED_DUMP: { color: C.red, label: "Coordinated Dump", bg: "#fef2f2" },
  COORDINATED_BUY: { color: C.amber, label: "Coordinated Buy", bg: "#fffbeb" },
};

// ── Score Chart (Canvas) ──────────────────────────────────────────────────
function ReplayChart({ candles, scores, meta }) {
  const canvasRef = useRef(null);
  const [hover, setHover] = useState(null);

  const draw = useCallback(
    (hoverX) => {
      const canvas = canvasRef.current;
      if (!canvas || !candles?.length) return;
      const ctx = canvas.getContext("2d");
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      if (canvas.width !== rect.width * dpr) {
        canvas.width = rect.width * dpr;
        canvas.height = rect.height * dpr;
        ctx.scale(dpr, dpr);
      }
      const W = rect.width,
        H = rect.height;

      ctx.clearRect(0, 0, W, H);

      const priceData = scores?.length ? scores : candles;
      if (priceData.length < 2) return;

      const prices = priceData.map((d) => d.close);
      const minP = Math.min(...prices) * 0.99;
      const maxP = Math.max(...prices) * 1.01;
      const rangeP = maxP - minP || 1;

      const PAD_L = 56,
        PAD_R = 10,
        PAD_T = 12,
        PAD_B = 38;
      const W2 = W - PAD_L - PAD_R;
      const H2 = H - PAD_T - PAD_B;

      const toX = (i) => PAD_L + (i / (priceData.length - 1)) * W2;
      const toY = (p) => PAD_T + (1 - (p - minP) / rangeP) * H2 * 0.7;

      // Event window highlight
      if (meta) {
        const es = new Date(meta.event_start);
        const ee = new Date(meta.event_end);
        let x1 = W,
          x2 = 0;
        priceData.forEach((d, i) => {
          const dt = new Date(d.datetime);
          if (dt >= es && dt <= ee) {
            x1 = Math.min(x1, toX(i));
            x2 = Math.max(x2, toX(i));
          }
        });
        if (x1 < x2) {
          ctx.fillStyle = "#dc262612";
          ctx.fillRect(x1, PAD_T, x2 - x1, H2 * 0.7);
          ctx.fillStyle = "#dc2626";
          ctx.font = "9px IBM Plex Mono";
          ctx.textAlign = "center";
          ctx.fillText("MANIPULATION WINDOW", (x1 + x2) / 2, PAD_T - 2);
          ctx.strokeStyle = "#dc262644";
          ctx.lineWidth = 0.5;
          ctx.beginPath();
          ctx.moveTo(x1, PAD_T);
          ctx.lineTo(x1, PAD_T + H2 * 0.7);
          ctx.moveTo(x2, PAD_T);
          ctx.lineTo(x2, PAD_T + H2 * 0.7);
          ctx.stroke();
        }
      }

      // Alert fired markers (red dots above price)
      if (scores) {
        scores.forEach((s, i) => {
          if (s.alert_fired) {
            const x = toX(i),
              y = toY(s.close);
            ctx.beginPath();
            ctx.arc(x, y - 8, 4, 0, Math.PI * 2);
            ctx.fillStyle = C.red;
            ctx.fill();
          }
        });
      }

      // Grid
      ctx.strokeStyle = "#f0efeb";
      ctx.lineWidth = 0.5;
      for (let i = 0; i <= 4; i++) {
        const y = PAD_T + (H2 * 0.7 * i) / 4;
        ctx.beginPath();
        ctx.moveTo(PAD_L, y);
        ctx.lineTo(W - PAD_R, y);
        ctx.stroke();
        const pv = maxP - (rangeP * i) / 4;
        ctx.fillStyle = C.faint;
        ctx.font = "9px IBM Plex Mono";
        ctx.textAlign = "right";
        ctx.fillText(`₹${pv.toFixed(0)}`, PAD_L - 4, y + 3);
      }

      // Price fill
      const grad = ctx.createLinearGradient(0, toY(maxP), 0, toY(minP));
      grad.addColorStop(0, "#2563eb14");
      grad.addColorStop(1, "#2563eb02");
      ctx.beginPath();
      priceData.forEach((d, i) => {
        i === 0
          ? ctx.moveTo(toX(i), toY(d.close))
          : ctx.lineTo(toX(i), toY(d.close));
      });
      ctx.lineTo(toX(priceData.length - 1), PAD_T + H2 * 0.7);
      ctx.lineTo(PAD_L, PAD_T + H2 * 0.7);
      ctx.closePath();
      ctx.fillStyle = grad;
      ctx.fill();

      // Price line
      ctx.beginPath();
      ctx.strokeStyle = C.blue;
      ctx.lineWidth = 1.5;
      ctx.lineJoin = "round";
      priceData.forEach((d, i) => {
        i === 0
          ? ctx.moveTo(toX(i), toY(d.close))
          : ctx.lineTo(toX(i), toY(d.close));
      });
      ctx.stroke();

      // Anomaly score line (bottom section)
      if (scores?.length) {
        const scoreBaseline = PAD_T + H2 * 0.76;
        const scoreH = H2 * 0.2;

        ctx.fillStyle = "#f8f7f3";
        ctx.fillRect(PAD_L, scoreBaseline, W2, scoreH);
        ctx.strokeStyle = C.border;
        ctx.lineWidth = 0.5;
        ctx.strokeRect(PAD_L, scoreBaseline, W2, scoreH);

        // 0.55 alert threshold line
        const threshY = scoreBaseline + scoreH * (1 - 0.55);
        ctx.beginPath();
        ctx.strokeStyle = C.amber + "80";
        ctx.lineWidth = 0.5;
        ctx.setLineDash([3, 3]);
        ctx.moveTo(PAD_L, threshY);
        ctx.lineTo(W - PAD_R, threshY);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = C.amber;
        ctx.font = "8px IBM Plex Mono";
        ctx.textAlign = "right";
        ctx.fillText("0.55", PAD_L - 3, threshY + 3);

        ctx.beginPath();
        scores.forEach((s, i) => {
          const sx = toX(i);
          const sy = scoreBaseline + scoreH * (1 - s.ensemble_score);
          i === 0 ? ctx.moveTo(sx, sy) : ctx.lineTo(sx, sy);
        });
        ctx.strokeStyle = C.red;
        ctx.lineWidth = 1.2;
        ctx.lineJoin = "round";
        ctx.stroke();

        ctx.fillStyle = C.faint;
        ctx.font = "8px IBM Plex Mono";
        ctx.textAlign = "left";
        ctx.fillText("ANOMALY SCORE", PAD_L + 4, scoreBaseline + 9);
      }

      // Date labels on X axis
      const step = Math.max(1, Math.floor(priceData.length / 6));
      ctx.fillStyle = C.faint;
      ctx.font = "9px IBM Plex Mono";
      ctx.textAlign = "center";
      for (let i = 0; i < priceData.length; i += step) {
        const dt = new Date(priceData[i].datetime);
        const label = dt.toLocaleDateString("en-IN", {
          day: "2-digit",
          month: "short",
        });
        ctx.fillText(label, toX(i), H - PAD_B + 14);
      }

      // Crosshair
      if (hoverX !== null && hoverX >= PAD_L && hoverX <= W - PAD_R) {
        const idx = Math.round(
          ((hoverX - PAD_L) / W2) * (priceData.length - 1),
        );
        const ci = Math.max(0, Math.min(priceData.length - 1, idx));
        const cx = toX(ci),
          cy = toY(priceData[ci].close);
        ctx.beginPath();
        ctx.strokeStyle = "#c0bfbb";
        ctx.lineWidth = 0.5;
        ctx.setLineDash([3, 3]);
        ctx.moveTo(cx, PAD_T);
        ctx.lineTo(cx, PAD_T + H2 * 0.7);
        ctx.moveTo(PAD_L, cy);
        ctx.lineTo(W - PAD_R, cy);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.beginPath();
        ctx.arc(cx, cy, 3.5, 0, Math.PI * 2);
        ctx.fillStyle = C.blue;
        ctx.fill();
        ctx.strokeStyle = "#fff";
        ctx.lineWidth = 1.5;
        ctx.stroke();
        setHover({ idx: ci, data: priceData[ci] });
      } else {
        setHover(null);
      }
    },
    [candles, scores, meta],
  );

  useEffect(() => {
    draw(null);
  }, [draw]);

  return (
    <div style={{ position: "relative" }}>
      {hover && (
        <div
          style={{
            position: "absolute",
            top: 8,
            right: 12,
            background: "#fff",
            border: `1px solid ${C.border}`,
            borderRadius: 6,
            padding: "6px 10px",
            fontSize: 11,
            fontFamily: "'IBM Plex Mono',monospace",
            lineHeight: 1.6,
            zIndex: 10,
            pointerEvents: "none",
            boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
          }}
        >
          <div style={{ color: C.text, fontWeight: 500 }}>
            ₹{Number(hover.data.close).toFixed(2)}
          </div>
          <div style={{ color: C.muted }}>
            {hover.data.volume
              ? `${(hover.data.volume / 1e6).toFixed(2)}M vol`
              : ""}
          </div>
          {hover.data.ensemble_score !== undefined && (
            <div style={{ color: hover.data.alert_fired ? C.red : C.muted }}>
              score: {(hover.data.ensemble_score * 100).toFixed(0)}%
              {hover.data.alert_fired ? " ⚠ ALERT" : ""}
            </div>
          )}
        </div>
      )}
      <canvas
        ref={canvasRef}
        style={{
          width: "100%",
          height: 320,
          display: "block",
          cursor: "crosshair",
        }}
        onMouseMove={(e) => {
          const rect = canvasRef.current?.getBoundingClientRect();
          if (rect) draw(e.clientX - rect.left);
        }}
        onMouseLeave={() => {
          setHover(null);
          draw(null);
        }}
      />
    </div>
  );
}

// ── Case Card ─────────────────────────────────────────────────────────────
function CaseCard({ meta, selected, onClick }) {
  const cfg = TYPE_CONFIG[meta.type] || {
    color: C.muted,
    label: meta.type,
    bg: "#f9f9f9",
  };
  const downloaded = meta.rows > 0;

  return (
    <div
      onClick={onClick}
      style={{
        padding: "12px 14px",
        borderRadius: 8,
        border: `1px solid ${selected ? cfg.color : C.border}`,
        background: selected ? cfg.bg : C.surface,
        cursor: "pointer",
        transition: "all 0.12s",
        marginBottom: 8,
        boxShadow: selected ? `0 0 0 3px ${cfg.color}22` : "none",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          marginBottom: 4,
        }}
      >
        <div>
          <span style={{ fontSize: 14, fontWeight: 600, color: C.text }}>
            {meta.symbol}
          </span>
          <span
            style={{
              fontSize: 10,
              color: cfg.color,
              background: cfg.color + "18",
              border: `1px solid ${cfg.color}40`,
              borderRadius: 3,
              padding: "1px 6px",
              marginLeft: 7,
              fontFamily: "'IBM Plex Mono',monospace",
            }}
          >
            {cfg.label}
          </span>
        </div>
        {!downloaded && (
          <span
            style={{
              fontSize: 9,
              color: C.faint,
              fontFamily: "'IBM Plex Mono',monospace",
            }}
          >
            NOT DOWNLOADED
          </span>
        )}
      </div>
      <div style={{ fontSize: 11, color: C.muted, marginBottom: 2 }}>
        {meta.event_start} → {meta.event_end}
      </div>
      <div style={{ fontSize: 11, color: C.text, lineHeight: 1.4 }}>
        {meta.description?.slice(0, 90)}...
      </div>
    </div>
  );
}

// ── Stats Row ─────────────────────────────────────────────────────────────
function StatsRow({ stats, meta }) {
  if (!stats) return null;
  const cfg = TYPE_CONFIG[meta.type] || { color: C.muted };

  const items = [
    { l: "EVENT DAYS", v: stats.event_days },
    {
      l: "DETECTED",
      v: `${stats.detected_days}/${stats.event_days}`,
      c: stats.detection_rate_pct > 60 ? C.green : C.amber,
    },
    {
      l: "DETECTION RATE",
      v: `${stats.detection_rate_pct}%`,
      c: stats.detection_rate_pct > 60 ? C.green : C.amber,
    },
    {
      l: "PEAK SCORE",
      v: `${(stats.max_score_in_event * 100).toFixed(0)}%`,
      c: stats.max_score_in_event > 0.7 ? C.red : C.amber,
    },
    {
      l: "FALSE POSITIVES",
      v: stats.false_positives,
      c: stats.false_positives < 3 ? C.green : C.amber,
    },
    {
      l: "FIRST ALERT",
      v: stats.first_alert_date
        ? new Date(stats.first_alert_date).toLocaleDateString("en-IN", {
            day: "2-digit",
            month: "short",
          })
        : "—",
    },
  ];

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(6,1fr)",
        background: C.surface,
        borderRadius: 8,
        border: `1px solid ${C.border}`,
        marginBottom: 14,
        overflow: "hidden",
      }}
    >
      {items.map((s, i) => (
        <div
          key={i}
          style={{
            padding: "10px 14px",
            borderRight: i < 5 ? `1px solid ${C.border}` : "none",
          }}
        >
          <div
            style={{
              fontSize: 9,
              fontFamily: "'IBM Plex Mono',monospace",
              color: C.faint,
              letterSpacing: 1,
              marginBottom: 3,
            }}
          >
            {s.l}
          </div>
          <div
            style={{
              fontSize: 18,
              fontWeight: 600,
              color: s.c || C.text,
              fontFamily: "'IBM Plex Mono',monospace",
            }}
          >
            {s.v}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Main Replay Page ──────────────────────────────────────────────────────
export default function ReplayPage() {
  const [cases, setCases] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [caseData, setCaseData] = useState(null);
  const [scoreData, setScoreData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [scoring, setScoring] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios
      .get(`${ML}/replay/cases`)
      .then((r) => {
        setCases(r.data);
        if (r.data.length > 0) setSelectedId(r.data[0].id);
      })
      .catch(() =>
        setError("ML service unavailable. Run: uvicorn main:app --port 8000"),
      );
  }, []);

  useEffect(() => {
    if (!selectedId) return;
    setLoading(true);
    setCaseData(null);
    setScoreData(null);
    setError(null);

    axios
      .get(`${ML}/replay/cases/${selectedId}`)
      .then((r) => {
        setCaseData({
          ...r.data,
          candles: Array.isArray(r.data.candles)
            ? r.data.candles
            : r.data.daily || [],
        });
        setLoading(false);
      })
      .catch((e) => {
        setError(e.message);
        setLoading(false);
      });
  }, [selectedId]);

  function runScoring() {
    if (!selectedId) return;
    setScoring(true);
    axios
      .post(`${ML}/replay/score/${selectedId}`)
      .then((r) => {
        const rows = Array.isArray(r.data.rows) ? r.data.rows : [];
        const backendStats = r.data.stats || {};
        const alerts = rows.filter((row) => row.alert_fired);
        const eventStart = r.data.event_start || "";
        const eventEnd = r.data.event_end || "";
        const preEventAlerts = alerts.filter((row) => {
          const date = String(row.datetime || "").slice(0, 10);
          return date < eventStart;
        }).length;
        const firstAlert = alerts[0]?.datetime || null;

        setScoreData({
          ...r.data,
          scores: rows,
          stats: {
            ...backendStats,
            event_days: backendStats.event_bars ?? 0,
            detected_days: backendStats.alerts_in_event ?? 0,
            detection_rate_pct: Math.round(
              (backendStats.detection_rate ?? 0) * 100,
            ),
            max_score_in_event: backendStats.max_ensemble ?? 0,
            false_positives: preEventAlerts,
            first_alert_date: firstAlert,
          },
        });
        setScoring(false);
      })
      .catch((e) => {
        setError(e.message);
        setScoring(false);
      });
  }

  const selectedCase = cases.find((c) => c.id === selectedId);
  const cfg = selectedCase
    ? TYPE_CONFIG[selectedCase.type] || { color: C.muted, bg: C.surface }
    : {};

  return (
    <div
      style={{
        display: "flex",
        height: "100%",
        overflow: "hidden",
        background: C.bg,
      }}
    >
      {/* Left panel — case list */}
      <div
        style={{
          width: 280,
          borderRight: `1px solid ${C.border}`,
          background: C.bg,
          display: "flex",
          flexDirection: "column",
          flexShrink: 0,
        }}
      >
        <div
          style={{
            padding: "12px 14px",
            borderBottom: `1px solid ${C.border}`,
            background: C.surface,
          }}
        >
          <div
            style={{
              fontSize: 9,
              fontFamily: "'IBM Plex Mono',monospace",
              letterSpacing: 2,
              color: C.faint,
              marginBottom: 2,
            }}
          >
            SEBI MANIPULATION CASES
          </div>
          <div style={{ fontSize: 12, color: C.muted }}>
            Run model on confirmed events
          </div>
        </div>
        <div style={{ overflowY: "auto", flex: 1, padding: 12 }}>
          {cases.length === 0 && !error && (
            <div
              style={{
                fontSize: 11,
                color: C.faint,
                textAlign: "center",
                padding: 20,
              }}
            >
              Loading cases...
            </div>
          )}
          {error && (
            <div
              style={{
                fontSize: 11,
                color: C.red,
                padding: 12,
                background: "#fef2f2",
                borderRadius: 6,
                fontFamily: "'IBM Plex Mono',monospace",
                lineHeight: 1.5,
              }}
            >
              {error}
              <br />
              <br />
              Run:
              <br />
              cd ml-service
              <br />
              python replay/fetch_manipulation_cases.py
            </div>
          )}
          {cases.map((c) => (
            <CaseCard
              key={c.id}
              meta={c}
              selected={c.id === selectedId}
              onClick={() => setSelectedId(c.id)}
            />
          ))}
        </div>
        <div
          style={{
            padding: 12,
            borderTop: `1px solid ${C.border}`,
            background: C.surface,
          }}
        >
          <div style={{ fontSize: 10, color: C.faint, lineHeight: 1.5 }}>
            Download data first:
            <br />
            <span
              style={{ fontFamily: "'IBM Plex Mono',monospace", fontSize: 9 }}
            >
              python replay/fetch_manipulation_cases.py
            </span>
          </div>
        </div>
      </div>

      {/* Right panel — chart + analysis */}
      <div style={{ flex: 1, overflowY: "auto", padding: 20 }}>
        {loading && (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              height: 300,
              color: C.muted,
              fontSize: 13,
            }}
          >
            Loading case data...
          </div>
        )}

        {caseData && selectedCase && (
          <div style={{ animation: "fadeIn 0.2s ease" }}>
            {/* Case header */}
            <div style={{ marginBottom: 16 }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  marginBottom: 4,
                }}
              >
                <span style={{ fontSize: 22, fontWeight: 600 }}>
                  {selectedCase.symbol}
                </span>
                <span
                  style={{
                    fontSize: 12,
                    color: cfg.color,
                    background: cfg.color + "18",
                    border: `1px solid ${cfg.color}40`,
                    borderRadius: 4,
                    padding: "2px 10px",
                    fontFamily: "'IBM Plex Mono',monospace",
                  }}
                >
                  {(TYPE_CONFIG[selectedCase.type] || {}).label ||
                    selectedCase.type}
                </span>
              </div>
              <div
                style={{
                  fontSize: 14,
                  fontWeight: 500,
                  color: C.text,
                  marginBottom: 4,
                }}
              >
                {selectedCase.label}
              </div>
              <p
                style={{
                  fontSize: 12,
                  color: C.muted,
                  lineHeight: 1.6,
                  maxWidth: 700,
                }}
              >
                {selectedCase.description}
              </p>
            </div>

            {/* SEBI action badge */}
            {selectedCase.sebi_action && (
              <div
                style={{
                  marginBottom: 14,
                  padding: "8px 12px",
                  background: "#fef2f2",
                  border: "1px solid #fecaca",
                  borderRadius: 6,
                  fontSize: 11,
                  color: C.red,
                  lineHeight: 1.5,
                }}
              >
                🏛️ <strong>SEBI Action:</strong> {selectedCase.sebi_action}
              </div>
            )}

            {/* Stats (if scored) */}
            {scoreData && (
              <StatsRow stats={scoreData.stats} meta={selectedCase} />
            )}

            {/* Chart */}
            <div
              style={{
                background: C.surface,
                borderRadius: 8,
                border: `1px solid ${C.border}`,
                marginBottom: 14,
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  padding: "10px 14px",
                  borderBottom: `1px solid ${C.border}`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <span style={{ fontSize: 11, fontWeight: 500, color: C.text }}>
                  Price history · {caseData.candles?.length || 0} bars
                  {scoreData ? ` · Model scores overlaid` : ""}
                </span>
                <button
                  onClick={runScoring}
                  disabled={scoring}
                  style={{
                    fontSize: 11,
                    fontWeight: 500,
                    background: scoring ? C.faint : C.text,
                    color: "#fff",
                    border: "none",
                    padding: "5px 14px",
                    borderRadius: 5,
                    cursor: scoring ? "wait" : "pointer",
                  }}
                >
                  {scoring
                    ? "Scoring..."
                    : scoreData
                      ? "Re-run Model"
                      : "▶ Run Model on This Case"}
                </button>
              </div>
              <ReplayChart
                candles={caseData.candles}
                scores={scoreData?.scores}
                meta={selectedCase}
              />
            </div>

            {/* What the model would have detected */}
            {scoreData && (
              <div
                style={{
                  background: C.surface,
                  borderRadius: 8,
                  border: `1px solid ${C.border}`,
                  padding: 16,
                  marginBottom: 14,
                }}
              >
                <div
                  style={{
                    fontSize: 11,
                    fontFamily: "'IBM Plex Mono',monospace",
                    color: C.faint,
                    letterSpacing: 1,
                    marginBottom: 10,
                  }}
                >
                  MODEL DETECTION ANALYSIS
                </div>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "1fr 1fr",
                    gap: 16,
                  }}
                >
                  <div>
                    <p style={{ fontSize: 12, color: C.text, lineHeight: 1.7 }}>
                      The model
                      {scoreData.stats.detection_rate_pct > 60 ? (
                        <strong style={{ color: C.green }}>
                          {" "}
                          successfully detected{" "}
                        </strong>
                      ) : (
                        <strong style={{ color: C.amber }}>
                          {" "}
                          partially detected{" "}
                        </strong>
                      )}
                      this event, flagging{" "}
                      <strong>{scoreData.stats.detected_days}</strong> out of{" "}
                      <strong>{scoreData.stats.event_days}</strong> manipulation
                      days ({scoreData.stats.detection_rate_pct}% detection
                      rate).
                      {scoreData.stats.first_alert_date && (
                        <>
                          {" "}
                          The first alert would have fired on{" "}
                          <strong>
                            {new Date(
                              scoreData.stats.first_alert_date,
                            ).toLocaleDateString("en-IN", {
                              day: "2-digit",
                              month: "short",
                              year: "numeric",
                            })}
                          </strong>
                          .
                        </>
                      )}
                    </p>
                    <p
                      style={{
                        fontSize: 12,
                        color: C.muted,
                        lineHeight: 1.7,
                        marginTop: 8,
                      }}
                    >
                      Pre-event false positives:{" "}
                      <strong>{scoreData.stats.false_positives}</strong> alerts
                      fired before the manipulation window. A rate below 3 is
                      considered acceptable for operator review.
                    </p>
                  </div>
                  <div>
                    <div
                      style={{
                        fontSize: 10,
                        fontFamily: "'IBM Plex Mono',monospace",
                        color: C.faint,
                        letterSpacing: 1,
                        marginBottom: 8,
                      }}
                    >
                      ALERT TIMELINE
                    </div>
                    <div style={{ maxHeight: 200, overflowY: "auto" }}>
                      {scoreData.scores
                        .filter((s) => s.alert_fired)
                        .map((s, i) => (
                          <div
                            key={i}
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: 8,
                              padding: "4px 0",
                              borderBottom: `1px solid ${C.border}`,
                            }}
                          >
                            <div
                              style={{
                                width: 5,
                                height: 5,
                                borderRadius: "50%",
                                background: s.in_event ? C.red : C.amber,
                                flexShrink: 0,
                              }}
                            />
                            <span
                              style={{
                                fontSize: 11,
                                fontFamily: "'IBM Plex Mono',monospace",
                                color: C.muted,
                              }}
                            >
                              {new Date(s.datetime).toLocaleDateString(
                                "en-IN",
                                { day: "2-digit", month: "short" },
                              )}
                            </span>
                            <span
                              style={{
                                fontSize: 11,
                                color: s.in_event ? C.red : C.amber,
                                fontFamily: "'IBM Plex Mono',monospace",
                              }}
                            >
                              {s.alert_type || "ML_ANOMALY"} ·{" "}
                              {(s.ensemble_score * 100).toFixed(0)}%
                            </span>
                            <span
                              style={{
                                fontSize: 9,
                                color: C.faint,
                                marginLeft: "auto",
                              }}
                            >
                              {s.in_event ? "IN EVENT" : "pre-event"}
                            </span>
                          </div>
                        ))}
                      {scoreData.scores.filter((s) => s.alert_fired).length ===
                        0 && (
                        <p style={{ fontSize: 11, color: C.faint }}>
                          No alerts fired.
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Raw SEBI narrative */}
            <div
              style={{
                background: "#fffbeb",
                border: "1px solid #fde68a",
                borderRadius: 8,
                padding: 16,
              }}
            >
              <div
                style={{
                  fontSize: 10,
                  fontFamily: "'IBM Plex Mono',monospace",
                  color: C.amber,
                  letterSpacing: 1,
                  marginBottom: 8,
                }}
              >
                WHAT ACTUALLY HAPPENED (SEBI RECORDS)
              </div>
              <p style={{ fontSize: 12, color: "#92400e", lineHeight: 1.7 }}>
                {selectedCase.description}
              </p>
              <p
                style={{
                  fontSize: 11,
                  color: "#b45309",
                  marginTop: 8,
                  fontStyle: "italic",
                }}
              >
                SEBI Action: {selectedCase.sebi_action}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
