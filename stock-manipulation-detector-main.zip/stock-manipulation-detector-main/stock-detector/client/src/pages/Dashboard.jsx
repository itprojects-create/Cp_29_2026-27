// src/pages/Dashboard.jsx
// Light mode dashboard. Clean, editorial aesthetic.
// Features: crosshair hover chart, timeline selector, full evidence panel.
import React, { useRef, useEffect, useCallback, useState } from 'react'
import useStore from '../store/useStore'
import { runAnalysis } from '../services/api'

const C = {
  bg:       '#f5f4f0',
  surface:  '#ffffff',
  border:   '#e8e7e3',
  border2:  '#d4d3cf',
  text:     '#1a1a18',
  muted:    '#888884',
  faint:    '#b8b7b3',
  green:    '#16a34a',
  red:      '#dc2626',
  amber:    '#d97706',
  blue:     '#2563eb',
  purple:   '#7c3aed',
}

const LEVEL_COLORS = { CRITICAL: C.red, HIGH: C.amber, MEDIUM: C.blue, LOW: C.green }

const TIMEFRAMES = [
  { label: '15m', ticks: 15 },
  { label: '1H',  ticks: 60 },
  { label: '1D',  ticks: 390 },
  { label: 'All', ticks: 9999 },
]

// ── Crosshair Canvas Chart ────────────────────────────────────────────────
function PriceChart({ symbol, ticks, alerts }) {
  const canvasRef = useRef(null)
  const [cursor, setCursor] = useState(null)
  const [timeframe, setTimeframe] = useState('1H')

  const visibleTicks = (() => {
    const tf = TIMEFRAMES.find(t => t.label === timeframe) || TIMEFRAMES[1]
    return ticks.slice(-tf.ticks)
  })()

  const draw = useCallback((hoverX) => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    const dpr = window.devicePixelRatio || 1
    const rect = canvas.getBoundingClientRect()
    if (canvas.width !== rect.width * dpr) {
      canvas.width = rect.width * dpr
      canvas.height = rect.height * dpr
      ctx.scale(dpr, dpr)
    }
    const W = rect.width, H = rect.height
    ctx.clearRect(0, 0, W, H)

    if (visibleTicks.length < 2) {
      ctx.fillStyle = C.faint; ctx.font = '12px IBM Plex Mono'; ctx.textAlign = 'center'
      ctx.fillText('Waiting for data...', W / 2, H / 2)
      return
    }

    const prices = visibleTicks.map(t => t.price)
    const volumes = visibleTicks.map(t => t.volume)
    const minP = Math.min(...prices) * 0.9985
    const maxP = Math.max(...prices) * 1.0015
    const maxV = Math.max(...volumes) || 1
    const rangeP = maxP - minP || 1

    const PAD_L = 52, PAD_R = 8, PAD_T = 12, PAD_B = 28
    const chartW = W - PAD_L - PAD_R
    const chartH = H - PAD_T - PAD_B

    const toX = i => PAD_L + (i / (visibleTicks.length - 1)) * chartW
    const toY = p => PAD_T + (1 - (p - minP) / rangeP) * chartH * 0.82

    // Grid
    ctx.strokeStyle = '#f0efeb'; ctx.lineWidth = 0.5
    for (let i = 0; i <= 4; i++) {
      const y = PAD_T + (chartH * 0.82 * i / 4)
      ctx.beginPath(); ctx.moveTo(PAD_L, y); ctx.lineTo(W - PAD_R, y); ctx.stroke()
      const pVal = maxP - (rangeP * i / 4)
      ctx.fillStyle = C.faint; ctx.font = '9px IBM Plex Mono'; ctx.textAlign = 'right'
      ctx.fillText(`₹${pVal.toFixed(0)}`, PAD_L - 4, y + 3)
    }

    // Volume bars
    const volH = chartH * 0.12
    const barW = Math.max(1, chartW / visibleTicks.length - 0.5)
    visibleTicks.forEach((t, i) => {
      const bh = (t.volume / maxV) * volH
      ctx.fillStyle = '#e8e7e3'
      ctx.fillRect(toX(i) - barW / 2, H - PAD_B - bh, barW, bh)
    })

    // Alert zone highlights
    alerts.filter(a => a.symbol === symbol).forEach(alert => {
      const alertTime = new Date(alert.created_at).getTime()
      visibleTicks.forEach((t, i) => {
        if (Math.abs(new Date(t.timestamp).getTime() - alertTime) < 300000) {
          const color = LEVEL_COLORS[alert.level] || C.amber
          ctx.fillStyle = color + '18'
          ctx.fillRect(toX(i) - barW * 3, PAD_T, barW * 6, chartH * 0.82)
        }
      })
    })

    // Gradient fill
    const grad = ctx.createLinearGradient(0, toY(maxP), 0, toY(minP))
    grad.addColorStop(0, '#2563eb18'); grad.addColorStop(1, '#2563eb00')
    ctx.beginPath()
    visibleTicks.forEach((t, i) => {
      i === 0 ? ctx.moveTo(toX(i), toY(t.price)) : ctx.lineTo(toX(i), toY(t.price))
    })
    ctx.lineTo(toX(visibleTicks.length - 1), H - PAD_B)
    ctx.lineTo(toX(0), H - PAD_B)
    ctx.closePath(); ctx.fillStyle = grad; ctx.fill()

    // Price line
    ctx.beginPath(); ctx.strokeStyle = C.blue; ctx.lineWidth = 1.5; ctx.lineJoin = 'round'
    visibleTicks.forEach((t, i) => {
      i === 0 ? ctx.moveTo(toX(i), toY(t.price)) : ctx.lineTo(toX(i), toY(t.price))
    })
    ctx.stroke()

    // Alert dots
    alerts.filter(a => a.symbol === symbol).forEach(alert => {
      const alertTime = new Date(alert.created_at).getTime()
      let ci = -1, cd = Infinity
      visibleTicks.forEach((t, i) => {
        const d = Math.abs(new Date(t.timestamp).getTime() - alertTime)
        if (d < cd) { cd = d; ci = i }
      })
      if (ci >= 0 && cd < 600000) {
        const color = LEVEL_COLORS[alert.level] || C.amber
        const x = toX(ci), y = toY(visibleTicks[ci].price)
        ctx.beginPath(); ctx.arc(x, y, 5, 0, Math.PI * 2)
        ctx.fillStyle = '#fff'; ctx.fill()
        ctx.strokeStyle = color; ctx.lineWidth = 2; ctx.stroke()
      }
    })

    // Crosshair
    if (hoverX !== null && hoverX >= PAD_L && hoverX <= W - PAD_R) {
      const idx = Math.round((hoverX - PAD_L) / chartW * (visibleTicks.length - 1))
      const clampIdx = Math.max(0, Math.min(visibleTicks.length - 1, idx))
      const cx = toX(clampIdx)
      const cy = toY(visibleTicks[clampIdx].price)

      // Vertical line
      ctx.beginPath(); ctx.strokeStyle = '#c0bfbb'; ctx.lineWidth = 0.5; ctx.setLineDash([3, 3])
      ctx.moveTo(cx, PAD_T); ctx.lineTo(cx, H - PAD_B); ctx.stroke()
      // Horizontal line
      ctx.beginPath(); ctx.moveTo(PAD_L, cy); ctx.lineTo(W - PAD_R, cy); ctx.stroke()
      ctx.setLineDash([])

      // Dot
      ctx.beginPath(); ctx.arc(cx, cy, 4, 0, Math.PI * 2)
      ctx.fillStyle = C.blue; ctx.fill()
      ctx.strokeStyle = '#fff'; ctx.lineWidth = 2; ctx.stroke()

      // Price label on Y axis
      ctx.fillStyle = C.blue
      ctx.fillRect(0, cy - 9, PAD_L - 4, 18)
      ctx.fillStyle = '#fff'; ctx.font = 'bold 9px IBM Plex Mono'; ctx.textAlign = 'right'
      ctx.fillText(`₹${visibleTicks[clampIdx].price.toFixed(1)}`, PAD_L - 6, cy + 3)

      // Time label on X axis
      if (visibleTicks[clampIdx].timestamp) {
        const ts = new Date(visibleTicks[clampIdx].timestamp)
        const timeStr = ts.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
        ctx.fillStyle = C.muted; ctx.font = '9px IBM Plex Mono'; ctx.textAlign = 'center'
        ctx.fillText(timeStr, cx, H - 4)
      }

      setCursor({ idx: clampIdx, tick: visibleTicks[clampIdx] })
    } else {
      setCursor(null)
    }
  }, [visibleTicks, alerts, symbol])

  useEffect(() => { draw(null) }, [draw])

  const handleMouseMove = (e) => {
    const rect = canvasRef.current?.getBoundingClientRect()
    if (rect) draw(e.clientX - rect.left)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Timeframe selector + cursor info */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    padding: '6px 12px', borderBottom: `1px solid ${C.border}` }}>
        <div style={{ display: 'flex', gap: 2 }}>
          {TIMEFRAMES.map(tf => (
            <button key={tf.label} onClick={() => setTimeframe(tf.label)} style={{
              padding: '3px 10px', borderRadius: 4, border: 'none', fontSize: 11,
              fontFamily: "'IBM Plex Mono', monospace", fontWeight: 500,
              background: timeframe === tf.label ? '#1a1a18' : '#f5f4f0',
              color: timeframe === tf.label ? '#fff' : C.muted,
            }}>{tf.label}</button>
          ))}
        </div>
        {cursor ? (
          <span style={{ fontSize: 11, fontFamily: "'IBM Plex Mono', monospace", color: C.muted }}>
            ₹{cursor.tick.price?.toFixed(2)} · {cursor.tick.volume ? `${(cursor.tick.volume/1e6).toFixed(2)}M vol` : ''}
          </span>
        ) : null}
      </div>

      {/* Canvas */}
      <div style={{ flex: 1, cursor: 'crosshair' }}>
        <canvas ref={canvasRef}
          style={{ width: '100%', height: '100%', display: 'block' }}
          onMouseMove={handleMouseMove}
          onMouseLeave={() => { setCursor(null); draw(null) }}
        />
      </div>
    </div>
  )
}

// ── LangChain Evidence Panel ──────────────────────────────────────────────
function EvidencePanel() {
  const { analysisResult, analysisLoading, clearAnalysis } = useStore()

  if (!analysisResult && !analysisLoading) {
    return (
      <div style={{ padding: '14px 16px', borderTop: `1px solid ${C.border}` }}>
        <div style={{ fontSize: 10, fontFamily: "'IBM Plex Mono',monospace",
                      letterSpacing: 2, color: C.faint, marginBottom: 6 }}>
          LANGCHAIN ANALYSIS · GROQ LLAMA 3.3
        </div>
        <p style={{ fontSize: 12, color: C.faint }}>
          Click "Analyse" on any alert to run AI investigation.
        </p>
      </div>
    )
  }

  if (analysisLoading) {
    return (
      <div style={{ padding: '14px 16px', borderTop: `1px solid ${C.border}` }}>
        <div style={{ fontSize: 10, fontFamily: "'IBM Plex Mono',monospace",
                      letterSpacing: 2, color: C.faint, marginBottom: 10 }}>
          LANGCHAIN ANALYSIS · RUNNING
        </div>
        <div style={{ height: 3, background: C.border, borderRadius: 2, overflow: 'hidden' }}>
          <div style={{ height: '100%', background: C.blue, width: '30%',
                        animation: 'slide 1s infinite linear',
                        borderRadius: 2 }} />
        </div>
        <style>{`@keyframes slide{from{margin-left:-30%}to{margin-left:130%}}`}</style>
        <p style={{ fontSize: 11, color: C.muted, marginTop: 8 }}>Querying news · SEBI feeds · StockTwits · Reddit...</p>
      </div>
    )
  }

  const r = analysisResult
  const prob = r.manipulation_probability || 0
  const mtype = r.manipulation_type || 'UNCLEAR'
  const action = r.recommended_action || 'MONITOR'
  const provider = r.llm_provider || ''

  const probColor = prob > 70 ? C.red : prob > 45 ? C.amber : C.green
  const actionBg = { FLAG_REGULATORY: '#fef2f2', ALERT_COMPLIANCE: '#fffbeb',
                     MONITOR: '#eff6ff', CLEAR: '#f0fdf4' }[action] || '#f9fafb'
  const actionColor = { FLAG_REGULATORY: C.red, ALERT_COMPLIANCE: C.amber,
                        MONITOR: C.blue, CLEAR: C.green }[action] || C.muted

  // Parse evidence bullets from the raw analysis text
  const rawText = r.analysis || ''
  const evidenceLines = rawText.split('\n')
    .filter(l => l.trim().match(/^[•\-\*→▸]|^\d+\./))
    .slice(0, 6)

  // Parse tool usage from raw text (what sources LangChain queried)
  const toolsUsed = []
  if (/news|article|headline/i.test(rawText)) toolsUsed.push({ icon: '📰', label: 'Google News' })
  if (/sebi|nse|announcement|corporate/i.test(rawText)) toolsUsed.push({ icon: '🏛️', label: 'SEBI/NSE' })
  if (/stocktwits|reddit|twitter|social/i.test(rawText)) toolsUsed.push({ icon: '💬', label: 'Social Media' })
  if (/pattern|historical|match|similar/i.test(rawText)) toolsUsed.push({ icon: '📊', label: 'Pattern Match' })

  return (
    <div style={{ borderTop: `1px solid ${C.border}`, background: C.surface, flexShrink: 0 }}>
      <div style={{ padding: '10px 16px', borderBottom: `1px solid ${C.border}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 10, fontFamily: "'IBM Plex Mono',monospace",
                       letterSpacing: 2, color: C.faint }}>
          LANGCHAIN ANALYSIS · {provider.toUpperCase()}
        </span>
        <button onClick={clearAnalysis} style={{ background: 'none', border: 'none',
                                                  color: C.faint, fontSize: 14, lineHeight: 1 }}>×</button>
      </div>

      <div style={{ padding: '12px 16px', display: 'grid',
                    gridTemplateColumns: '200px 1fr 1fr', gap: 16 }}>
        {/* Probability */}
        <div>
          <div style={{ fontSize: 9, fontFamily: "'IBM Plex Mono',monospace",
                        color: C.faint, letterSpacing: 1, marginBottom: 4 }}>MANIPULATION PROB.</div>
          <div style={{ fontSize: 28, fontWeight: 600, color: probColor, lineHeight: 1 }}>
            {prob}<span style={{ fontSize: 16, fontWeight: 400 }}>/100</span>
          </div>
          <div style={{ marginTop: 6, height: 3, background: C.border, borderRadius: 2 }}>
            <div style={{ height: '100%', width: `${prob}%`,
                          background: probColor, borderRadius: 2, transition: 'width .4s' }} />
          </div>
          <div style={{ marginTop: 6, fontSize: 11, fontWeight: 600,
                        color: probColor }}>{mtype.replace(/_/g, ' ')}</div>
        </div>

        {/* Evidence */}
        <div>
          <div style={{ fontSize: 9, fontFamily: "'IBM Plex Mono',monospace",
                        color: C.faint, letterSpacing: 1, marginBottom: 6 }}>EVIDENCE FOUND</div>
          {evidenceLines.length > 0 ? (
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 3 }}>
              {evidenceLines.map((l, i) => (
                <li key={i} style={{ fontSize: 11, color: C.text, lineHeight: 1.4 }}>
                  {l.trim()}
                </li>
              ))}
            </ul>
          ) : (
            <p style={{ fontSize: 11, color: C.muted, lineHeight: 1.5 }}>
              {rawText.slice(0, 200)}...
            </p>
          )}
        </div>

        {/* Sources queried + Action */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div>
            <div style={{ fontSize: 9, fontFamily: "'IBM Plex Mono',monospace",
                          color: C.faint, letterSpacing: 1, marginBottom: 6 }}>SOURCES QUERIED</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
              {toolsUsed.map((t, i) => (
                <span key={i} style={{ fontSize: 10, background: '#f0f0ee',
                                        border: `1px solid ${C.border}`, borderRadius: 4,
                                        padding: '2px 7px', color: C.text }}>
                  {t.icon} {t.label}
                </span>
              ))}
              {toolsUsed.length === 0 && (
                <span style={{ fontSize: 10, color: C.faint }}>No sources detected</span>
              )}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 9, fontFamily: "'IBM Plex Mono',monospace",
                          color: C.faint, letterSpacing: 1, marginBottom: 4 }}>RECOMMENDED ACTION</div>
            <div style={{ fontSize: 12, fontWeight: 600, color: actionColor,
                          background: actionBg, border: `1px solid ${actionColor}33`,
                          borderRadius: 6, padding: '5px 12px', display: 'inline-block',
                          letterSpacing: 0.5 }}>
              {action.replace(/_/g, ' ')}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// ── Alert Feed ────────────────────────────────────────────────────────────
function AlertRow({ alert, onAnalyse, loading }) {
  const color = LEVEL_COLORS[alert.level] || C.faint
  const score = alert.ensemble_score || alert.severity || 0
  return (
    <div style={{ padding: '10px 14px', borderBottom: `1px solid ${C.border}`,
                  background: '#fff', animation: 'fadeIn 0.25s ease' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 3 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ fontSize: 12, fontWeight: 600, color: C.text }}>{alert.symbol}</span>
          <span style={{ fontSize: 9, fontFamily: "'IBM Plex Mono',monospace",
                          background: color + '15', color, border: `1px solid ${color}40`,
                          padding: '1px 5px', borderRadius: 3 }}>{alert.level}</span>
        </div>
        <span style={{ fontSize: 9, color: C.faint, fontFamily: "'IBM Plex Mono',monospace" }}>
          {alert.created_at ? new Date(alert.created_at).toLocaleTimeString('en-IN', {hour:'2-digit',minute:'2-digit'}) : ''}
        </span>
      </div>
      <div style={{ fontSize: 11, color: C.muted, marginBottom: 3 }}>
        {alert.alert_type?.replace(/_/g, ' ')}
      </div>
      {alert.detail && (
        <div style={{ fontSize: 10, color: C.faint, marginBottom: 6, lineHeight: 1.4 }}>
          {alert.detail.slice(0, 85)}{alert.detail.length > 85 ? '…' : ''}
        </div>
      )}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ flex: 1, height: 2, background: C.border, borderRadius: 1 }}>
          <div style={{ height: '100%', width: `${score*100}%`, background: color,
                        borderRadius: 1, transition: 'width 0.3s' }} />
        </div>
        <span style={{ fontSize: 9, color: C.faint, fontFamily: "'IBM Plex Mono',monospace",
                        minWidth: 28 }}>{(score*100).toFixed(0)}%</span>
        <button onClick={() => onAnalyse(alert)} disabled={loading} style={{
          fontSize: 9, fontFamily: "'IBM Plex Mono',monospace", fontWeight: 500,
          background: loading ? C.border : C.text, color: loading ? C.faint : '#fff',
          border: 'none', padding: '3px 8px', borderRadius: 4,
          opacity: loading ? 0.6 : 1, letterSpacing: 0.5,
        }}>
          {loading ? '...' : 'ANALYSE'}
        </button>
      </div>
    </div>
  )
}

// ── Main Dashboard ────────────────────────────────────────────────────────
export default function Dashboard() {
  const {
    watchlist, liveState, tickHistory, alerts, selectedSymbol,
    setSelectedSymbol, connected, totalTicksScanned, setAnalysisLoading,
    setAnalysisResult, newAlertCount, clearNewAlerts,
  } = useStore()
  const [loadingId, setLoadingId] = useState(null)

  const alertsBySymbol = {}
  alerts.forEach(a => { if (!alertsBySymbol[a.symbol]) alertsBySymbol[a.symbol] = a })

  async function handleAnalyse(alert) {
    setLoadingId(alert.id)
    setAnalysisLoading(true)
    try {
      const result = await runAnalysis({
        alertId: alert.id, symbol: alert.symbol, alert_type: alert.alert_type,
        price: alert.price, volume: alert.volume,
        ensemble_score: alert.ensemble_score || alert.severity,
      })
      setAnalysisResult(result, alert.id)
    } catch (e) {
      setAnalysisResult({ analysis: `Failed: ${e.message}`, manipulation_probability: 0 }, alert.id)
    } finally { setLoadingId(null) }
  }

  const live = liveState[selectedSymbol] || {}
  const chg = live.changePct || 0
  const symAlerts = alerts.filter(a => a.symbol === selectedSymbol)

  return (
    <div style={{ display: 'flex', height: '100%', overflow: 'hidden', background: C.bg }}>

      {/* Watchlist */}
      <div style={{ width: 188, borderRight: `1px solid ${C.border}`, background: C.surface,
                    display: 'flex', flexDirection: 'column', flexShrink: 0, overflowY: 'auto' }}>
        <div style={{ padding: '10px 12px 6px', fontSize: 9, fontFamily: "'IBM Plex Mono',monospace",
                      letterSpacing: 2, color: C.faint, borderBottom: `1px solid ${C.border}` }}>
          WATCHLIST
        </div>
        {watchlist.map(sym => {
          const s = liveState[sym] || {}
          const c = s.changePct || 0
          const a = alertsBySymbol[sym]
          const fresh = a && (Date.now() - a.seenAt) < 300000
          const aColor = fresh ? LEVEL_COLORS[a.level] : null
          const sel = sym === selectedSymbol
          return (
            <div key={sym} onClick={() => setSelectedSymbol(sym)} style={{
              padding: '8px 12px', cursor: 'pointer',
              background: sel ? '#f0f6ff' : 'transparent',
              borderLeft: `2px solid ${sel ? C.blue : 'transparent'}`,
              borderBottom: `1px solid ${C.border}`,
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 12, fontWeight: 600, color: sel ? C.blue : C.text }}>{sym}</span>
                {fresh && aColor && (
                  <div style={{ width: 5, height: 5, borderRadius: '50%', background: aColor }} />
                )}
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 1 }}>
                <span style={{ fontSize: 11, color: C.muted, fontFamily: "'IBM Plex Mono',monospace" }}>
                  {s.price ? `₹${Number(s.price).toFixed(1)}` : '—'}
                </span>
                <span style={{ fontSize: 10, color: c >= 0 ? C.green : C.red,
                                fontFamily: "'IBM Plex Mono',monospace" }}>
                  {c >= 0 ? '+' : ''}{c.toFixed(2)}%
                </span>
              </div>
            </div>
          )
        })}
      </div>

      {/* Center */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Stats row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)',
                      borderBottom: `1px solid ${C.border}`, background: C.surface, flexShrink: 0 }}>
          {[
            { l: 'PRICE',        v: live.price ? `₹${Number(live.price).toFixed(2)}` : '—', c: chg >= 0 ? C.green : C.red },
            { l: '24H CHANGE',   v: live.price ? `${chg >= 0 ? '+' : ''}${chg.toFixed(2)}%` : '—', c: chg >= 0 ? C.green : C.red },
            { l: 'VOLUME',       v: live.volume ? `${(live.volume/1e6).toFixed(2)}M` : '—', c: C.text },
            { l: 'ALERTS TODAY', v: symAlerts.length, c: symAlerts.length > 0 ? C.amber : C.muted },
            { l: 'TICKS SCANNED',v: totalTicksScanned.toLocaleString(), c: C.muted },
          ].map((s, i) => (
            <div key={i} style={{ padding: '10px 16px',
                                   borderRight: i < 4 ? `1px solid ${C.border}` : 'none' }}>
              <div style={{ fontSize: 9, fontFamily: "'IBM Plex Mono',monospace",
                            color: C.faint, letterSpacing: 1, marginBottom: 3 }}>{s.l}</div>
              <div style={{ fontSize: 18, fontWeight: 600, color: s.c,
                            fontFamily: "'IBM Plex Mono',monospace" }}>{s.v}</div>
            </div>
          ))}
        </div>

        {/* Symbol label */}
        <div style={{ padding: '8px 16px 4px', borderBottom: `1px solid ${C.border}`,
                      background: C.surface, display: 'flex', alignItems: 'center',
                      gap: 10, flexShrink: 0 }}>
          <span style={{ fontSize: 18, fontWeight: 600, color: C.text }}>{selectedSymbol}</span>
          <span style={{ fontSize: 10, color: C.faint, fontFamily: "'IBM Plex Mono',monospace",
                          letterSpacing: 1 }}>NSE · REAL-TIME</span>
          <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 5, height: 5, borderRadius: '50%',
                          background: connected ? C.green : C.red }} />
            <span style={{ fontSize: 10, color: connected ? C.green : C.red,
                            fontFamily: "'IBM Plex Mono',monospace" }}>
              {connected ? 'LIVE' : 'OFFLINE'}
            </span>
          </div>
        </div>

        {/* Chart */}
        <div style={{ flex: 1, minHeight: 0, background: C.surface }}>
          <PriceChart
            symbol={selectedSymbol}
            ticks={tickHistory[selectedSymbol] || []}
            alerts={alerts}
          />
        </div>

        {/* LangChain evidence panel */}
        <EvidencePanel />
      </div>

      {/* Alert feed */}
      <div style={{ width: 292, borderLeft: `1px solid ${C.border}`,
                    display: 'flex', flexDirection: 'column', flexShrink: 0, background: C.bg }}>
        <div style={{ padding: '10px 14px', borderBottom: `1px solid ${C.border}`,
                      background: C.surface, display: 'flex', justifyContent: 'space-between',
                      alignItems: 'center', flexShrink: 0 }}>
          <span style={{ fontSize: 9, fontFamily: "'IBM Plex Mono',monospace",
                          letterSpacing: 2, color: C.faint }}>ANOMALY FEED</span>
          <span style={{ fontSize: 9, color: C.faint }}>{alerts.length} events</span>
        </div>
        <div style={{ overflowY: 'auto', flex: 1 }}>
          {alerts.length === 0 && (
            <div style={{ padding: 20, fontSize: 11, color: C.faint, textAlign: 'center' }}>
              No anomalies detected.<br />Scanning...
            </div>
          )}
          {alerts.map(a => (
            <AlertRow key={a.id} alert={a}
              onAnalyse={handleAnalyse}
              loading={loadingId === a.id} />
          ))}
        </div>
      </div>
    </div>
  )
}
