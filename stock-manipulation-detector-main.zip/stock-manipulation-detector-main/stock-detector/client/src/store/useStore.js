// src/store/useStore.js
// Single Zustand store for the entire app.
// Holds: ticks per symbol, alerts, selected symbol, ML model choice, connection status.

import { create } from 'zustand'

const MAX_TICKS_PER_SYMBOL = 120  // Keep last 120 ticks for chart

const useStore = create((set, get) => ({
  // ── Connection ──────────────────────────────────────────────────────────
  connected: false,
  scanActive: true,
  setConnected: (v) => set({ connected: v }),
  setScanActive: (v) => set({ scanActive: v }),

  // ── Watchlist & live prices ────────────────────────────────────────────
  watchlist: [
    'RELIANCE','HDFCBANK','INFY','TCS','ICICIBANK',
    'KOTAKBANK','SBIN','AXISBANK','BAJFINANCE','WIPRO',
    'ZOMATO','NYKAA','PAYTM','ADANIENT','YESBANK'
  ],

  // { RELIANCE: { price, volume, high, low, change, changePct } }
  liveState: {},

  // { RELIANCE: [{price, volume, timestamp}, ...] }
  tickHistory: {},

  setLiveState: (symbol, data) => set((state) => ({
    liveState: { ...state.liveState, [symbol]: { ...state.liveState[symbol], ...data } }
  })),

  addTick: (tick) => set((state) => {
    const sym = tick.symbol
    const existing = state.tickHistory[sym] || []
    const prev = existing[existing.length - 1]
    const change = prev ? tick.price - prev.price : 0
    const changePct = prev ? (change / prev.price) * 100 : 0

    const newTicks = [
      ...existing,
      { ...tick, change, changePct }
    ].slice(-MAX_TICKS_PER_SYMBOL)

    return {
      tickHistory: { ...state.tickHistory, [sym]: newTicks },
      liveState: {
        ...state.liveState,
        [sym]: {
          ...(state.liveState[sym] || {}),
          price: tick.price,
          volume: tick.volume,
          change,
          changePct,
          last_updated: tick.timestamp,
        }
      }
    }
  }),

  // ── Selected symbol (drives chart) ───────────────────────────────────
  selectedSymbol: 'RELIANCE',
  setSelectedSymbol: (sym) => set({ selectedSymbol: sym }),

  // ── Alerts ────────────────────────────────────────────────────────────
  alerts: [],      // All alerts, newest first
  newAlertCount: 0,

  addAlert: (alert) => set((state) => ({
    alerts: [
      { ...alert, id: alert.id || `${alert.symbol}-${Date.now()}`, seenAt: Date.now() },
      ...state.alerts
    ].slice(0, 100),  // Keep last 100
    newAlertCount: state.newAlertCount + 1,
  })),

  clearNewAlerts: () => set({ newAlertCount: 0 }),

  // ── AI Analysis panel ─────────────────────────────────────────────────
  analysisResult: null,
  analysisLoading: false,
  analysisAlertId: null,

  setAnalysisLoading: (v) => set({ analysisLoading: v }),
  setAnalysisResult: (result, alertId) => set({
    analysisResult: result,
    analysisLoading: false,
    analysisAlertId: alertId,
  }),
  clearAnalysis: () => set({ analysisResult: null, analysisAlertId: null }),

  // ── Stats ─────────────────────────────────────────────────────────────
  totalTicksScanned: 0,
  incrementTicks: (n = 1) => set((s) => ({ totalTicksScanned: s.totalTicksScanned + n })),
}))

export default useStore
