// src/components/AIAnalysisPanel.jsx
// Full structured evidence panel — shows every tool the agent called,
// every piece of evidence, and the final verdict with score breakdown.

import React, { useState } from 'react'
import useStore from '../store/useStore'

const VERDICT_COLORS = {
  PUMP_AND_DUMP:   '#dc2626',
  COORDINATED_BUY: '#ea580c',
  SHORT_ATTACK:    '#ea580c',
  WASH_TRADING:    '#d97706',
  LEGITIMATE:      '#16a34a',
  UNCLEAR:         '#6b7280',
}
const ACTION_COLORS = {
  FLAG_REGULATORY:  '#dc2626',
  ALERT_COMPLIANCE: '#ea580c',
  MONITOR:          '#d97706',
  CLEAR:            '#16a34a',
}
const TOOL_LABELS = {
  search_news_tool:               '📰 News',
  check_sebi_announcements_tool:  '🏛 SEBI',
  social_sentiment_tool:          '📱 Social',
  historical_pattern_tool:        '📊 Patterns',
}
const LAYER_LABELS = {
  if_score:    'Isolation Forest',
  rf_score:    'Random Forest',
  lstm_score:  'LSTM Autoencoder',
  rule_score:  'Z-score Rules',
  cf_score:    'Collaborative Filter',
}

// Loading dots animation
function LoadingDots() {
  return (
    <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}>
      {[0,1,2].map(i => (
        <span key={i} style={{
          width: 6, height: 6, borderRadius: '50%', background: '#2563eb',
          animation: `bounce 1s ${i * 0.2}s infinite`,
        }} />
      ))}
      <style>{`@keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}`}</style>
    </span>
  )
}

// Score bar for a single ML layer
function LayerBar({ label, score, color }) {
  const pct = Math.round((score || 0) * 100)
  return (
    <div style={{ marginBottom: 6 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between',
                    fontSize: 11, color: '#6b7280', marginBottom: 2 }}>
        <span>{label}</span>
        <span style={{ fontWeight: 600, color: pct > 55 ? color : '#9ca3af' }}>{pct}%</span>
      </div>
      <div style={{ height: 5, background: '#e5e7eb', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{
          height: '100%', width: `${pct}%`,
          background: pct > 85 ? '#dc2626' : pct > 70 ? '#ea580c' : pct > 55 ? '#d97706' : '#2563eb',
          borderRadius: 3, transition: 'width 0.5s',
        }} />
      </div>
    </div>
  )
}

export default function AIAnalysisPanel() {
  const { analysisResult, analysisLoading, clearAnalysis } = useStore()
  const [expandRaw, setExpandRaw] = useState(false)

  // ── Empty state ─────────────────────────────────────────────────────
  if (!analysisResult && !analysisLoading) {
    return (
      <div style={{
        borderTop: '1px solid #e5e7eb', background: '#fafafa',
        padding: '14px 20px',
      }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: '#6b7280',
                      letterSpacing: 1, marginBottom: 6 }}>
          🤖 AI INVESTIGATION (LangChain + Groq — free)
        </div>
        <div style={{ fontSize: 12, color: '#9ca3af' }}>
          Click <strong style={{ color: '#2563eb' }}>AI ANALYZE</strong> on any alert
          to run a full 4-tool investigation: News → SEBI → Social → Pattern Match
        </div>
      </div>
    )
  }

  // ── Loading state ───────────────────────────────────────────────────
  if (analysisLoading) {
    return (
      <div style={{
        borderTop: '1px solid #e5e7eb', background: '#fafafa',
        padding: '14px 20px',
      }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: '#6b7280',
                      letterSpacing: 1, marginBottom: 10 }}>
          🤖 AI INVESTIGATION — RUNNING
        </div>
        {['📰 Scanning news sources…',
          '🏛 Checking SEBI/NSE announcements…',
          '📱 Scanning StockTwits + Reddit…',
          '📊 Matching historical SEBI cases…',
        ].map((step, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8,
                                fontSize: 12, color: '#374151', marginBottom: 6 }}>
            <LoadingDots />
            <span>{step}</span>
          </div>
        ))}
        <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 8 }}>
          Groq Llama 3.3-70B · typically 3–8 seconds
        </div>
      </div>
    )
  }

  const r              = analysisResult
  const prob           = r.manipulation_probability || 0
  const mtype          = r.manipulation_type        || 'UNCLEAR'
  const action         = r.recommended_action       || 'MONITOR'
  const evidence       = r.evidence                 || []
  const tools          = r.tools_called             || []
  const ml             = r.ml_context               || {}
  const verdictColor   = VERDICT_COLORS[mtype]      || '#6b7280'
  const actionColor    = ACTION_COLORS[action]       || '#6b7280'

  return (
    <div style={{
      borderTop: '1px solid #e5e7eb', background: '#fafafa',
      maxHeight: 420, overflowY: 'auto',
    }}>
      {/* ── Header ── */}
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        padding: '12px 20px 10px', borderBottom: '1px solid #e5e7eb',
        background: '#fff', position: 'sticky', top: 0,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: '#111827' }}>
            🤖 AI INVESTIGATION
          </span>
          <span style={{ fontSize: 10, background: '#eff6ff', color: '#1d4ed8',
                         border: '1px solid #bfdbfe', borderRadius: 4,
                         padding: '1px 6px' }}>
            {r.llm_provider?.toUpperCase() || 'GROQ'}
          </span>
          {/* Tools called badges */}
          {tools.map(t => (
            <span key={t} style={{ fontSize: 10, background: '#f0fdf4',
                                    color: '#15803d', border: '1px solid #bbf7d0',
                                    borderRadius: 4, padding: '1px 6px' }}>
              {TOOL_LABELS[t] || t}
            </span>
          ))}
        </div>
        <button onClick={clearAnalysis} style={{
          background: 'none', border: 'none', cursor: 'pointer',
          fontSize: 16, color: '#9ca3af', lineHeight: 1,
        }}>✕</button>
      </div>

      <div style={{ padding: '14px 20px', display: 'grid',
                    gridTemplateColumns: '1fr 1fr', gap: 16 }}>

        {/* ── Left: Verdict + Evidence ── */}
        <div>
          {/* Verdict */}
          <div style={{ marginBottom: 12 }}>
            <div style={{ fontSize: 10, color: '#6b7280', fontWeight: 600,
                          letterSpacing: 1, marginBottom: 4 }}>VERDICT</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
              <span style={{ fontSize: 16, fontWeight: 700, color: verdictColor }}>
                {mtype.replace(/_/g, ' ')}
              </span>
              <span style={{ fontSize: 22, fontWeight: 800, color: verdictColor }}>
                {prob}/100
              </span>
            </div>
            {/* Probability bar */}
            <div style={{ height: 6, background: '#e5e7eb', borderRadius: 3,
                          overflow: 'hidden', marginBottom: 8 }}>
              <div style={{
                height: '100%', width: `${prob}%`, borderRadius: 3,
                background: prob > 70 ? '#dc2626' : prob > 40 ? '#d97706' : '#16a34a',
                transition: 'width 0.6s',
              }} />
            </div>
            {/* Action */}
            <div style={{ display: 'inline-block', fontSize: 11, fontWeight: 700,
                          color: actionColor, background: `${actionColor}15`,
                          border: `1px solid ${actionColor}44`,
                          borderRadius: 4, padding: '3px 10px', letterSpacing: 1 }}>
              {action.replace(/_/g, ' ')}
            </div>
          </div>

          {/* Evidence list */}
          <div>
            <div style={{ fontSize: 10, color: '#6b7280', fontWeight: 600,
                          letterSpacing: 1, marginBottom: 6 }}>KEY EVIDENCE</div>
            {evidence.length > 0 ? evidence.map((e, i) => (
              <div key={i} style={{ display: 'flex', gap: 6, marginBottom: 5,
                                    fontSize: 11, color: '#374151', lineHeight: 1.4 }}>
                <span style={{ color: prob > 60 ? '#dc2626' : '#6b7280',
                               flexShrink: 0, marginTop: 1 }}>
                  {prob > 60 ? '⚠' : '•'}
                </span>
                <span>{e}</span>
              </div>
            )) : (
              <div style={{ fontSize: 11, color: '#9ca3af' }}>No evidence extracted</div>
            )}
          </div>

          {/* Reasoning */}
          {r.reasoning && (
            <div style={{ marginTop: 10, padding: '8px 10px',
                          background: '#f9fafb', borderRadius: 6,
                          border: '1px solid #e5e7eb' }}>
              <div style={{ fontSize: 10, color: '#6b7280', fontWeight: 600,
                            letterSpacing: 1, marginBottom: 4 }}>REASONING</div>
              <div style={{ fontSize: 11, color: '#374151', lineHeight: 1.5 }}>
                {r.reasoning}
              </div>
            </div>
          )}
        </div>

        {/* ── Right: Tool findings + ML breakdown ── */}
        <div>
          {/* ML Layer Scores */}
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 10, color: '#6b7280', fontWeight: 600,
                          letterSpacing: 1, marginBottom: 8 }}>ML LAYER BREAKDOWN</div>
            {Object.entries(LAYER_LABELS).map(([key, label]) => (
              ml[key] !== undefined || r[key] !== undefined
                ? <LayerBar key={key} label={label}
                             score={ml[key] || r[key] || 0}
                             color={verdictColor} />
                : null
            ))}
            {ml.cf_signal && (
              <div style={{ fontSize: 11, color: '#6b7280', marginTop: 4 }}>
                CF Signal: <strong style={{ color: ml.cf_signal === 'COORDINATED' ? '#dc2626' : '#374151' }}>
                  {ml.cf_signal}
                </strong>
                {ml.co_moving_peers?.length > 0 &&
                  ` (peers: ${ml.co_moving_peers.join(', ')})`}
              </div>
            )}
          </div>

          {/* Tool-by-tool findings */}
          <div>
            <div style={{ fontSize: 10, color: '#6b7280', fontWeight: 600,
                          letterSpacing: 1, marginBottom: 8 }}>TOOL FINDINGS</div>

            {/* News */}
            {r.news_summary && (
              <div style={{ marginBottom: 8, padding: '7px 10px',
                            background: '#eff6ff', borderRadius: 6,
                            border: '1px solid #bfdbfe' }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: '#1d4ed8',
                              marginBottom: 3 }}>📰 NEWS</div>
                <div style={{ fontSize: 11, color: '#1e3a5f', lineHeight: 1.4 }}>
                  {r.news_summary}
                </div>
              </div>
            )}

            {/* SEBI */}
            {r.sebi_status && (
              <div style={{ marginBottom: 8, padding: '7px 10px',
                            background: r.sebi_status.includes('ASM') ? '#fef2f2' : '#f0fdf4',
                            borderRadius: 6,
                            border: `1px solid ${r.sebi_status.includes('ASM') ? '#fecaca' : '#bbf7d0'}` }}>
                <div style={{ fontSize: 10, fontWeight: 700,
                              color: r.sebi_status.includes('ASM') ? '#dc2626' : '#15803d',
                              marginBottom: 3 }}>🏛 SEBI/NSE</div>
                <div style={{ fontSize: 11, lineHeight: 1.4,
                              color: r.sebi_status.includes('ASM') ? '#7f1d1d' : '#14532d' }}>
                  {r.sebi_status}
                </div>
              </div>
            )}

            {/* Social */}
            {r.social_summary && (
              <div style={{ marginBottom: 8, padding: '7px 10px',
                            background: '#fff7ed', borderRadius: 6,
                            border: '1px solid #fed7aa' }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: '#c2410c',
                              marginBottom: 3 }}>📱 SOCIAL MEDIA</div>
                <div style={{ fontSize: 11, color: '#7c2d12', lineHeight: 1.4 }}>
                  {r.social_summary}
                </div>
              </div>
            )}

            {/* Pattern */}
            {r.pattern_match && (
              <div style={{ marginBottom: 8, padding: '7px 10px',
                            background: '#faf5ff', borderRadius: 6,
                            border: '1px solid #e9d5ff' }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: '#7e22ce',
                              marginBottom: 3 }}>📊 SEBI PATTERN MATCH</div>
                <div style={{ fontSize: 11, color: '#3b0764', lineHeight: 1.4 }}>
                  {r.pattern_match}
                </div>
              </div>
            )}
          </div>

          {/* Raw output toggle */}
          <button onClick={() => setExpandRaw(x => !x)} style={{
            marginTop: 6, fontSize: 10, color: '#9ca3af', background: 'none',
            border: '1px solid #e5e7eb', borderRadius: 4, cursor: 'pointer',
            padding: '3px 8px',
          }}>
            {expandRaw ? 'Hide' : 'Show'} raw LLM output
          </button>
          {expandRaw && (
            <pre style={{ marginTop: 6, fontSize: 9, color: '#6b7280',
                          background: '#f9fafb', border: '1px solid #e5e7eb',
                          borderRadius: 4, padding: 8, overflowX: 'auto',
                          maxHeight: 120, whiteSpace: 'pre-wrap' }}>
              {r.analysis}
            </pre>
          )}
        </div>
      </div>
    </div>
  )
}

// ── SHAP Waterfall component (add inside AIAnalysisPanel after tool findings) ──
export function SHAPWaterfall({ shap }) {
  if (!shap || !shap.available || !shap.top_drivers?.length) return null

  const max_abs = Math.max(...shap.top_drivers.map(d => Math.abs(d.shap_value)), 0.01)

  return (
    <div style={{ marginTop: 12, padding: '10px 12px',
                  background: '#fdf4ff', border: '1px solid #e9d5ff',
                  borderRadius: 6 }}>
      <div style={{ fontSize: 10, fontWeight: 700, color: '#7e22ce',
                    letterSpacing: 1, marginBottom: 8 }}>
        🔬 SHAP — WHY THIS ALERT FIRED (top feature drivers)
      </div>
      {shap.top_drivers.map((d, i) => {
        const pct     = (Math.abs(d.shap_value) / max_abs) * 100
        const isPos   = d.shap_value > 0
        return (
          <div key={i} style={{ marginBottom: 6 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between',
                          fontSize: 10, marginBottom: 2 }}>
              <span style={{ color: '#374151', fontWeight: 600 }}>
                {d.feature.replace(/_/g,' ')}
              </span>
              <span style={{ color: isPos ? '#dc2626' : '#16a34a', fontWeight: 700 }}>
                {isPos ? '+' : ''}{d.shap_value.toFixed(3)}
              </span>
            </div>
            <div style={{ height: 6, background: '#e5e7eb', borderRadius: 3 }}>
              <div style={{
                height: '100%', width: `${pct}%`, borderRadius: 3,
                background: isPos ? '#dc2626' : '#16a34a',
                transition: 'width 0.4s',
              }} />
            </div>
            <div style={{ fontSize: 9, color: '#9ca3af', marginTop: 1 }}>
              value: {d.feat_value?.toFixed?.(3) ?? d.feat_value} — {d.direction}
            </div>
          </div>
        )
      })}
      <div style={{ fontSize: 9, color: '#a78bfa', marginTop: 6 }}>
        Based on TreeSHAP (Lundberg et al., 2020) applied to Isolation Forest
      </div>
    </div>
  )
}

// ── Video signal component ──
export function VideoSignalPanel({ video }) {
  if (!video || !video.available) return null
  const score = video.composite_score || 0
  const color = score > 60 ? '#dc2626' : score > 30 ? '#d97706' : '#16a34a'

  return (
    <div style={{ marginTop: 10, padding: '8px 12px',
                  background: '#fff7ed', border: '1px solid #fed7aa',
                  borderRadius: 6 }}>
      <div style={{ fontSize: 10, fontWeight: 700, color: '#c2410c',
                    letterSpacing: 1, marginBottom: 6 }}>
        📺 YOUTUBE + GOOGLE TRENDS SIGNAL
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
        <div style={{ fontSize: 18, fontWeight: 800, color }}>
          {score.toFixed(0)}/100
        </div>
        <div style={{ fontSize: 11, color }}>
          {score > 60 ? '🚨 HIGH — Sadhna Broadcast pattern' :
           score > 30 ? '⚠️  MODERATE' : '✅ LOW — No unusual promotion'}
        </div>
      </div>
      {video.suspicious_videos?.length > 0 && (
        <div>
          <div style={{ fontSize: 10, color: '#92400e', marginBottom: 4 }}>
            Suspicious videos:
          </div>
          {video.suspicious_videos.slice(0,3).map((v, i) => (
            <div key={i} style={{ fontSize: 10, color: '#7c2d12', marginBottom: 3 }}>
              • {v.title} ({(v.views/1000).toFixed(0)}K views)
            </div>
          ))}
        </div>
      )}
      {video.trends_spike && (
        <div style={{ fontSize: 10, color: '#dc2626', marginTop: 4 }}>
          ⚠️  Google Trends spike detected (ratio: {video.trends_data?.spike_ratio?.toFixed(1) || '?'}x)
        </div>
      )}
      <div style={{ fontSize: 9, color: '#a78bfa', marginTop: 4 }}>
        YouTube Data API v3 + pytrends (Google Trends)
      </div>
    </div>
  )
}
