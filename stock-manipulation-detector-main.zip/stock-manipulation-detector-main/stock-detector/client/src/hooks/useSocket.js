// src/hooks/useSocket.js
// Manages Socket.IO connection lifecycle.
// Subscribes to symbol rooms, routes incoming ticks and alerts to Zustand.

import { useEffect, useRef } from 'react'
import { io } from 'socket.io-client'
import useStore from '../store/useStore'

const SERVER_URL = import.meta.env.VITE_SERVER_URL || 'http://localhost:3001'

export function useSocket() {
  const socketRef = useRef(null)
  const {
    watchlist, addTick, addAlert, setConnected,
    setLiveState, incrementTicks, scanActive,
  } = useStore()

  useEffect(() => {
    if (!scanActive) return

    const socket = io(SERVER_URL, {
      transports: ['websocket', 'polling'],
      reconnectionAttempts: Infinity,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
    })
    socketRef.current = socket

    // ── Connection events ─────────────────────────────────────────────
    socket.on('connect', () => {
      setConnected(true)
      // Subscribe to all watchlist symbols
      watchlist.forEach(sym => socket.emit('subscribe', sym))
      // Subscribe to global alert feed
      socket.emit('subscribe_all')
    })

    socket.on('disconnect', () => setConnected(false))
    socket.on('connect_error', () => setConnected(false))

    // ── Incoming tick ─────────────────────────────────────────────────
    // Fired by Node.js for every price update
    socket.on('tick', (tick) => {
      addTick(tick)
      incrementTicks()
    })

    // ── Incoming alert ────────────────────────────────────────────────
    // Fired when ML service detects anomaly
    socket.on('alert', (alert) => {
      addAlert(alert)
    })

    // ── Live state on subscribe ───────────────────────────────────────
    // Server sends current price immediately on subscription
    socket.on('live_state', ({ symbol, ...data }) => {
      setLiveState(symbol, data)
    })

    return () => {
      socket.disconnect()
      socketRef.current = null
      setConnected(false)
    }
  }, [scanActive])  // Reconnects if scanActive changes

  return socketRef
}
