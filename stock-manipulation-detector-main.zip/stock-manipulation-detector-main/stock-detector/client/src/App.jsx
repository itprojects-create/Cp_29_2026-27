// src/App.jsx
import React, { useEffect, useState } from 'react'
import { useSocket } from './hooks/useSocket'
import Dashboard from './pages/Dashboard'
import ReplayPage from './pages/ReplayPage'
import useStore from './store/useStore'
import { fetchAlerts } from './services/api'

export default function App() {
  const [page, setPage] = useState('dashboard')
  useSocket()
  const { addAlert, selectedSymbol } = useStore()

  useEffect(() => {
    fetchAlerts({ limit: 30 }).then(a => a.forEach(addAlert)).catch(() => {})
  }, [])

  useEffect(() => {
    fetchAlerts({ symbol: selectedSymbol, limit: 20 }).then(a => a.forEach(addAlert)).catch(() => {})
  }, [selectedSymbol])

  return (
    <div style={{
      height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden',
      background: '#f5f4f0', color: '#1a1a18',
      fontFamily: "'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:4px;height:4px}
        ::-webkit-scrollbar-track{background:#ebebeb}
        ::-webkit-scrollbar-thumb{background:#c0bfbb;border-radius:2px}
        button,input,select{font-family:inherit;cursor:pointer}
        @keyframes fadeIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}
      `}</style>

      {/* Top nav */}
      <nav style={{
        height: 46, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 16px', background: '#fff', borderBottom: '1px solid #e8e7e3',
        flexShrink: 0, zIndex: 100,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#16a34a',
                          boxShadow: '0 0 0 2px #dcfce7' }} />
            <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 12,
                           fontWeight: 500, letterSpacing: 2, color: '#1a1a18' }}>
              MARKET SENTINEL
            </span>
          </div>
          <div style={{ display: 'flex', gap: 2 }}>
            {[['dashboard','Live Monitor'],['replay','Manipulation Replay']].map(([id, label]) => (
              <button key={id} onClick={() => setPage(id)} style={{
                padding: '4px 12px', borderRadius: 5, border: 'none', fontSize: 12, fontWeight: 500,
                background: page === id ? '#1a1a18' : 'transparent',
                color: page === id ? '#fff' : '#888', transition: 'all 0.12s',
              }}>{label}</button>
            ))}
          </div>
        </div>
        <span style={{ fontFamily: "'IBM Plex Mono', monospace", fontSize: 9, color: '#bbb', letterSpacing: 2 }}>
          NSE · INDIA
        </span>
      </nav>

      <div style={{ flex: 1, overflow: 'hidden' }}>
        {page === 'dashboard' && <Dashboard />}
        {page === 'replay'    && <ReplayPage />}
      </div>
    </div>
  )
}
