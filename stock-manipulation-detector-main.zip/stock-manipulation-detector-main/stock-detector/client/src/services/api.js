// src/services/api.js
// All HTTP calls to the Node.js backend REST API.

import axios from 'axios'

const api = axios.create({
  baseURL: import.meta.env.VITE_SERVER_URL || 'http://localhost:3001',
  timeout: 35000,  // 35s for LangChain analysis (takes 3-8s)
})

// ── Alerts ──────────────────────────────────────────────────────────────

export async function fetchAlerts({ symbol, limit = 50 } = {}) {
  const params = { limit }
  if (symbol) params.symbol = symbol
  const { data } = await api.get('/api/alerts', { params })
  return data
}

// ── Stocks ──────────────────────────────────────────────────────────────

export async function fetchAllStocks() {
  const { data } = await api.get('/api/stocks')
  return data
}

export async function fetchStockHistory(symbol, count = 100) {
  const { data } = await api.get(`/api/stocks/${symbol}/history`, {
    params: { count }
  })
  return data
}

// ── AI Analysis ─────────────────────────────────────────────────────────

export async function runAnalysis(alertContext) {
  const { data } = await api.post('/api/analyze', alertContext)
  return data
}

// ── Health ──────────────────────────────────────────────────────────────

export async function fetchHealth() {
  const { data } = await api.get('/health', { timeout: 3000 })
  return data
}
