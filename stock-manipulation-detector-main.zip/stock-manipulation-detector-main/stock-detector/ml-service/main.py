# ml-service/main.py — COMPLETE REPLACEMENT FILE
# FastAPI ML service v3.1 — 5-layer ensemble
# Layers: Z-score + IF + RF + LSTM-AE + Vanilla-AE + CF (DS combination)

import json, os
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Optional

import numpy as np
import torch
import redis.asyncio as aioredis
from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from loguru import logger
from dotenv import load_dotenv

load_dotenv(dotenv_path=Path(__file__).parent.parent / ".env")

from detector.features             import extract_features, features_to_dict, FEATURE_NAMES, FEAT_DIM
from detector.zscore_rules         import detect_zscore
from detector.isolation_forest     import detector as if_detector
from detector.lstm_autoencoder     import lstm_ae_detector, SEQ_LEN
from detector.autoencoder          import vanilla_ae          # NEW sklearn AE
from detector.collaborative_filter import cf_filter
from detector.ensemble             import compute_ensemble_score
from detector.shap_explainer       import shap_explainer
from detector.concept_drift        import drift_monitor

REDIS_URL = os.getenv("REDIS_CLOUD_URL") or os.getenv("REDIS_URL", "redis://localhost:6379")
redis_client: Optional[aioredis.Redis] = None

price_history:   dict[str, list] = {}
feature_history: dict[str, list] = {}
tick_counts:     dict[str, int]  = {}


class TickPayload(BaseModel):
    symbol:    str
    price:     float
    volume:    int
    high:      Optional[float] = None
    low:       Optional[float] = None
    timestamp: Optional[str]   = None
    source:    Optional[str]   = "unknown"

class AnalyzeRequest(BaseModel):
    symbol:          str
    alert_type:      str
    price:           float
    volume:          int
    ensemble_score:  float
    if_score:        Optional[float] = 0.0
    rf_score:        Optional[float] = 0.0
    lstm_score:      Optional[float] = 0.0
    cf_signal:       Optional[str]   = "NEUTRAL"
    co_moving_peers: Optional[list]  = []
    context:         Optional[str]   = ""


@asynccontextmanager
async def lifespan(app: FastAPI):
    global redis_client
    try:
        redis_client = aioredis.from_url(
    REDIS_URL,
    decode_responses=True,
    socket_connect_timeout=5,
    socket_keepalive=True,
    retry_on_timeout=True,
    health_check_interval=30,
)
        await redis_client.ping()
        logger.info(f"Redis connected: {REDIS_URL}")
    except Exception as e:
        logger.warning(f"Redis unavailable: {e}")
        redis_client = None

    # Log all layer statuses
    layers = {
        "Isolation Forest":     if_detector.loaded,
        "LSTM Autoencoder":     lstm_ae_detector.loaded,
        "Vanilla Autoencoder":  vanilla_ae.loaded,      # NEW
        "SHAP Explainer":       shap_explainer.loaded,
        "Collaborative Filter": True,
        "Concept Drift (ADWIN)":True,
    }
    for name, ok in layers.items():
        logger.info(f"  {'✅' if ok else '⚠️ '} {name}: {'ready' if ok else 'not trained'}")

    yield
    if redis_client:
        await redis_client.close()


app = FastAPI(
    title="Stock Manipulation Detector — ML Service",
    description="5-layer ensemble: Z-score + IF + LSTM-AE + Vanilla-AE + CF | DS combination",
    version="3.1.0",
    lifespan=lifespan,
)
app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_methods=["*"], allow_headers=["*"])


# ── Core tick ingestion ───────────────────────────────────────────────────

@app.post("/ingest")
async def ingest_tick(tick: TickPayload, bg: BackgroundTasks):
    sym = tick.symbol.upper()

    if sym not in price_history:
        price_history[sym]   = []
        feature_history[sym] = []

    price_history[sym].append({
        "price":  tick.price, "volume": tick.volume,
        "high":   tick.high or tick.price,
        "low":    tick.low  or tick.price,
    })
    price_history[sym] = price_history[sym][-200:]

    # Feature extraction
    history  = price_history[sym][:-1]
    features = extract_features(
        tick.price, tick.volume,
        tick.high or tick.price,
        tick.low  or tick.price,
        history,
    )
    if features is None:
        return {"status": "insufficient_history", "symbol": sym,
                "ticks_so_far": len(price_history[sym])}

    features_dict = features_to_dict(features)

    # Layer 1: Z-score rules
    rule_result = detect_zscore(features_dict, sym)
    rule_score  = rule_result["rule_score"] if rule_result else 0.0

    # Layer 2: Isolation Forest
    if_score = if_detector.score(features)

    # Layer 3: LSTM Autoencoder (sequential)
    feature_history[sym].append(features.flatten().copy())
    feature_history[sym] = feature_history[sym][-SEQ_LEN * 3:]
    lstm_result = None
    if lstm_ae_detector.loaded and len(feature_history[sym]) >= SEQ_LEN:
        seq         = np.array(feature_history[sym][-SEQ_LEN:], dtype=np.float32)
        lstm_result = lstm_ae_detector.score_sequence(seq)

    # Layer 4: Vanilla Autoencoder (point anomaly, sklearn — no PyTorch)
    vanilla_result = vanilla_ae.score(features)

    # Layer 5: Collaborative Filter
    cf_result = cf_filter.compute_cf_score(sym, if_score)

    # Concept drift monitoring
    drift_result = drift_monitor.update(sym, if_score)
    if drift_result["should_retrain"]:
        bg.add_task(_retrain_if, sym)

    # 5-layer Dempster-Shafer ensemble
    ensemble = compute_ensemble_score(
        if_score, rule_score, sym, features,
        lstm_result, cf_result, vanilla_result
    )

    # SHAP (only on alerts)
    shap_result = {"available": False, "top_drivers": []}
    if ensemble["should_alert"] and shap_explainer.loaded:
        shap_result = shap_explainer.explain(features)

    # Fire alert
    if ensemble["should_alert"]:
        alert_type = rule_result["alert_type"] if rule_result else "ML_ANOMALY"
        alert_payload = {
            "symbol":            sym,
            "alert_type":        alert_type,
            "level":             ensemble["level"],
            "severity":          ensemble["ensemble_score"],
            "ensemble_score":    ensemble["ensemble_score"],
            "if_score":          ensemble["if_score"],
            "rf_score":          ensemble["rf_score"],
            "lstm_score":        ensemble["lstm_score"],
            "vanilla_ae_score":  ensemble["vanilla_ae_score"],
            "rule_score":        ensemble["rule_score"],
            "cf_score":          ensemble["cf_score"],
            "cf_signal":         ensemble["cf_signal"],
            "co_moving_peers":   ensemble["co_moving_peers"],
            "active_layers":     ensemble["active_layers"],
            "shap_top_drivers":  shap_result.get("top_drivers", []),
            "price":             tick.price,
            "volume":            tick.volume,
            "detail": (
                rule_result["detail"] if rule_result else
                f"Ensemble={ensemble['ensemble_score']:.3f} "
                f"IF={ensemble['if_score']:.3f} "
                f"VanillaAE={ensemble['vanilla_ae_score']:.3f}"
            ),
            "raw_features": features_dict,
            "created_at":   tick.timestamp or datetime.utcnow().isoformat(),
        }
        if redis_client:
            try:
                await redis_client.publish("alert:new", json.dumps(alert_payload))
                logger.info(
                    f"🚨 {sym} {alert_type} "
                    f"score={ensemble['ensemble_score']:.3f} [{ensemble['level']}] "
                    f"layers={ensemble['active_layers']}"
                )
            except Exception as e:
                logger.error(f"Redis publish: {e}")

    tick_counts[sym] = tick_counts.get(sym, 0) + 1

    return {
        "status":  "scored",
        "symbol":  sym,
        **{k: ensemble[k] for k in [
            "ensemble_score", "if_score", "rf_score", "lstm_score",
            "vanilla_ae_score", "rule_score", "cf_score",
            "cf_signal", "co_moving_peers", "level",
            "should_alert", "active_layers",
        ]},
        "shap_top_drivers": shap_result.get("top_drivers", []),
        "drift": {
            "detected":    drift_result["drift_detected"],
            "window_mean": drift_result["window_mean"],
        },
    }


# ── LangChain analysis ────────────────────────────────────────────────────

@app.post("/analyze")
async def analyze_alert(req: AnalyzeRequest):
    logger.info(f"Analysis: {req.symbol} {req.alert_type}")
    sym = req.symbol.upper()

    features_dict = {}
    current_feats = None
    if sym in price_history and len(price_history[sym]) >= 10:
        hist = price_history[sym][:-1]
        last = price_history[sym][-1]
        feats = extract_features(last["price"], last["volume"],
                                  last.get("high", last["price"]),
                                  last.get("low",  last["price"]), hist)
        if feats is not None:
            features_dict = features_to_dict(feats)
            current_feats = feats

    # SHAP
    shap_result = {"available": False, "top_drivers": []}
    if current_feats is not None and shap_explainer.loaded:
        shap_result = shap_explainer.explain(current_feats)

    # Video signal
    video_result = {"available": False, "composite_score": 0}
    try:
        from detector.social_video_signal import video_signal
        import yfinance as yf
        company = ""
        try:
            company = yf.Ticker(f"{sym}.NS").info.get("longName", "")
        except Exception:
            pass
        video_result = video_signal.scan(sym, company)
    except Exception:
        pass

    try:
        from langchain_agent.agent import run_analysis
        cf_context = cf_filter.compute_cf_score(sym, req.ensemble_score)
        result = run_analysis({
            "symbol": req.symbol, "alert_type": req.alert_type,
            "price": req.price, "volume": req.volume,
            "ensemble_score": req.ensemble_score,
            "if_score": req.if_score, "rf_score": req.rf_score,
            "lstm_score": req.lstm_score, "features": features_dict,
            "cf_signal": req.cf_signal or cf_context.get("cf_signal", "NEUTRAL"),
            "co_moving_peers": req.co_moving_peers or cf_context.get("co_moving_peers", []),
        })
        return {**result, "shap": shap_result, "video": video_result}
    except Exception as e:
        logger.error(f"Analysis: {e}")
        return {
            "analysis": f"LangChain error: {e}",
            "manipulation_probability": int(min(80, req.ensemble_score * 100)),
            "manipulation_type": "UNCLEAR", "recommended_action": "MONITOR",
            "evidence": [f"Ensemble={req.ensemble_score:.3f}"],
            "news_summary": "LLM unavailable", "social_summary": "LLM unavailable",
            "sebi_status": "Not checked", "pattern_match": "Not checked",
            "reasoning": "LLM unavailable", "tools_called": [],
            "llm_provider": "fallback", "ml_context": {},
            "shap": shap_result, "video": video_result,
        }


# ── Replay endpoints ──────────────────────────────────────────────────────

@app.get("/replay/cases")
async def get_replay_cases():
    try:
        from replay.fetch_manipulation_cases import list_cases
        return list_cases()
    except Exception as e:
        raise HTTPException(500, str(e))

@app.get("/replay/cases/{case_id}")
async def get_replay_case(case_id: str):
    try:
        from replay.fetch_manipulation_cases import load_case_data
        data = load_case_data(case_id)
        if not data: raise HTTPException(404, f"Case not found: {case_id}")
        return data
    except HTTPException: raise
    except Exception as e: raise HTTPException(500, str(e))

@app.post("/replay/score/{case_id}")
async def score_replay_case(case_id: str):
    try:
        from replay.fetch_manipulation_cases import load_case_data, CASES
        case_meta = next((c for c in CASES if c["id"] == case_id), None)
        if not case_meta: raise HTTPException(404, f"Case {case_id} not found")
        data = load_case_data(case_id)
        if not data or not data.get("daily"):
            raise HTTPException(404, "No data. Run fetch_manipulation_cases.py")

        rows = data["daily"]; sym = case_meta["symbol"]
        scored = []; hist_b = []; feat_b = []

        for row in rows:
            price  = float(row["close"]); volume = int(row["volume"])
            high   = float(row.get("high", price)); low = float(row.get("low", price))

            if len(hist_b) < 10:
                hist_b.append({"price":price,"volume":volume,"high":high,"low":low})
                scored.append({**row,"ensemble_score":0.0,"if_score":0.0,"rf_score":0.0,
                               "lstm_score":0.0,"vanilla_ae_score":0.0,"rule_score":0.0,
                               "cf_score":0.0,"level":"NONE","alert_fired":False,"shap_top_drivers":[]})
                continue

            feats = extract_features(price, volume, high, low, hist_b)
            if feats is None:
                hist_b.append({"price":price,"volume":volume,"high":high,"low":low})
                scored.append({**row,"ensemble_score":0.0,"level":"NONE","alert_fired":False,"shap_top_drivers":[]})
                continue

            fd         = features_to_dict(feats)
            rule_r     = detect_zscore(fd, sym)
            rule_score = rule_r["rule_score"] if rule_r else 0.0
            if_sc      = if_detector.score(feats)

            feat_b.append(feats.flatten().copy())
            feat_b = feat_b[-SEQ_LEN*3:]
            lstm_r = None
            if lstm_ae_detector.loaded and len(feat_b) >= SEQ_LEN:
                lstm_r = lstm_ae_detector.score_sequence(np.array(feat_b[-SEQ_LEN:], dtype=np.float32))

            vae_r  = vanilla_ae.score(feats)
            cf_r   = cf_filter.compute_cf_score(sym, if_sc)
            ens    = compute_ensemble_score(if_sc, rule_score, sym, feats, lstm_r, cf_r, vae_r)

            shap_d = []
            if ens["should_alert"] and shap_explainer.loaded:
                sh = shap_explainer.explain(feats)
                shap_d = sh.get("top_drivers", [])

            hist_b.append({"price":price,"volume":volume,"high":high,"low":low})
            scored.append({
                **row,
                "ensemble_score":   ens["ensemble_score"],
                "if_score":         ens["if_score"],
                "rf_score":         ens["rf_score"],
                "lstm_score":       ens["lstm_score"],
                "vanilla_ae_score": ens["vanilla_ae_score"],
                "rule_score":       ens["rule_score"],
                "cf_score":         ens["cf_score"],
                "cf_signal":        ens["cf_signal"],
                "level":            ens["level"],
                "alert_fired":      ens["should_alert"],
                "active_layers":    ens["active_layers"],
                "shap_top_drivers": shap_d,
            })

        es   = case_meta["event_start"]; ee = case_meta["event_end"]
        ev_r = [r for r in scored if es <= str(r.get("datetime",""))[:10] <= ee]
        alts = sum(1 for r in ev_r if r.get("alert_fired"))

        return {
            "case_id": case_id, "symbol": sym,
            "event_start": es, "event_end": ee,
            "rows": scored,
            "stats": {
                "total_bars":      len(scored),
                "event_bars":      len(ev_r),
                "alerts_in_event": alts,
                "detection_rate":  round(alts / max(len(ev_r),1), 3),
                "max_ensemble":    round(max((r["ensemble_score"] for r in ev_r), default=0), 3),
                "layers_active":   list(set(l for r in scored for l in r.get("active_layers",[]))),
                "simulated":       case_meta.get("simulated", False),
            },
        }
    except HTTPException: raise
    except Exception as e:
        logger.error(f"Replay score: {e}")
        raise HTTPException(500, str(e))


# ── Utility endpoints ─────────────────────────────────────────────────────

@app.get("/shap/global")
async def shap_global():
    if not shap_explainer.loaded:
        raise HTTPException(503, "SHAP not loaded. Run trainer/train.py first.")
    return {"feature_importance": shap_explainer.global_feature_importance()}

@app.get("/drift")
async def get_drift():
    return {"per_symbol": drift_monitor.summary(), "global": drift_monitor.global_drift_summary()}

@app.get("/correlations")
async def get_correlations():
    return {"matrix": cf_filter.correlation_matrix, "summary": cf_filter.summary()}

@app.post("/retrain/{symbol}")
async def retrain_symbol(symbol: str, bg: BackgroundTasks):
    bg.add_task(_retrain_if, symbol.upper())
    return {"status": "scheduled", "symbol": symbol.upper()}

@app.get("/health")
async def health():
    redis_ok = False
    if redis_client:
        try: await redis_client.ping(); redis_ok = True
        except Exception: pass
    return {
        "status":  "ok", "version": "3.1.0",
        "layers": {
            "isolation_forest":    if_detector.loaded,
            "lstm_autoencoder":    lstm_ae_detector.loaded,
            "vanilla_autoencoder": vanilla_ae.loaded,
            "shap_explainer":      shap_explainer.loaded,
            "collaborative_filter": True,
            "concept_drift":       True,
        },
        "symbols_tracked":  list(price_history.keys()),
        "tick_counts":      tick_counts,
        "cf_summary":       cf_filter.summary(),
        "drift_global":     drift_monitor.global_drift_summary(),
        "redis_connected":  redis_ok,
        "llm_provider":     os.getenv("LLM_PROVIDER", "groq"),
    }


async def _retrain_if(symbol: str):
    hist = price_history.get(symbol, [])
    if len(hist) < 50: return
    try:
        from sklearn.ensemble import IsolationForest
        from sklearn.preprocessing import StandardScaler
        feat_rows = []
        for i in range(20, len(hist)):
            feats = extract_features(hist[i]["price"], hist[i]["volume"],
                                      hist[i].get("high", hist[i]["price"]),
                                      hist[i].get("low",  hist[i]["price"]),
                                      hist[max(0,i-20):i])
            if feats is not None: feat_rows.append(feats.flatten())
        if len(feat_rows) < 30: return
        X  = np.array(feat_rows, dtype=np.float32)
        sc = StandardScaler()
        m  = IsolationForest(n_estimators=200, contamination=0.05, random_state=42)
        m.fit(sc.fit_transform(X))
        if_detector.model = m; if_detector.scaler = sc; if_detector.loaded = True
        shap_explainer.reload()
        logger.info(f"Retrained IF for {symbol}")
    except Exception as e:
        logger.error(f"Retrain {symbol}: {e}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
