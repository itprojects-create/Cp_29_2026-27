# ml-service/langchain_agent/tools.py
#
# Investigation tools for the LangChain agent.
# These run on YOUR machine where all external APIs are accessible.
#
# SOURCES (all work on your machine, most need no key):
#
#   Tool 1 — News Scanner
#     • yfinance .news (free, no key)           ← primary
#     • gnews library (free, no key)            ← secondary
#     • feedparser on Indian RSS feeds           ← fallback
#
#   Tool 2 — SEBI/NSE Announcements
#     • NSE API with session cookie             ← primary (free)
#     • NSE Bhavcopy delivery data             ← secondary
#
#   Tool 3 — Social Media
#     • StockTwits public JSON (free, no key)  ← primary
#     • twitterapi.io (pay-per-use, ~₹0.01)   ← if key set
#     • Reddit public JSON (no OAuth needed)   ← always works
#       reddit.com/r/X.json?q=SYMBOL works with just User-Agent
#       No API key needed for READ-ONLY search
#
#   Tool 4 — Historical Pattern Match
#     • In-memory comparison (no API)
#
# REDDIT NOTE:
#   Reddit's PUBLIC search endpoint (reddit.com/r/sub/search.json)
#   works with just a proper User-Agent header — no OAuth, no API key.
#   Rate limit: 60 requests/minute. Sufficient for on-demand analysis.
#   If you want more: reddit.com/prefs/apps → create "script" app → free.

import os, json, time, requests, feedparser
from datetime import datetime, timedelta
from loguru import logger
from langchain_core.tools import tool

# ── Shared session with proper headers ───────────────────────────────────
def _session():
    s = requests.Session()
    s.headers.update({
        "User-Agent": "StockManipulationDetector/2.0 (Research Project; contact@vesit.edu.in)",
        "Accept": "application/json, application/rss+xml, */*",
        "Accept-Language": "en-IN,en;q=0.9",
    })
    return s


# ══════════════════════════════════════════════════════════════════════════
# TOOL 1 — NEWS SCANNER
# Returns: headlines, sources, detected catalysts, sentiment
# ══════════════════════════════════════════════════════════════════════════

@tool
def search_news_tool(symbol: str) -> str:
    """
    Scan news sources for recent coverage of an NSE stock.
    Looks for legitimate catalysts (earnings, M&A, RBI/SEBI actions).
    If no catalyst found during a price+volume spike, that is a manipulation signal.
    Returns structured list of headlines with sources and dates.
    """
    headlines    = []
    catalysts    = set()
    all_text     = ""
    sources_used = []

    CATALYST_KW = {
        "earnings":    ["earnings", "results", "profit", "revenue", "q1", "q2", "q3", "q4", "quarterly"],
        "corporate":   ["bonus", "dividend", "split", "rights issue", "buyback", "merger", "acquisition"],
        "regulatory":  ["sebi", "rbi", "circular", "ban", "suspension", "order", "penalty"],
        "analyst":     ["target price", "upgrade", "downgrade", "rating", "buy", "sell", "hold"],
        "insider":     ["promoter", "stake", "insider", "block deal", "bulk deal"],
    }

    # ── Source 1: yfinance news (most reliable for NSE) ──────────────
    try:
        import yfinance as yf
        ticker = yf.Ticker(f"{symbol}.NS")
        news   = ticker.news or []
        for n in news[:8]:
            title  = n.get("title", "")
            pub    = n.get("publisher", "Unknown")
            ts     = n.get("providerPublishTime", 0)
            date   = datetime.fromtimestamp(ts).strftime("%d %b") if ts else ""
            headlines.append(f"• [{pub}] {title} ({date})")
            all_text += " " + title.lower()
        if news:
            sources_used.append(f"yfinance ({len(news)} articles)")
    except Exception as e:
        logger.debug(f"yfinance news: {e}")

    # ── Source 2: gnews ───────────────────────────────────────────────
    if len(headlines) < 4:
        try:
            from gnews import GNews
            gn  = GNews(language="en", country="IN", period="3d", max_results=8)
            res = gn.get_news(f"{symbol} NSE India stock")
            for a in res:
                title  = a.get("title", "")
                pub    = a.get("publisher", {}).get("title", "Unknown")
                date   = a.get("published date", "")[:10]
                if title and title not in [h.split("] ")[1][:30] if "] " in h else "" for h in headlines]:
                    headlines.append(f"• [{pub}] {title} ({date})")
                    all_text += " " + title.lower()
            if res:
                sources_used.append(f"GNews ({len(res)} articles)")
        except Exception as e:
            logger.debug(f"gnews: {e}")

    # ── Source 3: RSS fallbacks ───────────────────────────────────────
    if len(headlines) < 3:
        rss_feeds = [
            ("Economic Times", f"https://economictimes.indiatimes.com/markets/rss.cms"),
            ("Moneycontrol",   "https://www.moneycontrol.com/rss/MCtopnews.xml"),
        ]
        for feed_name, url in rss_feeds:
            try:
                feed = feedparser.parse(url)
                sym_lower = symbol.lower()
                for entry in feed.entries[:30]:
                    title = entry.get("title", "")
                    if sym_lower in title.lower() or symbol in title:
                        date = entry.get("published", "")[:16]
                        headlines.append(f"• [{feed_name}] {title} ({date})")
                        all_text += " " + title.lower()
                if feed.entries:
                    sources_used.append(f"{feed_name} RSS")
            except Exception:
                pass

    # ── Detect catalysts ──────────────────────────────────────────────
    for cat, keywords in CATALYST_KW.items():
        if any(kw in all_text for kw in keywords):
            catalysts.add(cat)

    # ── Format output ─────────────────────────────────────────────────
    if not headlines:
        return (
            f"NO NEWS FOUND for {symbol} in last 72 hours.\n"
            "Sources checked: yfinance, GNews, RSS feeds\n"
            "⚠️  Absence of news during a price+volume spike is itself a manipulation signal.\n"
            "Recommend: proceed to social media scan and pattern match."
        )

    out  = f"NEWS FOR {symbol} (last 72h) — Sources: {', '.join(sources_used)}\n"
    out += "\n".join(headlines[:8])
    out += "\n"

    if catalysts:
        out += f"\n✅ LEGITIMATE CATALYSTS DETECTED: {', '.join(catalysts).upper()}\n"
        out += "→ Price/volume move may have a fundamental explanation.\n"
        out += "→ Lower manipulation probability. Verify with SEBI announcements."
    else:
        out += "\n⚠️  NO LEGITIMATE CATALYSTS FOUND\n"
        out += "→ No earnings, no corporate actions, no regulatory news.\n"
        out += "→ Unexplained price/volume move — manipulation probability elevated."

    return out


# ══════════════════════════════════════════════════════════════════════════
# TOOL 2 — SEBI/NSE ANNOUNCEMENTS
# ══════════════════════════════════════════════════════════════════════════

@tool
def check_sebi_announcements_tool(symbol: str) -> str:
    """
    Check NSE corporate announcements and SEBI surveillance lists for a stock.
    Corporate actions (bonus, split, dividend) legitimately explain volume spikes.
    ASM/GSM listing means SEBI already suspects this stock.
    Returns structured announcement data and surveillance status.
    """
    findings = []
    s        = _session()
    s.headers["Referer"] = "https://www.nseindia.com"

    # ── Step 1: Establish NSE session cookie ─────────────────────────
    try:
        s.get("https://www.nseindia.com", timeout=6)
        time.sleep(0.3)
    except Exception:
        pass

    # ── Step 2: Corporate announcements ──────────────────────────────
    try:
        r = s.get(
            f"https://www.nseindia.com/api/corp-info?index={symbol}&section=corp_announcements",
            timeout=10
        )
        if r.status_code == 200:
            anns = r.json().get("data", [])[:5]
            if anns:
                findings.append(f"NSE CORPORATE ANNOUNCEMENTS ({symbol}):")
                for a in anns:
                    desc = a.get("desc", a.get("subject", "Unknown"))
                    date = a.get("date", "")
                    findings.append(f"  • {desc} [{date}]")
            else:
                findings.append(f"No recent corporate announcements for {symbol}")
        else:
            findings.append(f"NSE announcements: HTTP {r.status_code}")
    except Exception as e:
        findings.append(f"NSE announcements unavailable: {e}")

    # ── Step 3: Check ASM (Additional Surveillance Measure) list ─────
    try:
        r2 = s.get("https://www.nseindia.com/api/reportsmf?index=ASM", timeout=8)
        if r2.status_code == 200:
            asm_syms = [x.get("symbol","") for x in r2.json().get("data", [])]
            if symbol in asm_syms:
                findings.append(f"\n🚨 {symbol} IS ON ASM LIST")
                findings.append("→ SEBI already flagged as high-risk/suspicious trading.")
                findings.append("→ This STRONGLY supports manipulation hypothesis.")
            else:
                findings.append(f"\n✅ {symbol} NOT on ASM list (not yet flagged by SEBI)")
        else:
            findings.append(f"\nASM check: HTTP {r2.status_code}")
    except Exception as e:
        findings.append(f"\nASM check unavailable: {e}")

    # ── Step 4: Delivery percentage (manipulation signal) ────────────
    try:
        r3 = s.get(
            f"https://www.nseindia.com/api/quote-equity?symbol={symbol}",
            timeout=8
        )
        if r3.status_code == 200:
            d    = r3.json()
            cm   = d.get("securityInfo", {})
            deliv_pct = cm.get("deliveryToTradedQuantity")
            if deliv_pct is not None:
                findings.append(f"\nDELIVERY %: {deliv_pct}%")
                if float(deliv_pct) < 20:
                    findings.append("⚠️  Very low delivery % — speculative intraday trading dominant.")
                    findings.append("→ Low delivery during volume spike = wash trading / circular trading signal.")
                elif float(deliv_pct) > 60:
                    findings.append("→ High delivery % — genuine investor buying (less suspicious).")
    except Exception as e:
        logger.debug(f"Delivery data: {e}")

    return "\n".join(findings) if findings else f"SEBI/NSE data unavailable for {symbol}."


# ══════════════════════════════════════════════════════════════════════════
# TOOL 3 — SOCIAL MEDIA SENTIMENT
# Sources: StockTwits (free) + Reddit (free, no key) + twitterapi.io (cheap)
# ══════════════════════════════════════════════════════════════════════════

PUMP_KEYWORDS = [
    "moon", "rocket", "🚀", "squeeze", "buy now", "load up", "100x",
    "guaranteed", "easy money", "don't miss", "yolo", "calls", "target",
    "breakout", "next gme", "multibagger", "sureshot", "sure shot",
]

@tool
def social_sentiment_tool(symbol: str) -> str:
    """
    Scan social media for coordinated pump signals around an NSE stock.
    Checks StockTwits (free), Reddit (free, no key needed), twitterapi.io.
    High bullish skew + pump language + volume spike + no news = coordination signal.
    Returns: post counts, sentiment ratios, pump keyword counts, top posts.
    """
    results      = []
    total_signal = 0
    signal_count = 0

    # ── StockTwits ────────────────────────────────────────────────────
    try:
        s  = _session()
        r  = s.get(
            f"https://api.stocktwits.com/api/2/streams/symbol/{symbol}.json",
            timeout=8
        )
        if r.status_code == 200:
            data     = r.json()
            messages = data.get("messages", [])
            sym_info = data.get("symbol", {})
            total    = len(messages)

            bull = sum(1 for m in messages
                       if m.get("entities",{}).get("sentiment",{}).get("basic") == "Bullish")
            bear = sum(1 for m in messages
                       if m.get("entities",{}).get("sentiment",{}).get("basic") == "Bearish")
            pump_count = sum(
                1 for m in messages
                if any(kw in m.get("body","").lower() for kw in PUMP_KEYWORDS)
            )
            bull_pct = (bull / total * 100) if total > 0 else 0
            watchlist_ct = sym_info.get("watchlist_count", 0)

            st_block = [
                f"STOCKTWITS ({symbol}):",
                f"  Posts in feed:     {total}",
                f"  Watchlist count:   {watchlist_ct:,}",
                f"  Bullish:           {bull} ({bull_pct:.0f}%)",
                f"  Bearish:           {bear}",
                f"  Pump-language:     {pump_count} posts",
            ]

            signal = 0
            if bull_pct > 80 and total > 20:
                st_block.append(f"  ⚠️  EXTREME BULLISH SKEW ({bull_pct:.0f}%) — coordination signal")
                signal += 40
            elif bull_pct > 65:
                st_block.append(f"  ⚠️  Elevated bullish ({bull_pct:.0f}%)")
                signal += 15
            if pump_count > 5:
                st_block.append(f"  ⚠️  {pump_count} pump-language posts detected")
                signal += min(30, pump_count * 4)

            st_block.append(f"  Social signal score: {signal}/100")
            results.append("\n".join(st_block))
            total_signal += signal; signal_count += 1
        elif r.status_code == 403:
            results.append("StockTwits: Rate limited (403). Try again in 30s.")
        else:
            results.append(f"StockTwits: HTTP {r.status_code}")
    except Exception as e:
        results.append(f"StockTwits: {e}")

    # ── Reddit (NO API KEY NEEDED — public JSON endpoint) ─────────────
    # reddit.com/r/X/search.json with User-Agent works without OAuth
    # Rate limit: 60 req/min, sufficient for on-demand analysis
    try:
        s = _session()
        # Search multiple relevant subreddits
        reddit_posts = []
        subreddits   = [
            "IndiaInvestments", "DalalStreetTalks",
            "IndianStreetBets", "stocks"
        ]
        for sub in subreddits:
            try:
                r = s.get(
                    f"https://www.reddit.com/r/{sub}/search.json",
                    params={"q": symbol, "sort": "new", "limit": 10, "t": "week"},
                    timeout=8
                )
                if r.status_code == 200:
                    posts = r.json().get("data", {}).get("children", [])
                    for p in posts:
                        d = p.get("data", {})
                        reddit_posts.append({
                            "title":    d.get("title", ""),
                            "score":    d.get("score", 0),
                            "comments": d.get("num_comments", 0),
                            "sub":      sub,
                            "url":      d.get("url", ""),
                        })
            except Exception:
                continue
            time.sleep(0.2)

        if reddit_posts:
            total_engagement = sum(p["score"] + p["comments"] for p in reddit_posts)
            pump_posts = [p for p in reddit_posts
                          if any(kw in p["title"].lower() for kw in PUMP_KEYWORDS)]
            signal = 0
            if len(pump_posts) > 5: signal += min(35, len(pump_posts) * 5)
            if total_engagement > 500: signal += 15

            rd_block = [
                f"\nREDDIT ({symbol}) — no API key required:",
                f"  Posts found (last 7d): {len(reddit_posts)}",
                f"  Total engagement:      {total_engagement:,}",
                f"  Pump-language posts:   {len(pump_posts)}",
            ]
            if pump_posts:
                rd_block.append("  Top pump posts:")
                for p in sorted(pump_posts, key=lambda x: x["score"], reverse=True)[:3]:
                    rd_block.append(f"    • r/{p['sub']}: {p['title'][:70]}")
            rd_block.append(f"  Social signal score: {signal}/100")
            results.append("\n".join(rd_block))
            total_signal += signal; signal_count += 1
        else:
            results.append(f"\nReddit: No posts found for {symbol} in last 7 days")
    except Exception as e:
        results.append(f"\nReddit: {e}")

    # ── Twitter/X via twitterapi.io ───────────────────────────────────
    tw_key = os.getenv("TWITTERAPI_IO_KEY", "")
    if tw_key:
        try:
            s = _session()
            r = s.get(
                "https://api.twitterapi.io/twitter/tweet/advanced_search",
                params={"query": f"${symbol} OR #{symbol}NSE lang:en -is:retweet",
                        "queryType": "Latest", "count": "50"},
                headers={"X-API-Key": tw_key},
                timeout=12
            )
            if r.status_code == 200:
                tweets = r.json().get("tweets", [])
                total  = len(tweets)
                authors = set(t.get("author",{}).get("userName","") for t in tweets)
                diversity = len(authors) / total if total > 0 else 1
                pump_tw  = [t for t in tweets
                             if any(kw in t.get("text","").lower() for kw in PUMP_KEYWORDS)]
                signal = 0
                if diversity < 0.3: signal += 35
                if len(pump_tw) > 10: signal += min(35, len(pump_tw) * 2)
                if total > 100: signal += 15

                tw_block = [
                    f"\nTWITTER/X via twitterapi.io (${symbol}):",
                    f"  Tweets found:     {total}",
                    f"  Unique authors:   {len(authors)} ({diversity:.0%} diversity)",
                    f"  Pump tweets:      {len(pump_tw)}",
                ]
                if diversity < 0.3:
                    tw_block.append(f"  ⚠️  LOW AUTHOR DIVERSITY — possible bot network")
                if pump_tw:
                    tw_block.append("  Sample pump tweets:")
                    for t in sorted(pump_tw, key=lambda x: x.get("likeCount",0), reverse=True)[:3]:
                        tw_block.append(f"    • @{t.get('author',{}).get('userName','?')}: "
                                        f"{t.get('text','')[:70]}")
                tw_block.append(f"  Social signal score: {signal}/100")
                results.append("\n".join(tw_block))
                total_signal += signal; signal_count += 1
            elif r.status_code == 429:
                results.append("\nTwitter/X: Rate limited — try again in 60s")
            else:
                results.append(f"\nTwitter/X: HTTP {r.status_code}")
        except Exception as e:
            results.append(f"\nTwitter/X: {e}")
    else:
        results.append(
            "\nTwitter/X: TWITTERAPI_IO_KEY not set.\n"
            "  Add to .env for Twitter scanning (~₹0.01/query at twitterapi.io).\n"
            "  Not required — StockTwits + Reddit cover most Indian retail pump signals."
        )

    # ── Composite score summary ───────────────────────────────────────
    avg_signal = total_signal / signal_count if signal_count > 0 else 0
    if avg_signal > 60:
        summary = f"\n🚨 HIGH SOCIAL SIGNAL ({avg_signal:.0f}/100) — Strong coordination evidence"
    elif avg_signal > 30:
        summary = f"\n⚠️  MODERATE SOCIAL SIGNAL ({avg_signal:.0f}/100) — Some coordination indicators"
    else:
        summary = f"\n✅ LOW SOCIAL SIGNAL ({avg_signal:.0f}/100) — Normal social activity"

    return "\n".join(results) + summary


# ══════════════════════════════════════════════════════════════════════════
# TOOL 4 — HISTORICAL PATTERN MATCH
# ══════════════════════════════════════════════════════════════════════════

HISTORICAL_PATTERNS = [
    {
        "name": "Yes Bank Coordinated Dump (Mar 2020)",
        "type": "COORDINATED_DUMP",
        "signature": "Volume 15-20x normal, price -80% in 4 days, institutional coordination",
        "vol_zscore_min": 8, "r5_min": -0.8, "r5_max": -0.3,
        "sebi_ref": "SEBI adjudication order 2021-02-18, penalty ₹10.85cr",
    },
    {
        "name": "Adani Group Short Attack (Jan 2023)",
        "type": "SHORT_ATTACK",
        "signature": "Sustained 2-week selling, pre-positioned shorts, media coordination",
        "vol_zscore_min": 3, "r5_min": -0.5, "r5_max": -0.15,
        "sebi_ref": "SEBI show-cause notice 2023, Supreme Court expert committee",
    },
    {
        "name": "Zomato IPO Pump (Jul 2021)",
        "type": "IPO_PUMP",
        "signature": "Volume 50x, +66% on listing day, retail FOMO buying",
        "vol_zscore_min": 10, "r5_min": 0.3, "r5_max": 2.0,
        "sebi_ref": "SEBI IPO surveillance circular 2021",
    },
    {
        "name": "Paytm IPO Dump (Nov 2021)",
        "type": "IPO_DUMP",
        "signature": "Volume 20x, -27% on listing day, coordinated institutional sell",
        "vol_zscore_min": 8, "r5_min": -0.4, "r5_max": -0.1,
        "sebi_ref": "SEBI market surveillance Q3 FY2022",
    },
    {
        "name": "Nykaa Bonus Dump (Nov 2022)",
        "type": "BONUS_DUMP",
        "signature": "Volume 8x before bonus record date, promoter exit via bonus",
        "vol_zscore_min": 4, "r5_min": -0.3, "r5_max": 0.1,
        "sebi_ref": "SEBI investigation 2022-23, led to bonus issue disclosure norms",
    },
    {
        "name": "Generic NSE Penny Pump-and-Dump",
        "type": "PUMP_AND_DUMP",
        "signature": "+20% in 5 days, volume 10x, then crash within 7 days",
        "vol_zscore_min": 5, "r5_min": 0.2, "r5_max": 2.0,
        "sebi_ref": "SEBI enforcement actions 2022-24 (multiple SME segment cases)",
    },
]


@tool
def historical_pattern_tool(features_json: str) -> str:
    """
    Compare current stock's anomaly features to confirmed SEBI manipulation cases.
    Input: JSON string with volume_zscore, returns_5d, price_zscore, etc.
    Returns: matching historical patterns, similarity assessment, SEBI case references.
    """
    try:
        features = json.loads(features_json) if isinstance(features_json, str) else {}
    except Exception:
        features = {}

    vol_z    = float(features.get("volume_zscore",    0))
    r5       = float(features.get("returns_5d",       0))
    r1       = float(features.get("returns_1d",       0))
    pv       = float(features.get("price_vol_interaction", 0))
    drawdown = float(features.get("drawdown_from_recent_high", 0))
    amihud   = float(features.get("amihud_illiquidity", 0))

    matches  = []
    for pat in HISTORICAL_PATTERNS:
        vol_match = abs(vol_z) >= pat["vol_zscore_min"]
        r5_match  = pat["r5_min"] <= r5 <= pat["r5_max"]
        if vol_match and r5_match:
            matches.append(pat)

    out = [
        "HISTORICAL PATTERN ANALYSIS",
        f"  Volume Z-score:         {vol_z:+.2f}σ",
        f"  5-day return:           {r5*100:+.1f}%",
        f"  1-day return:           {r1*100:+.1f}%",
        f"  Price×Vol interaction:  {pv:.2f}",
        f"  Drawdown from high:     {drawdown*100:.1f}%",
        f"  Amihud illiquidity Z:   {amihud:.2f}",
        "",
    ]

    if not matches:
        out.append("No close match to confirmed SEBI patterns.")
        out.append("→ Could be: (1) novel manipulation pattern, "
                   "(2) legitimate market event, or (3) IF false positive.")
        out.append("→ Recommend: proceed with social scan before concluding.")
    else:
        out.append(f"MATCHED {len(matches)} CONFIRMED SEBI CASE(S):")
        for m in matches:
            out.append(f"\n  ✅ MATCH: {m['name']}")
            out.append(f"     Type:      {m['type']}")
            out.append(f"     Signature: {m['signature']}")
            out.append(f"     SEBI ref:  {m['sebi_ref']}")

    return "\n".join(out)


# ══════════════════════════════════════════════════════════════════════════
# TOOL 5 — F&O OPTIONS PRE-SIGNAL
# Detects unusual options positioning that precedes price manipulation
# ══════════════════════════════════════════════════════════════════════════

@tool
def fno_presignal_tool(symbol: str) -> str:
    """
    Check NSE F&O option chain for unusual positioning that precedes manipulation.
    Looks for: extreme Put/Call ratio, OI concentration in OTM calls, IV spikes.
    Low PCR (<0.4) + concentrated OTM call OI = classic pre-pump options signal.
    Uses NSE public API — no authentication needed.
    """
    try:
        from detector.fno_presignal import get_fno_signal
        result = get_fno_signal(symbol)

        if not result.get("available"):
            return (
                f"F&O data unavailable for {symbol}. "
                "This may be a small-cap stock without liquid F&O contracts, "
                "or NSE API is temporarily unavailable. "
                "Proceed with equity-only analysis."
            )

        out = [
            f"F&O OPTIONS ANALYSIS ({symbol}):",
            f"  Put/Call Ratio:      {result['pcr']:.3f}  [{result['pcr_signal']}]",
            f"  Total Call OI:       {result['total_call_oi']:,}",
            f"  Total Put OI:        {result['total_put_oi']:,}",
            f"  ATM Implied Vol:     {result['atm_iv']:.1f}%",
            f"  OI Concentration:    {result['oi_concentration']*100:.1f}%",
            f"  IV Spike:            {'YES' if result['iv_spike'] else 'No'}",
            f"  Pre-Signal Score:    {result['signal_score']:.0f}/100",
            "",
            result["interpretation"],
        ]

        if result.get("unusual_strikes"):
            out.append("\n  Unusual OTM Call Strikes:")
            for s in result["unusual_strikes"][:4]:
                out.append(
                    f"    Strike ₹{s['strike']:,}  "
                    f"({s['distance_pct']:+.1f}% from ATM)  "
                    f"OI change: +{s['oi_change']:,}"
                )
            out.append(
                "  ⚠️  Concentrated OTM call buying is consistent with "
                "pre-pump options positioning (Pan & Poteshman 2006)"
            )

        return "\n".join(out)

    except Exception as e:
        return f"F&O pre-signal check failed: {e}"


# ══════════════════════════════════════════════════════════════════════════
# TOOL 6 — YOUTUBE + GOOGLE TRENDS SIGNAL (Sadhna Broadcast type)
# ══════════════════════════════════════════════════════════════════════════

@tool
def youtube_trends_tool(symbol: str) -> str:
    """
    Detect YouTube-driven manipulation campaigns (Sadhna Broadcast / Arshad Warsi pattern).
    Checks: YouTube video spike in last 7 days + Google Trends search interest spike.
    A YouTube views surge PRECEDING a price spike is the key Sadhna Broadcast signal.
    SEBI found YouTube/social video promotion preceded price manipulation by 2-5 days.
    Requires YOUTUBE_API_KEY in .env (free, 10,000 units/day at console.cloud.google.com).
    """
    try:
        from detector.social_video_signal import video_signal
        import yfinance as yf

        # Get company name for better YouTube search
        company_name = ""
        try:
            info = yf.Ticker(f"{symbol}.NS").info
            company_name = info.get("longName", "") or info.get("shortName", "")
        except Exception:
            pass

        result = video_signal.scan(symbol, company_name)

        if not result.get("available"):
            return (
                f"YouTube/Trends signal: YOUTUBE_API_KEY not set. "
                "Get free key at console.cloud.google.com → YouTube Data API v3. "
                "Google Trends check: unavailable. "
                "Manual YouTube search recommended for Sadhna-type case assessment."
            )

        out = [
            f"YOUTUBE + GOOGLE TRENDS ({symbol}):",
            f"  Video signal score:  {result['video_signal_score']:.0f}/100",
            f"  Trends signal score: {result['trends_signal_score']:.0f}/100",
            f"  Composite score:     {result['composite_score']:.0f}/100",
            f"  Google Trends spike: {'YES — ' + str(result.get('trends_data',{}).get('spike_ratio','?')) + 'x' if result['trends_spike'] else 'No'}",
            "",
            result["summary"],
        ]

        if result.get("suspicious_videos"):
            out.append("\n  Suspicious promotional videos detected:")
            for v in result["suspicious_videos"][:3]:
                out.append(
                    f"    • {v['title'][:70]}\n"
                    f"      Channel: {v['channel']}  |  Views: {v['views']:,}  "
                    f"  Keywords: {', '.join(v['keywords'][:3])}"
                )
            out.append(
                "\n  ⚠️  These videos match the Sadhna Broadcast pattern: "
                "misleading financial claims + high view counts + no legitimate news basis."
            )

        if result["composite_score"] > 60:
            out.append(
                "\n  SEBI PRECEDENT: Similar YouTube promotion patterns were the "
                "primary evidence in SEBI's Sadhna Broadcast order (April 2024). "
                "59 entities were barred, ₹21.45 crore penalty imposed."
            )

        return "\n".join(out)

    except Exception as e:
        return f"YouTube/Trends scan failed: {e}"
