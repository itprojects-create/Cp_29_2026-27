# ml-service/langchain_agent/agent.py
# LangChain agent — structured investigation with full evidence trail.
# Returns every piece of evidence the agent used, not just a verdict.

import os, re, json
from loguru import logger
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain.agents import AgentExecutor, create_tool_calling_agent

from .tools import (
    search_news_tool,
    check_sebi_announcements_tool,
    social_sentiment_tool,
    historical_pattern_tool,
    fno_presignal_tool,
    youtube_trends_tool,
)

SYSTEM_PROMPT = """You are a SEBI-trained financial crime analyst investigating NSE stock manipulation.

You have 6 tools. Use them intelligently:
1. search_news_tool            — find news catalysts FIRST (always call this)
2. check_sebi_announcements_tool — ASM list, delivery %, corporate actions
3. social_sentiment_tool       — StockTwits + Reddit + Twitter pump signals
4. historical_pattern_tool     — match to confirmed SEBI cases
5. fno_presignal_tool          — options PCR, OI concentration (call if large-cap)
6. youtube_trends_tool         — YouTube video + Google Trends (call if social score high)

DECISION LOGIC:
- Legitimate catalyst found (earnings, RBI, SEBI order, M&A) → LEGITIMATE, CLEAR
- No news + volume spike + high social signal → PUMP_AND_DUMP or COORDINATED_BUY
- Sustained selling + pre-positioned + media coordination → SHORT_ATTACK
- Around IPO/bonus date + extreme volume → IPO_PUMP or BONUS_DUMP

OUTPUT FORMAT — follow exactly, no deviation:
MANIPULATION_PROBABILITY: [0-100]
MANIPULATION_TYPE: [PUMP_AND_DUMP|COORDINATED_BUY|SHORT_ATTACK|WASH_TRADING|LEGITIMATE|UNCLEAR]
RECOMMENDED_ACTION: [CLEAR|MONITOR|ALERT_COMPLIANCE|FLAG_REGULATORY]

KEY_EVIDENCE:
• [finding 1 with specific numbers]
• [finding 2 with specific numbers]
• [finding 3 with specific numbers]
• [finding 4 if available]

NEWS_SUMMARY: [1 sentence on what news was/wasn't found]
SOCIAL_SUMMARY: [1 sentence on social media signal]
SEBI_STATUS: [ASM listed or not, any corporate action]
PATTERN_MATCH: [matched historical case or none]

REASONING: [2-3 sentences explaining the verdict with specific evidence references]"""


def _get_llm():
    provider = os.getenv("LLM_PROVIDER", "groq").lower()
    if provider == "groq":
        key = os.getenv("GROQ_API_KEY", "")
        if not key:
            logger.warning("GROQ_API_KEY not set — falling back to Ollama")
            return _get_ollama()
        try:
            from langchain_groq import ChatGroq
            llm = ChatGroq(model="llama-3.3-70b-versatile",
                           temperature=0, api_key=key, max_tokens=2048)
            logger.info("LLM: Groq llama-3.3-70b-versatile (free tier)")
            return llm
        except ImportError:
            return _get_ollama()
    return _get_ollama()


def _get_ollama():
    model   = os.getenv("OLLAMA_MODEL", "llama3.2")
    base    = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    try:
        from langchain_ollama import ChatOllama
        llm = ChatOllama(model=model, base_url=base, temperature=0)
        logger.info(f"LLM: Ollama {model} (local)")
        return llm
    except Exception as e:
        logger.error(f"Ollama unavailable: {e}")
        return None


def run_analysis(alert_context: dict) -> dict:
    """
    Run full investigation on an alert. Returns structured evidence + verdict.

    Input (alert_context):
        symbol, alert_type, price, volume, ensemble_score,
        if_score, rf_score, lstm_score, cf_signal, co_moving_peers,
        features (dict of 20 feature values)

    Output:
        {
          analysis: str,                   full raw LLM output
          manipulation_probability: int,
          manipulation_type: str,
          recommended_action: str,
          evidence: list[str],             bullet points
          news_summary: str,
          social_summary: str,
          sebi_status: str,
          pattern_match: str,
          reasoning: str,
          tools_called: list[str],
          llm_provider: str,
          ml_context: dict,                what ML layers said
        }
    """
    llm = _get_llm()
    if llm is None:
        return _fallback_analysis(alert_context)

    tools = [
        search_news_tool,
        check_sebi_announcements_tool,
        social_sentiment_tool,
        historical_pattern_tool,
        fno_presignal_tool,
        youtube_trends_tool,
    ]

    prompt = ChatPromptTemplate.from_messages([
        ("system", SYSTEM_PROMPT),
        ("human", "{input}"),
        MessagesPlaceholder(variable_name="agent_scratchpad"),
    ])

    # Build rich context for the LLM
    sym    = alert_context.get("symbol", "UNKNOWN")
    atype  = alert_context.get("alert_type", "ANOMALY")
    price  = alert_context.get("price", 0)
    vol    = alert_context.get("volume", 0)
    score  = alert_context.get("ensemble_score", 0)
    feats  = alert_context.get("features", {})

    vol_z   = feats.get("volume_zscore", 0)
    price_z = feats.get("price_zscore", 0)
    r5      = feats.get("returns_5d", 0)
    r1      = feats.get("returns_1d", 0)
    pv      = feats.get("price_vol_interaction", 0)
    amihud  = feats.get("amihud_illiquidity", 0)

    cf_signal = alert_context.get("cf_signal", "NEUTRAL")
    peers     = alert_context.get("co_moving_peers", [])

    user_input = f"""Investigate this NSE alert:

STOCK: {sym}
ALERT TYPE: {alert_type if (alert_type:=atype) else atype}
PRICE: ₹{price:.2f}
VOLUME: {vol:,}

ML DETECTION SCORES:
  Ensemble score:      {score:.3f}/1.00  (threshold 0.55 = alert fires)
  Isolation Forest:    {alert_context.get('if_score',0):.3f}
  Random Forest:       {alert_context.get('rf_score',0):.3f}
  LSTM Autoencoder:    {alert_context.get('lstm_score',0):.3f}

FEATURE SIGNALS:
  Volume Z-score:         {vol_z:+.2f}σ  (normal = ±1σ, manipulation = >4σ)
  Price Z-score:          {price_z:+.2f}σ
  5-day return:           {r5*100:+.1f}%
  1-day return:           {r1*100:+.1f}%
  Price×Vol interaction:  {pv:.2f}  (key manipulation indicator)
  Amihud illiquidity:     {amihud:.2f}

CROSS-ASSET SIGNAL:
  Collaborative filter:   {cf_signal}
  Co-moving peers:        {', '.join(peers) if peers else 'none'}

Now investigate step by step using your tools. Start with news, then SEBI, then social, then pattern match.
Pass these features to historical_pattern_tool: {json.dumps({k: feats.get(k,0) for k in ['volume_zscore','returns_5d','returns_1d','price_zscore','price_vol_interaction','drawdown_from_recent_high','amihud_illiquidity']})}"""

    try:
        agent    = create_tool_calling_agent(llm, tools, prompt)
        executor = AgentExecutor(
            agent=agent, tools=tools,
            verbose=True,
            max_iterations=12,
            handle_parsing_errors=True,
            return_intermediate_steps=True,
        )

        result       = executor.invoke({"input": user_input})
        analysis_txt = result.get("output", "")
        steps        = result.get("intermediate_steps", [])
        tools_called = [step[0].tool for step in steps if hasattr(step[0], "tool")]

        parsed = _parse_structured_output(analysis_txt)
        parsed["analysis"]    = analysis_txt
        parsed["tools_called"] = tools_called
        parsed["llm_provider"] = os.getenv("LLM_PROVIDER", "groq")
        parsed["ml_context"]  = {
            "ensemble_score": score,
            "if_score":       alert_context.get("if_score", 0),
            "rf_score":       alert_context.get("rf_score", 0),
            "lstm_score":     alert_context.get("lstm_score", 0),
            "cf_signal":      cf_signal,
            "co_moving_peers": peers,
            "volume_zscore":  vol_z,
            "price_zscore":   price_z,
            "returns_5d":     r5,
            "alert_type":     atype,
        }
        return parsed

    except Exception as e:
        logger.error(f"LangChain error: {e}")
        return _fallback_analysis(alert_context, error=str(e))


def _parse_structured_output(text: str) -> dict:
    """Parse the structured output format from the LLM."""
    upper = text.upper()

    # Probability
    m = re.search(r"MANIPULATION_PROBABILITY[:\s]+(\d{1,3})", upper)
    prob = int(m.group(1)) if m else 50

    # Type
    mtype = "UNCLEAR"
    for t in ["PUMP_AND_DUMP","COORDINATED_BUY","SHORT_ATTACK",
               "WASH_TRADING","LEGITIMATE","UNCLEAR"]:
        if t in upper:
            mtype = t
            break

    # Action
    action = "MONITOR"
    for a in ["FLAG_REGULATORY","ALERT_COMPLIANCE","MONITOR","CLEAR"]:
        if a in upper:
            action = a
            break

    # Evidence bullets
    evidence = []
    for line in text.split("\n"):
        stripped = line.strip()
        if stripped.startswith("•") or stripped.startswith("-"):
            ev = stripped.lstrip("•- ").strip()
            if ev and len(ev) > 10:
                evidence.append(ev)

    # Sections
    def _extract_section(label: str) -> str:
        m = re.search(rf"{label}[:\s]+(.+?)(?:\n[A-Z_]{{4,}}:|\Z)", text,
                      re.DOTALL | re.IGNORECASE)
        return m.group(1).strip()[:300] if m else ""

    return {
        "manipulation_probability": prob,
        "manipulation_type":        mtype,
        "recommended_action":       action,
        "evidence":                 evidence[:6],
        "news_summary":             _extract_section("NEWS_SUMMARY"),
        "social_summary":           _extract_section("SOCIAL_SUMMARY"),
        "sebi_status":              _extract_section("SEBI_STATUS"),
        "pattern_match":            _extract_section("PATTERN_MATCH"),
        "reasoning":                _extract_section("REASONING"),
    }


def _fallback_analysis(ctx: dict, error: str = None) -> dict:
    score  = ctx.get("ensemble_score", 0)
    feats  = ctx.get("features", {})
    vol_z  = feats.get("volume_zscore", 0)
    r5     = feats.get("returns_5d", 0)

    if score > 0.85:   prob, action = 80, "ALERT_COMPLIANCE"
    elif score > 0.70: prob, action = 60, "MONITOR"
    else:              prob, action = 40, "MONITOR"

    evidence = []
    if abs(vol_z) > 4:
        evidence.append(f"Volume {abs(vol_z):.1f}σ above 20-period mean — abnormal")
    if abs(r5) > 0.10:
        direction = "up" if r5 > 0 else "down"
        evidence.append(f"5-day return {r5*100:+.1f}% ({direction}) — significant move")
    evidence.append(f"ML ensemble score {score:.3f} — {'above' if score>0.55 else 'below'} alert threshold")
    if error:
        evidence.append(f"LLM unavailable: {error}")

    return {
        "analysis":                 f"Rule-based fallback. Ensemble={score:.3f}",
        "manipulation_probability": prob,
        "manipulation_type":        "UNCLEAR",
        "recommended_action":       action,
        "evidence":                 evidence,
        "news_summary":             "LLM unavailable — manual news check required",
        "social_summary":           "LLM unavailable — manual social check required",
        "sebi_status":              "Not checked",
        "pattern_match":            "Not checked",
        "reasoning":                f"Rule-based: score {score:.3f}, vol_z {vol_z:.1f}σ, r5 {r5*100:.1f}%",
        "tools_called":             [],
        "llm_provider":             "fallback",
        "ml_context":               ctx,
    }
