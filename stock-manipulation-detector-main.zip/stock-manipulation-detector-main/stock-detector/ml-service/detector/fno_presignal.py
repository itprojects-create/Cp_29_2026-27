# ml-service/detector/fno_presignal.py
#
# F&O Options Pre-Signal Detector
#
# THEORETICAL BASIS (for paper Section 3.5):
# ─────────────────────────────────────────────────────────────────────
# Options markets often reveal manipulation intent BEFORE it appears
# in the equity (cash) market. Manipulators buy call options first,
# then pump the equity. The options position profits from the pump.
#
# KEY SIGNALS:
#
#   1. Unusual OI (Open Interest) build-up in OTM calls
#      Normal: OI spread across strikes
#      Manipulation: OI concentrated in specific OTM strike 2-5 days before pump
#
#   2. Put/Call Ratio (PCR) inversion
#      Normal PCR: 0.8 - 1.2
#      Pre-pump signal: PCR < 0.4 (extreme call buying)
#      Pre-dump signal: PCR > 2.5 (extreme put buying)
#
#   3. Implied Volatility (IV) spike without news
#      Options price in uncertainty. IV spike + no news = insider positioning.
#      Reference: Pan & Poteshman (2006) "The Information in Option Volume
#      for Future Stock Prices" RFS — confirms pre-manipulation OI signals.
#
#   4. Delta imbalance
#      The Jane Street India case (2019): F&O delta ratio 7.3:1 in final
#      15 minutes of trading. This was SEBI's primary detection signal.
#
# DATA SOURCE:
#   Angel One getCandleData for NFO (F&O) exchange — FREE with same API.
#   Token IDs for F&O differ from equity tokens.
#   NSE also publishes option chain as JSON (public, no auth).
#
# NSE OPTION CHAIN URL (public, no auth needed):
#   https://www.nseindia.com/api/option-chain-equities?symbol=RELIANCE
#   Returns full option chain with OI, IV, bid/ask for all strikes.
#
# ─────────────────────────────────────────────────────────────────────

import time
import requests
from loguru import logger

# NSE session headers (needed to bypass basic auth check)
NSE_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Accept": "application/json",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.nseindia.com/option-chain",
    "Connection": "keep-alive",
}

# Cache to avoid hammering NSE API
_cache: dict = {}
_CACHE_TTL   = 300   # 5 minutes


def get_option_chain(symbol: str) -> dict | None:
    """
    Fetch live option chain from NSE public API.
    No authentication needed — NSE publishes this publicly.

    Returns raw NSE option chain data or None.
    """
    cache_key = f"optchain_{symbol}_{int(time.time() // _CACHE_TTL)}"
    if cache_key in _cache:
        return _cache[cache_key]

    session = requests.Session()
    try:
        # Step 1: establish session cookie
        session.get("https://www.nseindia.com", headers=NSE_HEADERS, timeout=6)
        time.sleep(0.3)

        # Step 2: fetch option chain
        url  = f"https://www.nseindia.com/api/option-chain-equities?symbol={symbol}"
        resp = session.get(url, headers=NSE_HEADERS, timeout=10)

        if resp.status_code == 200:
            data = resp.json()
            _cache[cache_key] = data
            return data
        else:
            logger.debug(f"NSE option chain {symbol}: HTTP {resp.status_code}")
            return None

    except Exception as e:
        logger.debug(f"Option chain fetch error: {e}")
        return None


def compute_fno_signal(symbol: str) -> dict:
    """
    Compute F&O pre-signal score for a symbol.

    Returns:
        {
          "available":       bool,
          "pcr":             float,    Put/Call Ratio
          "pcr_signal":      str,      BULLISH_EXTREME / BEARISH_EXTREME / NEUTRAL
          "oi_concentration":float,    Concentration of OI in specific strike (0-1)
          "iv_spike":        bool,     IV elevated vs historical
          "atm_iv":          float,    At-the-money implied volatility
          "unusual_strikes": list,     Strikes with unusual OI build-up
          "signal_score":    float,    0-100 manipulation pre-signal score
          "interpretation":  str,
        }
    """
    data = get_option_chain(symbol)

    if data is None:
        return {
            "available":  False,
            "signal_score": 0,
            "interpretation": "NSE option chain unavailable",
        }

    try:
        records = data.get("records", {})
        oc_data = records.get("data", [])
        atm_price = records.get("underlyingValue", 0)

        if not oc_data or not atm_price:
            return {"available": False, "signal_score": 0,
                    "interpretation": "Empty option chain"}

        # ── Aggregate OI by strike ────────────────────────────────────
        total_call_oi = 0
        total_put_oi  = 0
        strike_oi     = {}

        for item in oc_data:
            strike = item.get("strikePrice", 0)
            ce     = item.get("CE", {})
            pe     = item.get("PE", {})
            c_oi   = ce.get("openInterest", 0) or 0
            p_oi   = pe.get("openInterest", 0) or 0
            total_call_oi += c_oi
            total_put_oi  += p_oi
            strike_oi[strike] = {
                "call_oi": c_oi,
                "put_oi":  p_oi,
                "call_iv": ce.get("impliedVolatility", 0) or 0,
                "put_iv":  pe.get("impliedVolatility", 0) or 0,
                "call_chng_oi": ce.get("changeinOpenInterest", 0) or 0,
                "put_chng_oi":  pe.get("changeinOpenInterest", 0) or 0,
            }

        # ── Put/Call Ratio ────────────────────────────────────────────
        pcr = total_put_oi / (total_call_oi + 1e-9)

        if   pcr < 0.4:  pcr_signal = "BULLISH_EXTREME"   # extreme call buying
        elif pcr > 2.5:  pcr_signal = "BEARISH_EXTREME"   # extreme put buying
        elif pcr < 0.7:  pcr_signal = "BULLISH"
        elif pcr > 1.5:  pcr_signal = "BEARISH"
        else:            pcr_signal = "NEUTRAL"

        # ── OI Concentration ──────────────────────────────────────────
        # Find strikes with unusual call OI build-up (change in OI > 2x avg)
        all_call_oi    = [v["call_chng_oi"] for v in strike_oi.values() if v["call_chng_oi"] > 0]
        avg_chng_oi    = sum(all_call_oi) / max(len(all_call_oi), 1)
        unusual_strikes = [
            {
                "strike":       strike,
                "call_oi":      info["call_oi"],
                "oi_change":    info["call_chng_oi"],
                "distance_pct": round((strike - atm_price) / atm_price * 100, 1),
            }
            for strike, info in strike_oi.items()
            if info["call_chng_oi"] > avg_chng_oi * 3  # 3x average = unusual
            and 0 < (strike - atm_price) / atm_price < 0.15  # OTM but not far
        ]
        unusual_strikes.sort(key=lambda x: x["oi_change"], reverse=True)

        # OI concentration score: fraction of total OI in top 3 strikes
        top3_oi     = sum(s["call_oi"] for s in unusual_strikes[:3])
        oi_conc     = top3_oi / (total_call_oi + 1e-9)

        # ── ATM Implied Volatility ────────────────────────────────────
        # Find nearest strike to ATM
        strikes_sorted = sorted(strike_oi.keys(), key=lambda s: abs(s - atm_price))
        atm_strike     = strikes_sorted[0] if strikes_sorted else 0
        atm_iv         = strike_oi.get(atm_strike, {}).get("call_iv", 0)

        # IV spike: >30% IV for large caps is unusual, >50% = very suspicious
        iv_spike = atm_iv > 35

        # ── Composite pre-signal score ────────────────────────────────
        score = 0.0
        if pcr_signal == "BULLISH_EXTREME": score += 35
        elif pcr_signal == "BULLISH":        score += 15
        if oi_conc > 0.5:                   score += 30   # very concentrated OI
        elif oi_conc > 0.3:                 score += 15
        if iv_spike:                         score += 20
        if len(unusual_strikes) > 3:         score += 15
        score = min(100, score)

        if score > 60:
            interp = (
                f"🚨 HIGH F&O PRE-SIGNAL ({score:.0f}/100). "
                f"PCR={pcr:.2f} ({pcr_signal}), "
                f"{len(unusual_strikes)} unusual OTM call strikes. "
                f"Consistent with pre-pump options positioning."
            )
        elif score > 30:
            interp = (
                f"⚠️  MODERATE F&O SIGNAL ({score:.0f}/100). "
                f"PCR={pcr:.2f}, IV={atm_iv:.1f}%. Monitor."
            )
        else:
            interp = (
                f"✅ NORMAL F&O ({score:.0f}/100). "
                f"PCR={pcr:.2f} — no unusual options positioning."
            )

        return {
            "available":          True,
            "pcr":                round(pcr, 3),
            "pcr_signal":         pcr_signal,
            "total_call_oi":      total_call_oi,
            "total_put_oi":       total_put_oi,
            "oi_concentration":   round(oi_conc, 3),
            "iv_spike":           iv_spike,
            "atm_iv":             round(atm_iv, 2),
            "atm_price":          atm_price,
            "unusual_strikes":    unusual_strikes[:5],
            "signal_score":       round(score, 1),
            "interpretation":     interp,
        }

    except Exception as e:
        logger.error(f"F&O signal computation error: {e}")
        return {"available": False, "signal_score": 0,
                "interpretation": f"Computation error: {e}"}


# Singleton accessor
def get_fno_signal(symbol: str) -> dict:
    return compute_fno_signal(symbol)
