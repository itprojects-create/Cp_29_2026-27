# ml-service/detector/zscore_rules.py
# Rule-based detection layer — runs on every tick before Isolation Forest.
# Fast, interpretable, catches obvious patterns.
# Returns None if nothing suspicious, or a dict with alert info.

from typing import Optional
import numpy as np


def detect_zscore(
    features: dict,  # Named dict from features_to_dict()
    symbol: str,
) -> Optional[dict]:
    """
    Rule-based detection using Z-score thresholds.
    These are the "obvious" manipulation patterns:
    - Pump & Dump: price up then down fast with huge volume
    - Coordinated Buy: volume spike + price surge together
    - Volume Spike: volume alone extremely high
    - Price Anomaly: price move with no volume explanation

    Returns None if nothing suspicious, otherwise returns alert dict.
    """

    vol_z = features.get("volume_zscore", 0)
    price_z = features.get("price_zscore", 0)
    pv_interact = features.get("price_vol_interaction", 0)
    r5 = features.get("returns_5d", 0)
    r1 = features.get("returns_1d", 0)
    drawdown = features.get("drawdown_from_recent_high", 0)
    vol_ratio = features.get("volume_ratio", 1)
    r_consistency = features.get("return_consistency", 0)

    # ── Rule 1: Pump and Dump ─────────────────────────────────────────────
    # Pattern: big upward move in last 5 days + sudden crash today
    # Threshold: 5-day return > 15%, 1-day return < -8%, vol spike
    if r5 > 0.15 and r1 < -0.08 and vol_z > 3:
        return {
            "alert_type": "PUMP_AND_DUMP",
            "level": "CRITICAL",
            "rule_score": 0.95,
            "detail": (
                f"5-day gain {r5*100:.1f}% followed by {r1*100:.1f}% crash today. "
                f"Volume {vol_z:.1f}σ above normal. Classic dump phase."
            ),
        }

    # ── Rule 2: Coordinated Buy ───────────────────────────────────────────
    # Pattern: massive volume + sustained price rise + consistent direction
    # All three must align — eliminates accidental false positives
    if vol_z > 4 and r5 > 0.05 and r_consistency > 0.8 and vol_ratio > 3:
        return {
            "alert_type": "COORDINATED_BUY",
            "level": "HIGH",
            "rule_score": 0.82,
            "detail": (
                f"Volume {vol_z:.1f}σ above normal ({vol_ratio:.1f}x average). "
                f"Price up {r5*100:.1f}% over 5 days with {r_consistency*100:.0f}% "
                f"directional consistency. Coordinated buying signal."
            ),
        }

    # ── Rule 3: Intraday Pump ─────────────────────────────────────────────
    # Pattern: volume spike + single-day price spike together
    if pv_interact > 8 and vol_z > 3.5:
        return {
            "alert_type": "INTRADAY_PUMP",
            "level": "HIGH",
            "rule_score": 0.75,
            "detail": (
                f"Price×Volume interaction score {pv_interact:.1f} — "
                f"price Z-score {price_z:.1f}σ + volume Z-score {vol_z:.1f}σ "
                f"spiking simultaneously. Intraday pump signature."
            ),
        }

    # ── Rule 4: Volume Spike ──────────────────────────────────────────────
    # Pure volume anomaly — could be institutional but worth flagging
    if vol_z > 4.5:
        return {
            "alert_type": "VOLUME_SPIKE",
            "level": "MEDIUM",
            "rule_score": 0.60,
            "detail": (
                f"Volume {vol_z:.1f}σ above 20-period mean ({vol_ratio:.1f}x average). "
                f"No matching price move — could be institutional block."
            ),
        }

    # ── Rule 5: Unusual Price Move (no volume confirmation) ───────────────
    if abs(price_z) > 4 and vol_z < 1.5:
        direction = "surge" if price_z > 0 else "crash"
        return {
            "alert_type": "PRICE_ANOMALY",
            "level": "LOW",
            "rule_score": 0.40,
            "detail": (
                f"Price {direction}: {price_z:.1f}σ from mean with "
                f"below-normal volume. Possible thin market manipulation."
            ),
        }

    return None  # Nothing suspicious
