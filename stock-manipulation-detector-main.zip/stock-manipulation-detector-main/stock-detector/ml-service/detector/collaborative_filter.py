# ml-service/detector/collaborative_filter.py
#
# Cross-Asset Collaborative Filtering for Manipulation Detection.
# Addresses mentor recommendation: "Try to do over collaborative filtering"
#
# THEORETICAL BASIS:
# ─────────────────────────────────────────────────────────────────────
# Traditional anomaly detection looks at ONE stock in isolation.
# Collaborative filtering asks: "Does this stock's anomaly co-occur
# with anomalies in correlated stocks?"
#
# If RELIANCE spikes and nothing else does → might be legitimate news.
# If RELIANCE + ADANIENT + ADANIPORTS all spike simultaneously with
# coordinated volume → coordinated manipulation signal.
#
# Implementation:
#   1. Pre-compute historical correlation matrix C[i,j] between stocks
#   2. For each alert, find the stock's top-k correlated peers
#   3. Check if peers are ALSO anomalous right now
#   4. If yes: amplify the ensemble score (co-movement = stronger signal)
#   5. If no: slight reduction (uncorroborated anomaly = might be noise)
#
# WHY THIS IS NOVEL FOR NSE:
#   NSE stocks in the same sector/group move together normally.
#   During manipulation, the pattern BREAKS — one stock moves abnormally
#   relative to its correlated peers (pump of one stock), OR multiple
#   stocks move together abnormally (coordinated group manipulation).
#   Both patterns are captured here.
#
# PAPER REFERENCE:
#   Cao et al. "Detecting Wash Trade in Financial Market using
#   Digraph-based Models" (IEEE 2019) — graph-based cross-asset analysis.
# ─────────────────────────────────────────────────────────────────────

import numpy as np
from collections import defaultdict, deque
from loguru import logger

# NSE sector groupings — stocks in same sector are naturally correlated
SECTOR_GROUPS = {
    "banking":    ["HDFCBANK", "ICICIBANK", "KOTAKBANK", "SBIN", "AXISBANK", "YESBANK"],
    "it":         ["INFY", "TCS", "WIPRO"],
    "conglomerate": ["RELIANCE", "ADANIENT", "ADANIPORTS"],
    "fintech_ipo":  ["ZOMATO", "NYKAA", "PAYTM"],
    "finance":    ["BAJFINANCE"],
}

# Reverse lookup: symbol → sector
SYMBOL_SECTOR = {}
for sector, symbols in SECTOR_GROUPS.items():
    for sym in symbols:
        SYMBOL_SECTOR[sym] = sector


class CollaborativeFilter:
    """
    Tracks anomaly scores across all symbols and computes
    cross-asset correlation signals.
    """

    def __init__(self, window: int = 30, top_k: int = 3):
        """
        Args:
            window: Number of recent scores to keep per symbol
            top_k:  Number of correlated peers to check
        """
        self.window  = window
        self.top_k   = top_k

        # Rolling anomaly score history: {symbol: deque([score, ...])}
        self._history: dict[str, deque] = defaultdict(lambda: deque(maxlen=window))

        # Learned correlation matrix (populated by update_correlation)
        # _corr[sym_a][sym_b] = pearson correlation coefficient
        self._corr: dict[str, dict[str, float]] = {}

        # Pre-populate with known sector correlations as prior
        self._init_sector_priors()

    def _init_sector_priors(self):
        """
        Initialise correlation matrix with sector-based priors.
        Stocks in the same sector start with high correlation (0.7).
        Cross-sector starts at 0.1.
        Updated dynamically as real scores come in.
        """
        all_syms = list(SYMBOL_SECTOR.keys())
        for s1 in all_syms:
            self._corr[s1] = {}
            for s2 in all_syms:
                if s1 == s2:
                    self._corr[s1][s2] = 1.0
                elif SYMBOL_SECTOR.get(s1) == SYMBOL_SECTOR.get(s2):
                    self._corr[s1][s2] = 0.70   # Same sector prior
                else:
                    self._corr[s1][s2] = 0.10   # Cross-sector prior

    def record_score(self, symbol: str, anomaly_score: float):
        """Record a new anomaly score for a symbol (called every tick)."""
        self._history[symbol].append(float(anomaly_score))

        # Update correlations every 50 records
        total = sum(len(h) for h in self._history.values())
        if total % 50 == 0 and len(self._history) > 1:
            self._update_correlations()

    def _update_correlations(self):
        """
        Recompute Pearson correlation matrix from recent score history.
        Only update pairs where both have enough history.
        """
        symbols = [s for s, h in self._history.items() if len(h) >= 10]
        for i, s1 in enumerate(symbols):
            for s2 in symbols[i+1:]:
                h1 = list(self._history[s1])
                h2 = list(self._history[s2])
                min_len = min(len(h1), len(h2))
                if min_len < 10:
                    continue
                a1 = np.array(h1[-min_len:])
                a2 = np.array(h2[-min_len:])
                if np.std(a1) < 1e-6 or np.std(a2) < 1e-6:
                    continue
                corr = float(np.corrcoef(a1, a2)[0, 1])
                if np.isnan(corr):
                    continue
                # Exponential moving average update (don't overwrite prior completely)
                old = self._corr.get(s1, {}).get(s2, 0.1)
                new_corr = 0.8 * old + 0.2 * corr
                if s1 not in self._corr:
                    self._corr[s1] = {}
                if s2 not in self._corr:
                    self._corr[s2] = {}
                self._corr[s1][s2] = new_corr
                self._corr[s2][s1] = new_corr

    def get_correlated_peers(self, symbol: str) -> list[tuple[str, float]]:
        """
        Get top-k correlated peers for a symbol, sorted by correlation.
        Returns [(peer_symbol, correlation), ...]
        """
        if symbol not in self._corr:
            return []
        peers = [
            (s, c) for s, c in self._corr[symbol].items()
            if s != symbol and c > 0.3
        ]
        return sorted(peers, key=lambda x: x[1], reverse=True)[:self.top_k]

    def compute_cf_score(self, symbol: str, current_score: float) -> dict:
        """
        Compute collaborative filtering amplification for a symbol's anomaly score.

        Logic:
          - Get top-k correlated peers
          - Get their recent average anomaly scores
          - If peers are ALSO anomalous: amplify (coordinated signal)
          - If peers are quiet: slight reduction (uncorroborated)
          - If no correlation data yet: neutral (amplifier = 1.0)

        Returns:
            {
              "cf_score": float,          — amplified final score
              "amplifier": float,         — multiplier applied (0.7 to 1.5)
              "co_moving_peers": list,    — peers that are also anomalous
              "cf_signal": str,           — COORDINATED / ISOLATED / NEUTRAL
              "peer_scores": dict,        — {peer: avg_score}
            }
        """
        self.record_score(symbol, current_score)

        peers = self.get_correlated_peers(symbol)
        if not peers:
            return {
                "cf_score":         current_score,
                "amplifier":        1.0,
                "co_moving_peers":  [],
                "cf_signal":        "NEUTRAL",
                "peer_scores":      {},
            }

        # Get recent average score for each peer
        peer_scores = {}
        for peer_sym, correlation in peers:
            hist = list(self._history.get(peer_sym, []))
            if hist:
                # Use last 5 scores as recent context
                peer_scores[peer_sym] = float(np.mean(hist[-5:]))

        if not peer_scores:
            return {
                "cf_score":         current_score,
                "amplifier":        1.0,
                "co_moving_peers":  [],
                "cf_signal":        "NEUTRAL",
                "peer_scores":      {},
            }

        # Identify co-moving peers (also anomalous at > MEDIUM threshold)
        PEER_THRESHOLD = 0.45
        co_moving = [
            p for p, s in peer_scores.items()
            if s > PEER_THRESHOLD
        ]

        # Compute weighted co-movement score
        if co_moving:
            # Peers are anomalous too — coordinated signal
            # Amplifier proportional to: how many peers, how correlated
            peer_corrs = {p: self._corr.get(symbol, {}).get(p, 0.3) for p in co_moving}
            avg_corr   = np.mean(list(peer_corrs.values()))
            avg_peer_score = np.mean([peer_scores[p] for p in co_moving])

            # Amplifier: 1.0 base + up to 0.5 bonus
            # Formula: 1 + (num_co_moving / top_k) * 0.3 + avg_corr * 0.2
            amplifier = min(1.5,
                1.0
                + (len(co_moving) / max(len(peers), 1)) * 0.30
                + avg_corr * 0.20
            )
            cf_signal = "COORDINATED"
        else:
            # No peers anomalous — might be isolated/legitimate
            amplifier = 0.85   # Slight reduction
            cf_signal = "ISOLATED"

        cf_score = float(np.clip(current_score * amplifier, 0, 1))

        return {
            "cf_score":        round(cf_score, 4),
            "amplifier":       round(amplifier, 3),
            "co_moving_peers": co_moving,
            "cf_signal":       cf_signal,
            "peer_scores":     {k: round(v, 3) for k, v in peer_scores.items()},
        }

    @property
    def correlation_matrix(self) -> dict:
        """Return current learned correlation matrix (for inspection)."""
        return self._corr

    def summary(self) -> dict:
        """Return a summary of current state for health endpoint."""
        return {
            "symbols_tracked": list(self._history.keys()),
            "correlations_computed": sum(
                1 for s1 in self._corr for s2 in self._corr[s1] if s1 < s2
            ),
        }


# Singleton — shared across all requests in FastAPI
cf_filter = CollaborativeFilter(window=30, top_k=3)
