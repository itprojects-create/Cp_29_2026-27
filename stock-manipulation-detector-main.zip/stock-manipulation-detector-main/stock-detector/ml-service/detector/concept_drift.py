# ml-service/detector/concept_drift.py
#
# Concept drift detection using ADWIN (ADaptive WINdowing algorithm).
#
# PROBLEM THIS SOLVES:
# ─────────────────────────────────────────────────────────────────────
# Financial markets are non-stationary. A model trained on 2019-2023 data
# learns what "normal" looks like in that period. After a major structural
# change (COVID crash, interest rate cycle shift, new SEBI regulations),
# "normal" looks different and the model produces too many false positives
# or misses new manipulation patterns.
#
# This is called concept drift: the underlying distribution P(X,Y) changes.
#
# ADWIN ALGORITHM:
# ─────────────────────────────────────────────────────────────────────
# ADWIN maintains a sliding window of recent anomaly scores.
# It continuously tests whether the mean of the first half of the window
# differs significantly from the mean of the second half.
#
# If |μ₁ - μ₂| > ε → DRIFT DETECTED → trigger retraining
#
# δ = confidence parameter (default 0.002 = very sensitive)
# This is a proven algorithm: Bifet & Gavaldà (2007) SIAM SDM.
#
# WHAT THIS GIVES THE PAPER (Section 5 — Limitations and Future Work):
#   "The system includes an ADWIN-based concept drift detector that
#    monitors the distribution of anomaly scores. When drift is detected,
#    the Isolation Forest is automatically retrained on accumulated
#    recent data, maintaining detection performance across market regimes."
# ─────────────────────────────────────────────────────────────────────

import numpy as np
from collections import deque
from loguru import logger


class ADWIN:
    """
    Adaptive Windowing (ADWIN) concept drift detector.
    Bifet & Gavaldà (2007), SIAM International Conference on Data Mining.

    Monitors a stream of values (anomaly scores per symbol) and detects
    when the distribution has significantly shifted.
    """

    def __init__(self, delta: float = 0.002):
        """
        Args:
            delta: Confidence parameter (0.002 = 99.8% confidence for drift signal)
                   Smaller = more sensitive, more drift alerts
                   Larger  = less sensitive, fewer false drift alarms
        """
        self.delta   = delta
        self.window  = deque()
        self.total   = 0.0
        self.n       = 0
        self.drift_detected  = False
        self.drift_count     = 0
        self.last_drift_at   = None

    def update(self, value: float) -> bool:
        """
        Add a new observation to the window.

        Returns True if DRIFT is detected, False otherwise.
        """
        self.window.append(value)
        self.total += value
        self.n     += 1
        self.drift_detected = False

        # Minimum window before testing
        if self.n < 30:
            return False

        # Test all possible split points
        n_total  = len(self.window)
        values   = list(self.window)
        cum_sum  = np.cumsum(values)

        best_eps = 0.0
        best_idx = -1

        for i in range(10, n_total - 10):
            n0   = i
            n1   = n_total - i
            mu0  = cum_sum[i-1] / n0
            mu1  = (cum_sum[-1] - cum_sum[i-1]) / n1

            # ADWIN threshold (Hoeffding bound variant)
            m    = 1 / (1/n0 + 1/n1)
            eps  = np.sqrt((1 / (2 * m)) * np.log(4 * n_total / self.delta))

            if abs(mu0 - mu1) > eps:
                if abs(mu0 - mu1) > best_eps:
                    best_eps = abs(mu0 - mu1)
                    best_idx = i

        if best_idx > 0:
            # Drift detected — shrink window to the point of change
            for _ in range(best_idx):
                old = self.window.popleft()
                self.total -= old
                self.n     -= 1

            self.drift_detected = True
            self.drift_count   += 1
            self.last_drift_at  = self.n
            logger.warning(
                f"ADWIN drift detected! "
                f"Window reduced from {n_total} to {len(self.window)} samples. "
                f"|Δμ|={best_eps:.4f}"
            )
            return True

        return False

    @property
    def mean(self) -> float:
        """Current window mean."""
        return self.total / max(self.n, 1)

    @property
    def std(self) -> float:
        """Current window std."""
        if len(self.window) < 2:
            return 0.0
        return float(np.std(list(self.window)))

    def reset(self):
        self.window.clear()
        self.total = 0.0
        self.n     = 0

    def summary(self) -> dict:
        return {
            "window_size":    len(self.window),
            "mean":           round(self.mean, 4),
            "std":            round(self.std, 4),
            "drift_count":    self.drift_count,
            "last_drift_at":  self.last_drift_at,
        }


class DriftMonitor:
    """
    Manages ADWIN detectors per symbol and triggers retraining.
    One ADWIN instance per NSE symbol, monitoring its anomaly score stream.
    """

    def __init__(self, delta: float = 0.002, retrain_cooldown: int = 500):
        """
        Args:
            delta:            ADWIN confidence (0.002 = standard)
            retrain_cooldown: Min ticks between retraining triggers
        """
        self.delta            = delta
        self.retrain_cooldown = retrain_cooldown
        self._detectors: dict[str, ADWIN] = {}
        self._ticks_since_retrain: dict[str, int] = {}

    def _get_detector(self, symbol: str) -> ADWIN:
        if symbol not in self._detectors:
            self._detectors[symbol] = ADWIN(self.delta)
        return self._detectors[symbol]

    def update(self, symbol: str, anomaly_score: float) -> dict:
        """
        Feed a new anomaly score to the drift detector for this symbol.

        Returns:
            {
              "drift_detected": bool,
              "should_retrain": bool,
              "window_mean": float,
              "drift_count": int,
            }
        """
        detector = self._get_detector(symbol)
        self._ticks_since_retrain[symbol] = \
            self._ticks_since_retrain.get(symbol, 0) + 1

        drift = detector.update(anomaly_score)

        should_retrain = (
            drift and
            self._ticks_since_retrain.get(symbol, 0) >= self.retrain_cooldown
        )

        if should_retrain:
            self._ticks_since_retrain[symbol] = 0
            logger.info(
                f"Drift triggered retraining for {symbol}. "
                f"Score mean shifted to {detector.mean:.4f}"
            )

        return {
            "drift_detected": drift,
            "should_retrain": should_retrain,
            "window_mean":    round(detector.mean, 4),
            "window_std":     round(detector.std, 4),
            "drift_count":    detector.drift_count,
        }

    def summary(self) -> dict:
        """Return drift status across all tracked symbols."""
        return {
            sym: det.summary()
            for sym, det in self._detectors.items()
        }

    def global_drift_summary(self) -> dict:
        """
        Detect if the entire market is drifting (regime change).
        If >50% of symbols show drift simultaneously → systemic event.
        """
        if not self._detectors:
            return {"systemic_drift": False, "n_symbols": 0}

        drift_counts = [d.drift_count for d in self._detectors.values()]
        recent_drifts = sum(1 for d in self._detectors.values()
                            if d.drift_count > 0 and
                            d.last_drift_at is not None and
                            (d.n - d.last_drift_at) < 100)

        systemic = recent_drifts > len(self._detectors) * 0.5

        if systemic:
            logger.warning(
                f"SYSTEMIC DRIFT DETECTED: {recent_drifts}/{len(self._detectors)} "
                "symbols drifting simultaneously. Possible market regime change. "
                "Consider full model retraining."
            )

        return {
            "systemic_drift":  systemic,
            "n_symbols":       len(self._detectors),
            "drifting_symbols": recent_drifts,
            "pct_drifting":    round(recent_drifts / max(len(self._detectors), 1) * 100, 1),
        }


# Singleton
drift_monitor = DriftMonitor(delta=0.002, retrain_cooldown=500)
