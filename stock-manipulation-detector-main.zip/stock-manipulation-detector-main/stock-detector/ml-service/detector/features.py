# ml-service/detector/features.py
# 20 features (extended from 14) for paper-grade detection.
# 6 new features address mentor recommendation for more technical depth.
#
# FEATURE TAXONOMY (for paper Section 3.2):
# ─────────────────────────────────────────────────────────────────────
# Group A — Price momentum features (returns_1d … price_acceleration)
#   Capture: directional manipulation, sustained pumping
#
# Group B — Volume features (volume_zscore … volume_acceleration)
#   Capture: abnormal activity, coordinated buying volume
#
# Group C — Cross features (price_vol_interaction … return_consistency)
#   Capture: simultaneous price+volume anomaly (core pump signal)
#
# Group D — Microstructure features [NEW] (bid_ask_proxy … amihud_illiquidity)
#   Capture: market microstructure signatures of manipulation
#   Based on: Amihud (2002), Kyle (1985) lambda, Roll (1984) spread
#
# ─────────────────────────────────────────────────────────────────────

import numpy as np
from typing import Optional

FEATURE_NAMES = [
    # Group A — Price momentum
    "returns_1d",
    "returns_3d",
    "returns_5d",
    "returns_10d",
    "price_zscore",
    "price_acceleration",
    "intraday_range_pct",

    # Group B — Volume
    "volume_zscore",
    "volume_ratio",
    "volume_acceleration",

    # Group C — Cross features
    "price_vol_interaction",
    "vol_confirmed_momentum",
    "drawdown_from_recent_high",
    "return_consistency",

    # Group D — Microstructure [NEW]
    "amihud_illiquidity",     # |return| / volume → high during manipulation (Amihud 2002)
    "price_efficiency_ratio", # abs(net_change) / sum(abs(changes)) → trend strength
    "vol_concentration",      # Is volume concentrated in a few ticks or spread?
    "high_low_ratio",         # (high-low)/close rolling zscore → abnormal range
    "close_to_high_ratio",    # close/high — near high = buying pressure
    "momentum_reversal",      # Short-term momentum × sign reversal signal
]

FEAT_DIM = len(FEATURE_NAMES)   # 20
WINDOW   = 20


def safe_pct(a: float, b: float) -> float:
    return (a - b) / b if b != 0 else 0.0


def extract_features(
    current_price:  float,
    current_volume: int,
    current_high:   float,
    current_low:    float,
    history:        list[dict],
) -> Optional[np.ndarray]:
    """
    Compute all 20 features for a single tick.

    Args:
        current_price:  Latest trade price
        current_volume: Latest volume
        current_high:   Intraday high
        current_low:    Intraday low
        history:        List of {'price', 'volume', 'high'?, 'low'?} dicts

    Returns:
        np.ndarray shape (1, 20) or None if insufficient history
    """
    if len(history) < 20:   # sturdier — matches your WINDOW constant
        return None

    prices  = np.array([h["price"]  for h in history] + [current_price],  dtype=np.float64)
    volumes = np.array([h["volume"] for h in history] + [current_volume], dtype=np.float64)
    highs   = np.array([h.get("high", h["price"]) for h in history] + [current_high or current_price])
    lows    = np.array([h.get("low",  h["price"]) for h in history] + [current_low  or current_price])

    # ── Group A: Price momentum ───────────────────────────────────────
    r1  = safe_pct(prices[-1], prices[-2])  if len(prices) >= 2  else 0.0
    r3  = safe_pct(prices[-1], prices[-4])  if len(prices) >= 4  else 0.0
    r5  = safe_pct(prices[-1], prices[-6])  if len(prices) >= 6  else 0.0
    r10 = safe_pct(prices[-1], prices[-11]) if len(prices) >= 11 else 0.0

    window_prices = prices[-WINDOW-1:-1]
    if len(window_prices) >= 5:
        rets_w  = np.diff(window_prices) / (window_prices[:-1] + 1e-9)
        price_zscore = (r1 - np.mean(rets_w)) / (np.std(rets_w) + 1e-9)
    else:
        price_zscore = 0.0

    r1_prev          = safe_pct(prices[-2], prices[-3]) if len(prices) >= 3 else 0.0
    price_accel      = r1 - r1_prev
    h, l             = current_high or current_price, current_low or current_price
    intraday_range   = (h - l) / (current_price + 1e-9)

    # ── Group B: Volume ───────────────────────────────────────────────
    win_vols   = volumes[-WINDOW-1:-1]
    mean_vol   = np.mean(win_vols) + 1e-9
    std_vol    = np.std(win_vols)  + 1e-9
    vol_zscore = (current_volume - mean_vol) / std_vol
    vol_ratio  = current_volume / mean_vol

    prev_ratio     = volumes[-2] / (np.mean(volumes[-WINDOW-2:-2]) + 1e-9) if len(volumes) >= 3 else 1.0
    vol_accel      = vol_ratio - prev_ratio

    # ── Group C: Cross features ───────────────────────────────────────
    pv_interact   = price_zscore * vol_zscore   # KEY: simultaneous spike
    vol_momentum  = r5 * vol_ratio
    roll_max      = np.max(prices[-10:]) if len(prices) >= 10 else current_price
    drawdown      = (current_price - roll_max) / (roll_max + 1e-9)

    if len(prices) >= 6:
        recent_rets = np.diff(prices[-6:])
        signs       = np.sign(recent_rets)
        nz          = signs[signs != 0]
        ret_consist = abs(np.sum(nz)) / len(nz) if len(nz) > 0 else 0.0
    else:
        ret_consist = 0.0

    # ── Group D: Microstructure features [NEW] ────────────────────────

    # 1. Amihud (2002) illiquidity ratio: |r| / volume
    #    High during manipulation (large price move per unit of volume)
    amihud = abs(r1) / (current_volume / 1e6 + 1e-9)
    amihud_z = 0.0
    if len(volumes) >= 5:
        past_amihuds = [
            abs(safe_pct(prices[i], prices[i-1])) / (volumes[i] / 1e6 + 1e-9)
            for i in range(max(1, len(prices)-WINDOW), len(prices)-1)
        ]
        if len(past_amihuds) > 2:
            amihud_z = (amihud - np.mean(past_amihuds)) / (np.std(past_amihuds) + 1e-9)

    # 2. Price efficiency ratio (Kaufman 1995):
    #    |net_directional_change| / sum_of_all_moves
    #    1.0 = perfectly trending (momentum); 0 = noisy/choppy
    if len(prices) >= 5:
        net_change   = abs(prices[-1] - prices[-5])
        total_change = np.sum(np.abs(np.diff(prices[-5:]))) + 1e-9
        efficiency   = net_change / total_change
    else:
        efficiency = 0.5

    # 3. Volume concentration:
    #    If one tick has very high volume vs average → concentrated = suspicious
    if len(volumes) >= 5:
        vol_cv = np.std(volumes[-5:]) / (np.mean(volumes[-5:]) + 1e-9)
    else:
        vol_cv = 0.0

    # 4. High-Low range zscore (abnormal intraday range signals manipulation)
    hl_ratios = (highs - lows) / (prices + 1e-9)
    if len(hl_ratios) >= 5:
        hl_mean = np.mean(hl_ratios[:-1])
        hl_std  = np.std(hl_ratios[:-1]) + 1e-9
        hl_z    = (hl_ratios[-1] - hl_mean) / hl_std
    else:
        hl_z = 0.0

    # 5. Close-to-high ratio: close/high
    #    Near 1.0 = closing near the high = sustained buying pressure
    ctl = current_price / (current_high + 1e-9) if current_high else 1.0

    # 6. Momentum-reversal signal:
    #    High short-term momentum followed by reversal = dump phase
    if len(prices) >= 4:
        mom_3  = safe_pct(prices[-1], prices[-4])
        mom_1  = safe_pct(prices[-1], prices[-2])
        # Positive 3-day momentum + negative 1-day = reversal
        reversal = mom_3 * -np.sign(mom_1) if mom_1 != 0 else 0.0
    else:
        reversal = 0.0

    # ── Assemble ──────────────────────────────────────────────────────
    features = np.array([
        r1, r3, r5, r10,
        price_zscore, price_accel, intraday_range,
        vol_zscore, vol_ratio, vol_accel,
        pv_interact, vol_momentum, drawdown, ret_consist,
        # New microstructure
        float(np.clip(amihud_z, -5, 5)),
        float(np.clip(efficiency, 0, 1)),
        float(np.clip(vol_cv, 0, 5)),
        float(np.clip(hl_z, -5, 5)),
        float(np.clip(ctl, 0, 1)),
        float(np.clip(reversal, -1, 1)),
    ], dtype=np.float32)

    return np.nan_to_num(features, nan=0.0, posinf=0.0, neginf=0.0).reshape(1, -1)


def features_to_dict(features_array: np.ndarray) -> dict:
    flat = features_array.flatten()
    return {name: float(flat[i]) for i, name in enumerate(FEATURE_NAMES)}
