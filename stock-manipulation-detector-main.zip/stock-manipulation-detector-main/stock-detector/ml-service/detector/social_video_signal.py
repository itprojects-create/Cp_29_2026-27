# ml-service/detector/social_video_signal.py
#
# YouTube + Google Trends signal detector.
# Specifically designed to catch Sadhna Broadcast / Arshad Warsi type cases:
# coordinated YouTube promotions that precede stock price manipulation.
#
# THE SADHNA BROADCAST CASE (SEBI Order 2023-24):
# ─────────────────────────────────────────────────────────────────────
# • Promoters paid ₹5.8cr for Google Ads to boost YouTube videos
# • Videos falsely claimed Adani group takeover + ₹1,100cr deal
# • Videos got 90 lakh+ views within days
# • While retail bought, promoters sold at inflated prices
# • SEBI barred 59 entities, penalty ₹21.45 crore
# • Key signal: YouTube spike PRECEDES stock spike by 2-5 days
#
# DETECTION LOGIC:
# ─────────────────────────────────────────────────────────────────────
# 1. Search YouTube Data API for recent videos mentioning the stock
# 2. Flag: sudden view count spike in last 24-72 hours
# 3. Flag: videos with misleading titles (takeover, multibagger, etc.)
# 4. Cross-check: Google Trends spike (free, no key) in the same window
# 5. If YouTube spike + Trends spike + no corporate announcement = SIGNAL
#
# YouTube Data API v3: FREE, 10,000 units/day (each search = 100 units)
# Google Trends: free via pytrends library (unofficial API wrapper)
# ─────────────────────────────────────────────────────────────────────

import os, time, requests
from datetime import datetime, timedelta
from loguru import logger

# Keywords that appear in manipulative promotional videos
MANIPULATION_TITLE_KW = [
    "multibagger", "multi bagger", "next adani", "next tata",
    "1000%", "10x", "takeover", "acquisition deal", "₹1000 crore",
    "hidden gem", "sureshot", "sure shot", "guaranteed return",
    "promoter buying", "operator stock", "jackpot", "must buy",
    "buy now", "breakout", "upper circuit", "अगला adani",   # Hindi terms
    "करोड़पति", "मल्टीबैगर",
]


class SocialVideoSignal:
    """
    Detects YouTube-driven manipulation campaigns for NSE stocks.
    """

    def __init__(self):
        self.yt_api_key = os.getenv("YOUTUBE_API_KEY", "")
        # Cache to avoid hitting API too often
        self._cache: dict = {}
        self._cache_ttl = 3600  # 1 hour

    def scan(self, symbol: str, company_name: str = "") -> dict:
        """
        Scan YouTube + Google Trends for manipulation signals.

        Args:
            symbol:       NSE symbol (e.g., "SADHNABROADCAST")
            company_name: Full company name for better search

        Returns:
            {
              "video_signal_score": float 0-100,
              "trends_signal_score": float 0-100,
              "composite_score": float 0-100,
              "suspicious_videos": list,
              "trends_spike": bool,
              "summary": str,
            }
        """
        cache_key = f"{symbol}_{datetime.now().strftime('%Y%m%d%H')}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        yt_result     = self._scan_youtube(symbol, company_name)
        trends_result = self._scan_trends(symbol, company_name)

        # Composite score: weighted combination
        composite = (
            yt_result["score"]     * 0.65 +
            trends_result["score"] * 0.35
        )

        # Build summary
        if composite > 60:
            summary = (
                f"🚨 HIGH VIDEO SIGNAL ({composite:.0f}/100): "
                f"{yt_result.get('suspicious_count',0)} suspicious YouTube videos, "
                f"trends spike={trends_result.get('spike',False)}. "
                f"Matches Sadhna Broadcast manipulation pattern."
            )
        elif composite > 30:
            summary = (
                f"⚠️  MODERATE VIDEO SIGNAL ({composite:.0f}/100): "
                f"Some promotional content detected. Monitor."
            )
        else:
            summary = f"✅ LOW VIDEO SIGNAL ({composite:.0f}/100): No unusual promotional activity."

        result = {
            "video_signal_score":  round(yt_result["score"], 1),
            "trends_signal_score": round(trends_result["score"], 1),
            "composite_score":     round(composite, 1),
            "suspicious_videos":   yt_result.get("suspicious_videos", []),
            "trends_spike":        trends_result.get("spike", False),
            "trends_data":         trends_result.get("data", []),
            "summary":             summary,
            "available":           yt_result["available"] or trends_result["available"],
        }

        self._cache[cache_key] = result
        return result

    def _scan_youtube(self, symbol: str, company_name: str) -> dict:
        """
        Search YouTube for recent videos about this stock.
        Uses YouTube Data API v3 (free, 10,000 units/day).
        Falls back to web scraping if no key.
        """
        if not self.yt_api_key:
            return {
                "score": 0, "available": False,
                "note": "Set YOUTUBE_API_KEY in .env for YouTube scanning. "
                        "Free at console.cloud.google.com → YouTube Data API v3."
            }

        query     = f"{symbol} stock {company_name} NSE share"
        published = (datetime.utcnow() - timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%SZ")

        try:
            r = requests.get(
                "https://www.googleapis.com/youtube/v3/search",
                params={
                    "key":            self.yt_api_key,
                    "q":              query,
                    "part":           "snippet",
                    "type":           "video",
                    "publishedAfter": published,
                    "maxResults":     25,
                    "order":          "relevance",
                    "relevanceLanguage": "hi,en",
                },
                timeout=10,
            )
            if r.status_code != 200:
                return {"score": 0, "available": False,
                        "error": f"YouTube API: {r.status_code}"}

            items = r.json().get("items", [])
            if not items:
                return {"score": 0, "available": True,
                        "suspicious_videos": [], "suspicious_count": 0}

            # Get video IDs to fetch statistics
            video_ids = [it["id"]["videoId"] for it in items if "videoId" in it.get("id", {})]

            # Fetch view counts
            stats_r = requests.get(
                "https://www.googleapis.com/youtube/v3/videos",
                params={
                    "key":  self.yt_api_key,
                    "id":   ",".join(video_ids),
                    "part": "statistics,snippet",
                },
                timeout=10,
            )
            stats = {}
            if stats_r.status_code == 200:
                for v in stats_r.json().get("items", []):
                    stats[v["id"]] = {
                        "views":    int(v["statistics"].get("viewCount", 0)),
                        "likes":    int(v["statistics"].get("likeCount", 0)),
                        "title":    v["snippet"].get("title", ""),
                        "channel":  v["snippet"].get("channelTitle", ""),
                        "published":v["snippet"].get("publishedAt", ""),
                    }

            # Score each video
            suspicious = []
            total_score = 0

            for vid_id, info in stats.items():
                title_lower = info["title"].lower()
                views       = info["views"]

                # Check for manipulation keywords in title
                kw_hits = [kw for kw in MANIPULATION_TITLE_KW if kw in title_lower]

                # High views in short time = viral spread signal
                # Calculate age in days
                try:
                    pub_date = datetime.fromisoformat(info["published"].replace("Z",""))
                    age_days = max(0.1, (datetime.utcnow() - pub_date).total_seconds() / 86400)
                    daily_views = views / age_days
                except Exception:
                    daily_views = 0

                # Anomalous if: views > 50k in 3 days OR manipulation keywords
                is_suspicious = (
                    (daily_views > 15000 and len(kw_hits) > 0) or
                    len(kw_hits) >= 2 or
                    (views > 200000 and len(kw_hits) > 0)
                )

                if is_suspicious:
                    vid_score = min(100,
                        len(kw_hits) * 20 +
                        min(40, daily_views / 1000) +
                        (20 if views > 500000 else 0)
                    )
                    total_score += vid_score
                    suspicious.append({
                        "title":       info["title"][:80],
                        "channel":     info["channel"],
                        "views":       views,
                        "daily_views": round(daily_views),
                        "keywords":    kw_hits,
                        "score":       round(vid_score),
                        "url":         f"https://youtube.com/watch?v={vid_id}",
                    })

            # Normalise to 0-100
            score = min(100, total_score)

            return {
                "score":            score,
                "available":        True,
                "total_videos":     len(items),
                "suspicious_videos": sorted(suspicious, key=lambda x: x["score"], reverse=True)[:5],
                "suspicious_count": len(suspicious),
            }

        except Exception as e:
            logger.error(f"YouTube scan error: {e}")
            return {"score": 0, "available": False, "error": str(e)}

    def _scan_trends(self, symbol: str, company_name: str) -> dict:
        """
        Check Google Trends for unusual search interest spike.
        pytrends is free — no API key needed.
        A search spike 2-5 days before a price spike = manipulation precursor.
        """
        try:
            from pytrends.request import TrendReq
            pt = TrendReq(hl="en-IN", tz=-330, timeout=(8,25))  # IST offset

            queries = [symbol]
            if company_name:
                queries.append(company_name[:50])

            pt.build_payload(
                kw_list=queries[:1],   # max 5, use primary
                cat=7,                 # category: Finance
                timeframe="now 7-d",
                geo="IN",
            )
            df = pt.interest_over_time()

            if df.empty:
                return {"score": 0, "available": True, "spike": False, "data": []}

            col   = queries[0]
            if col not in df.columns:
                col = df.columns[0]

            values = df[col].tolist()
            if not values:
                return {"score": 0, "available": True, "spike": False}

            mean_val  = sum(values[:-3]) / max(len(values[:-3]), 1)   # exclude last 3
            recent_max = max(values[-3:]) if len(values) >= 3 else values[-1]

            # Spike if recent max is 3x the historical mean
            spike_ratio = recent_max / (mean_val + 1e-9)
            spike       = spike_ratio > 3.0
            score       = min(100, (spike_ratio - 1) * 20) if spike_ratio > 1 else 0

            return {
                "score":       round(score, 1),
                "available":   True,
                "spike":       spike,
                "spike_ratio": round(spike_ratio, 2),
                "recent_max":  round(recent_max, 1),
                "mean_val":    round(mean_val, 1),
                "data":        [{"value": v} for v in values[-7:]],
            }

        except Exception as e:
            logger.debug(f"Google Trends unavailable: {e}")
            return {"score": 0, "available": False, "spike": False}


# Singleton
video_signal = SocialVideoSignal()
