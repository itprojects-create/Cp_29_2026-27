# ml-service/detector/ensemble.py — COMPLETE REPLACEMENT FILE
# 5-Layer Ensemble: Z-score + IF + RF + LSTM-AE + Vanilla-AE
# Combination: Dempster-Shafer evidence theory

import numpy as np
import joblib
import pandas as pd
from pathlib import Path
from loguru import logger
from detector.features import FEATURE_NAMES

MODELS_DIR         = Path(__file__).parent.parent / "models"
THRESHOLD_CRITICAL = 0.92   # was 0.85
THRESHOLD_HIGH     = 0.80   # was 0.70
THRESHOLD_MEDIUM   = 0.65   # was 0.55
THRESHOLD_LOW      = 0.40

# DS weights — must sum to 1.0
WEIGHTS = {
    "rule":       0.12,
    "if":         0.28,
    "rf":         0.24,
    "lstm":       0.18,
    "vanilla_ae": 0.10,   # NEW — sklearn autoencoder
    "cf":         0.08,
}


class _RandomForestWrapper:
    def __init__(self):
        self.model = None; self.scaler = None; self.loaded = False
        self._load()

    def _load(self):
        rf = MODELS_DIR / "random_forest.pkl"
        sc = MODELS_DIR / "rf_scaler.pkl"
        if rf.exists() and sc.exists():
            try:
                self.model = joblib.load(rf)
                self.model.n_jobs = 1  
                self.scaler = joblib.load(sc)
                self.loaded = True
                logger.info("Random Forest loaded")
            except Exception as e:
                logger.warning(f"RF load: {e}")

    def predict_proba(self, features):
        if not self.loaded or features is None:
            return 0.0
        try:
            scaler_input = (
                pd.DataFrame(features, columns=FEATURE_NAMES)
                if hasattr(self.scaler, "feature_names_in_") else features
            )
            return float(self.model.predict_proba(
                self.scaler.transform(scaler_input))[0][1])
        except Exception:
            return 0.0

    def reload(self): self._load()


rf_classifier = _RandomForestWrapper()


def _ds_combine(scores: dict, weights: dict) -> float:
    """Dempster-Shafer rule of combination."""
    b_m = 0.0; b_n = 0.0; b_t = 1.0
    for layer, score in scores.items():
        if score <= 0 or layer not in weights or weights[layer] <= 0:
            continue
        w = weights[layer]
        m_a = score * w; m_na = (1 - score) * w; m_th = 1.0 - w
        new_m = b_m * (m_a + m_th) + b_t * m_a
        new_n = b_n * (m_na + m_th) + b_t * m_na
        new_t = b_t * m_th
        tot = new_m + new_n + new_t
        if tot < 1e-9: continue
        b_m = new_m / tot; b_n = new_n / tot; b_t = new_t / tot
    return float(np.clip(b_m + 0.5 * b_t, 0, 1))


def compute_ensemble_score(
    if_score,
    rule_score,
    symbol,
    features,
    lstm_result=None,
    cf_result=None,
    vanilla_ae_result=None,   # NEW parameter
) -> dict:
    """
    Compute 5-layer ensemble score.
    
    Layers:
        1. Z-score rules    (rule_score)
        2. Isolation Forest (if_score)
        3. Random Forest    (rf — supervised, loaded internally)
        4. LSTM Autoencoder (lstm_result — sequential)
        5. Vanilla AE       (vanilla_ae_result — point anomaly, sklearn)
    
    Combined via Dempster-Shafer evidence theory.
    Collaborative filter acts as post-hoc amplifier.
    """
    # Layer 3: RF
    rf_score = rf_classifier.predict_proba(features)

    # Layer 4: LSTM-AE score
    lstm_score = 0.0
    if lstm_result and lstm_result.get("available"):
        lstm_score = lstm_result.get("anomaly_score", 0.0)

    # Layer 5: Vanilla AE score (sklearn, no PyTorch)
    vae_score = 0.0
    if vanilla_ae_result and vanilla_ae_result.get("available"):
        vae_score = vanilla_ae_result.get("anomaly_score", 0.0)

    # CF metadata
    cf_score        = cf_result.get("cf_score", 0.0)        if cf_result else 0.0
    cf_amplifier    = cf_result.get("amplifier", 1.0)       if cf_result else 1.0
    cf_signal       = cf_result.get("cf_signal", "NEUTRAL") if cf_result else "NEUTRAL"
    co_moving_peers = cf_result.get("co_moving_peers", [])  if cf_result else []

    # Build score dict
    scores = {
        "rule":       rule_score,
        "if":         if_score,
        "rf":         rf_score,
        "lstm":       lstm_score,
        "vanilla_ae": vae_score,
        "cf":         cf_score if cf_result else 0.0,
    }

    # Adjust weights if layers missing
    w = WEIGHTS.copy()
    if not rf_classifier.loaded:
        w["if"] += w["rf"] * 0.6; w["rule"] += w["rf"] * 0.4; w["rf"] = 0.0
    if lstm_score == 0.0:
        w["if"] += w["lstm"] * 0.5; w["vanilla_ae"] += w["lstm"] * 0.5; w["lstm"] = 0.0
    if vae_score == 0.0:
        w["if"] += w["vanilla_ae"] * 0.6; w["rule"] += w["vanilla_ae"] * 0.4; w["vanilla_ae"] = 0.0

    # Dempster-Shafer combination
    ensemble = _ds_combine(scores, w)

    # CF amplification
    if cf_signal == "COORDINATED" and ensemble > THRESHOLD_LOW:
        ensemble = float(np.clip(ensemble * cf_amplifier, 0, 1))
    elif cf_signal == "ISOLATED" and ensemble < THRESHOLD_HIGH:
        ensemble = float(np.clip(ensemble * cf_amplifier, 0, 1))

    # Level
    if   ensemble >= THRESHOLD_CRITICAL: level = "CRITICAL"
    elif ensemble >= THRESHOLD_HIGH:     level = "HIGH"
    elif ensemble >= THRESHOLD_MEDIUM:   level = "MEDIUM"
    elif ensemble >= THRESHOLD_LOW:      level = "LOW"
    else:                                level = "NONE"

    return {
        "ensemble_score":   round(ensemble, 4),
        "level":            level,
        "should_alert":     ensemble >= THRESHOLD_MEDIUM,
        # All 5 layer scores
        "if_score":         round(if_score, 4),
        "rf_score":         round(rf_score, 4),
        "lstm_score":       round(lstm_score, 4),
        "vanilla_ae_score": round(vae_score, 4),
        "rule_score":       round(rule_score, 4),
        # CF
        "cf_score":         round(cf_score, 4),
        "cf_amplifier":     round(cf_amplifier, 3),
        "cf_signal":        cf_signal,
        "co_moving_peers":  co_moving_peers,
        # LSTM metadata
        "lstm_recon_error":     lstm_result.get("recon_error", 0.0) if lstm_result else 0.0,
        "vanilla_ae_recon_error": vanilla_ae_result.get("recon_error", 0.0) if vanilla_ae_result else 0.0,
        "lstm_available":       lstm_result.get("available", False) if lstm_result else False,
        "vanilla_ae_available": vanilla_ae_result.get("available", False) if vanilla_ae_result else False,
        # Active layers list
        "active_layers": [k for k, v in scores.items() if v > 0],
    }
