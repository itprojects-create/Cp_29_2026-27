# ml-service/detector/isolation_forest.py
# Isolation Forest model wrapper.
# Loads pre-trained model from models/ folder.
# Falls back to Z-score-only mode if model not yet trained.

import numpy as np
import joblib
import os
import pandas as pd
from pathlib import Path
from loguru import logger
from detector.features import FEATURE_NAMES

MODELS_DIR = Path(__file__).parent.parent / "models"

class IsolationForestDetector:
    """
    Wrapper around sklearn IsolationForest.
    Handles loading, scoring, and per-symbol adaptive retraining.
    """

    def __init__(self):
        self.model = None
        self.scaler = None
        self.loaded = False
        self._load_model()

        # Per-symbol tick counters for adaptive retraining trigger
        self._tick_counts: dict[str, int] = {}
        RETRAIN_EVERY = 500  # Retrain after every 500 ticks per symbol

    def _load_model(self):
        """Load pre-trained model from disk if available."""
        if_path = MODELS_DIR / "isolation_forest.pkl"
        scaler_path = MODELS_DIR / "if_scaler.pkl"

        if if_path.exists() and scaler_path.exists():
            try:
                self.model = joblib.load(if_path)
                self.model.n_jobs = 1 
                self.scaler = joblib.load(scaler_path)
                self.loaded = True
                logger.info("Isolation Forest model loaded from disk")
            except Exception as e:
                logger.warning(f"Failed to load IF model: {e}")
                self.loaded = False
        else:
            logger.warning(
                "Isolation Forest model not found. "
                "Run: python trainer/train.py to build it first. "
                "Using Z-score rules only until model is trained."
            )
            self.loaded = False

    def score(self, features: np.ndarray) -> float:
        """
        Score a feature vector.

        Returns float 0.0 to 1.0 where:
            0.0 = definitely normal
            1.0 = definitely anomalous
        Returns 0.0 if model not loaded (falls back to rule-based).
        """
        if not self.loaded or features is None:
            return 0.0

        try:
            scaler_input = (
                pd.DataFrame(features, columns=FEATURE_NAMES)
                if hasattr(self.scaler, "feature_names_in_") else features
            )
            scaled = self.scaler.transform(scaler_input)
            raw_score = self.model.score_samples(scaled)[0]
            # IsolationForest: score near 0 = normal, more negative = anomaly
            # Convert to 0-1 range
            # score_samples range is roughly [-0.5, 0.5]
            # We map: -0.5 → 1.0, +0.5 → 0.0
            normalised = float(np.clip(1 - (raw_score + 0.5), 0, 1))
            return normalised
        except Exception as e:
            logger.error(f"IF scoring error: {e}")
            return 0.0

    def should_retrain(self, symbol: str) -> bool:
        """Check if enough ticks have accumulated to retrain for this symbol."""
        self._tick_counts[symbol] = self._tick_counts.get(symbol, 0) + 1
        return self._tick_counts[symbol] % 500 == 0

    def reload(self):
        """Reload model from disk after retraining."""
        self._load_model()


# Singleton instance — shared across all requests in the FastAPI app
detector = IsolationForestDetector()
