#!/usr/bin/env python3
# ml-service/detector/autoencoder.py
# COMPLETE FILE — Vanilla Autoencoder using sklearn MLPRegressor
#
# WHY THIS IN ADDITION TO LSTM-AE:
#   LSTM-AE:     scores SEQUENCES of 20 ticks → temporal patterns
#   Vanilla AE:  scores SINGLE ticks → point anomalies
#   Together:    point anomaly + sequence anomaly = stronger ensemble
#
# WHY sklearn (NOT PyTorch):
#   Avoids Windows DLL issues with PyTorch c10.dll
#   sklearn works on every machine, no GPU needed
#   Training time: ~30 seconds vs 6 minutes for LSTM
#   No separate install needed (already have sklearn)
#
# ARCHITECTURE:
#   Input  (20) → Hidden (16) → Bottleneck (6) → Hidden (16) → Output (20)
#   Encoder: 20 → 16 → 6    (compression)
#   Decoder: 6  → 16 → 20   (reconstruction)
#   Loss:    MSE(input, reconstructed)
#   Anomaly: reconstruction_error > threshold (95th percentile of normal)
#
# PAPER FRAMING (Section 4.3):
#   "A symmetric feedforward autoencoder (Hinton & Salakhutdinov, 2006)
#    with bottleneck dimension d=6 is trained on normal NSE trading days.
#    Anomaly score is the normalised MSE reconstruction error, with
#    threshold set at the 95th percentile of training errors."
#
# REFERENCE:
#   Hinton, G.E. & Salakhutdinov, R.R. (2006). Reducing the dimensionality
#   of data with neural networks. Science, 313(5786), 504-507.

import numpy as np
import joblib
import pandas as pd
from pathlib import Path
from loguru import logger
from detector.features import FEATURE_NAMES

MODELS_DIR = Path(__file__).parent.parent / "models"
FEAT_DIM = 20  # must match features.py FEAT_DIM


class VanillaAutoencoder:
    """
    Feedforward autoencoder for point-anomaly detection on individual ticks.
    Uses sklearn MLPRegressor internally — no PyTorch required.
    Trained on normal NSE trading data only.
    """

    def __init__(self):
        self.encoder = None   # sklearn MLPRegressor (20 → 16 → 6)
        self.decoder = None   # sklearn MLPRegressor (6 → 16 → 20)
        self.scaler = None
        self.threshold = None
        self.loaded = False
        self._load()

    def _load(self):
        enc_path = MODELS_DIR / "vanilla_ae_encoder.pkl"
        dec_path = MODELS_DIR / "vanilla_ae_decoder.pkl"
        sc_path = MODELS_DIR / "vanilla_ae_scaler.pkl"
        thr_path = MODELS_DIR / "vanilla_ae_threshold.pkl"

        if not all(p.exists() for p in [enc_path, dec_path, sc_path, thr_path]):
            logger.warning(
                "Vanilla Autoencoder not trained. "
                "Run: python trainer/train_autoencoder.py"
            )
            return

        try:
            self.encoder = joblib.load(enc_path)
            self.decoder = joblib.load(dec_path)
            self.scaler = joblib.load(sc_path)
            self.threshold = joblib.load(thr_path)
            self.loaded = True
            logger.info(f"Vanilla Autoencoder loaded (threshold={self.threshold:.4f})")
        except Exception as e:
            logger.error(f"Vanilla AE load failed: {e}")

    def score(self, features: np.ndarray) -> dict:
        """
        Compute anomaly score for a single tick's feature vector.

        Args:
            features: np.ndarray shape (1, FEAT_DIM) — raw features

        Returns:
            {
              "anomaly_score":    float 0-1,
              "recon_error":      float (raw MSE),
              "is_anomaly":       bool,
              "available":        bool,
              "bottleneck":       list[float] — 6D latent representation
            }
        """
        if not self.loaded or features is None:
            return {
                "anomaly_score": 0.0,
                "recon_error": 0.0,
                "is_anomaly": False,
                "available": False,
                "bottleneck": [],
            }

        try:
            scaler_input = (
                pd.DataFrame(features, columns=FEATURE_NAMES)
                if hasattr(self.scaler, "feature_names_in_") else features
            )
            X = self.scaler.transform(scaler_input)
            bottleneck = self.encoder.predict(X)
            reconstructed = self.decoder.predict(bottleneck)
            recon_error = float(np.mean((X - reconstructed) ** 2))
            anomaly_score = float(np.clip(recon_error / (self.threshold + 1e-9), 0, 1))
            is_anomaly = recon_error > self.threshold

            return {
                "anomaly_score": round(anomaly_score, 4),
                "recon_error": round(recon_error, 6),
                "is_anomaly": is_anomaly,
                "available": True,
                "bottleneck": bottleneck.flatten().tolist(),
            }

        except Exception as e:
            logger.error(f"Vanilla AE score error: {e}")
            return {
                "anomaly_score": 0.0, "recon_error": 0.0,
                "is_anomaly": False, "available": True,
                "bottleneck": [],
            }

    def encode(self, features: np.ndarray) -> np.ndarray:
        """Return 6D bottleneck representation. Useful for clustering."""
        if not self.loaded:
            return np.zeros((1, 6))
        scaler_input = (
            pd.DataFrame(features, columns=FEATURE_NAMES)
            if hasattr(self.scaler, "feature_names_in_") else features
        )
        X = self.scaler.transform(scaler_input)
        return self.encoder.predict(X)

    def reload(self):
        self._load()


# Singleton
vanilla_ae = VanillaAutoencoder()
