# ml-service/detector/lstm_autoencoder.py
#
# LSTM Autoencoder for sequential anomaly detection.
# Addresses mentor recommendation: "Study Neural N/W → Autoencoder"
#
# THEORETICAL BASIS:
# ─────────────────────────────────────────────────────────────────────
# An autoencoder learns a compressed representation of NORMAL sequences.
# Architecture:
#
#   Input sequence (T × F)
#       ↓  Encoder LSTM
#   Latent vector h (compressed representation)
#       ↓  Decoder LSTM
#   Reconstructed sequence (T × F)
#
# During training: only normal trading sequences fed in.
# Model learns: "what does a normal 20-tick window look like?"
#
# At inference:
#   reconstruction_error = MSE(input, reconstructed)
#   High error → sequence doesn't look like anything normal → ANOMALY
#
# WHY BETTER THAN ISOLATION FOREST ALONE:
#   IF scores each tick independently (point anomaly).
#   LSTM-AE scores the SEQUENCE — captures temporal patterns like
#   sustained coordinated buying over 20 minutes that looks normal
#   tick-by-tick but abnormal as a sequence.
#
# PAPER REFERENCE:
#   Malhotra et al. "LSTM-based Encoder-Decoder for Multi-sensor
#   Anomaly Detection" (ICML 2016) — foundational work this builds on.
#
# ─────────────────────────────────────────────────────────────────────

import numpy as np
import joblib
from pathlib import Path
from loguru import logger

MODELS_DIR = Path(__file__).parent.parent / "models"

# Sequence length — how many ticks constitute one "window" for the LSTM
SEQ_LEN = 20

# Feature dimension — must match features.py FEATURE_NAMES length
FEAT_DIM = 20


class LSTMAutoencoder:
    """
    PyTorch LSTM Autoencoder for sequential anomaly detection.
    Trained exclusively on normal trading sequences.
    """

    def __init__(self, feat_dim: int = FEAT_DIM, hidden_dim: int = 64,
                 latent_dim: int = 32, num_layers: int = 2):
        self.feat_dim   = feat_dim
        self.hidden_dim = hidden_dim
        self.latent_dim = latent_dim
        self.num_layers = num_layers
        self.model      = None
        self.scaler     = None
        self.threshold  = None   # Reconstruction error threshold (95th percentile of normal)
        self.loaded     = False
        self._load()

    # ── PyTorch model definition ──────────────────────────────────────

    def _build_model(self):
        """Build the encoder-decoder architecture."""
        try:
            import torch
            import torch.nn as nn

            class _Encoder(nn.Module):
                def __init__(self, feat_dim, hidden_dim, latent_dim, num_layers):
                    super().__init__()
                    self.lstm = nn.LSTM(feat_dim, hidden_dim, num_layers,
                                        batch_first=True, dropout=0.2)
                    self.fc   = nn.Linear(hidden_dim, latent_dim)

                def forward(self, x):
                    _, (h, _) = self.lstm(x)
                    return self.fc(h[-1])   # Last hidden state → latent

            class _Decoder(nn.Module):
                def __init__(self, latent_dim, hidden_dim, feat_dim, num_layers, seq_len):
                    super().__init__()
                    self.seq_len = seq_len
                    self.fc      = nn.Linear(latent_dim, hidden_dim)
                    self.lstm    = nn.LSTM(hidden_dim, hidden_dim, num_layers,
                                           batch_first=True, dropout=0.2)
                    self.out     = nn.Linear(hidden_dim, feat_dim)

                def forward(self, z):
                    h = self.fc(z).unsqueeze(1).repeat(1, self.seq_len, 1)
                    out, _ = self.lstm(h)
                    return self.out(out)    # (batch, seq_len, feat_dim)

            class _LSTMAEModel(nn.Module):
                def __init__(self, feat_dim, hidden_dim, latent_dim, num_layers, seq_len):
                    super().__init__()
                    self.encoder = _Encoder(feat_dim, hidden_dim, latent_dim, num_layers)
                    self.decoder = _Decoder(latent_dim, hidden_dim, feat_dim, num_layers, seq_len)

                def forward(self, x):
                    z    = self.encoder(x)
                    recon = self.decoder(z)
                    return recon, z

            return _LSTMAEModel(self.feat_dim, self.hidden_dim,
                                self.latent_dim, self.num_layers, SEQ_LEN)
        except ImportError:
            return None

    # ── Load pre-trained model ────────────────────────────────────────

    def _load(self):
        model_path  = MODELS_DIR / "lstm_ae.pt"
        scaler_path = MODELS_DIR / "lstm_ae_scaler.pkl"
        thresh_path = MODELS_DIR / "lstm_ae_threshold.pkl"

        if not all(p.exists() for p in [model_path, scaler_path, thresh_path]):
            logger.warning(
                "LSTM Autoencoder not trained yet.\n"
                "Run: python trainer/train_lstm.py\n"
                "Falling back to IF+RF ensemble."
            )
            return

        try:
            import torch
            model = self._build_model()
            if model is None:
                return
            state_dict = torch.load(model_path, map_location="cpu", weights_only=True)
            try:
                model.load_state_dict(state_dict)
            except RuntimeError:
                # Backward compatibility for checkpoints saved with enc/dec naming.
                remapped = {}
                for key, value in state_dict.items():
                    if key.startswith("enc."):
                        remapped[key.replace("enc.", "encoder.", 1)] = value
                    elif key.startswith("dec."):
                        remapped[key.replace("dec.", "decoder.", 1)] = value
                    else:
                        remapped[key] = value
                model.load_state_dict(remapped)
            model.eval()
            self.model     = model
            self.scaler    = joblib.load(scaler_path)
            self.threshold = joblib.load(thresh_path)
            self.loaded    = True
            logger.info(f"LSTM Autoencoder loaded (threshold={self.threshold:.4f})")
        except Exception as e:
            logger.error(f"LSTM-AE load failed: {e}")

    # ── Inference ─────────────────────────────────────────────────────

    def score_sequence(self, sequence: np.ndarray) -> dict:
        """
        Score a sequence of feature vectors.

        Args:
            sequence: np.ndarray shape (SEQ_LEN, FEAT_DIM)
                     — the last SEQ_LEN ticks' feature vectors

        Returns:
            {
              "recon_error": float,     — MSE reconstruction error
              "anomaly_score": float,   — 0-1 normalised score
              "is_anomaly": bool,       — above threshold
              "available": bool         — False if model not loaded
            }
        """
        if not self.loaded or self.model is None:
            return {"recon_error": 0.0, "anomaly_score": 0.0,
                    "is_anomaly": False, "available": False}

        if sequence.shape[0] < SEQ_LEN:
            return {"recon_error": 0.0, "anomaly_score": 0.0,
                    "is_anomaly": False, "available": True}

        try:
            import torch
            seq = sequence[-SEQ_LEN:]  # Take last SEQ_LEN rows

            # Scale
            orig_shape = seq.shape
            seq_flat   = self.scaler.transform(seq.reshape(-1, self.feat_dim))
            seq_scaled = seq_flat.reshape(orig_shape)

            # Forward pass
            x_tensor = torch.FloatTensor(seq_scaled).unsqueeze(0)  # (1, T, F)
            with torch.no_grad():
                recon, _ = self.model(x_tensor)

            # Reconstruction error (MSE per feature, then mean)
            recon_error = float(
                torch.mean((x_tensor - recon) ** 2).item()
            )

            # Normalise to 0-1 using threshold
            # score = 1 means error is AT the threshold
            # score > 1 clipped to 1
            anomaly_score = float(np.clip(recon_error / (self.threshold + 1e-9), 0, 1))
            is_anomaly    = recon_error > self.threshold

            return {
                "recon_error":   round(recon_error, 6),
                "anomaly_score": round(anomaly_score, 4),
                "is_anomaly":    is_anomaly,
                "available":     True,
            }

        except Exception as e:
            logger.error(f"LSTM-AE scoring error: {e}")
            return {"recon_error": 0.0, "anomaly_score": 0.0,
                    "is_anomaly": False, "available": True}

    def reload(self):
        self._load()


# Singleton
lstm_ae_detector = LSTMAutoencoder()
