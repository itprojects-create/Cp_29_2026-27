#!/usr/bin/env python3
# ml-service/angelone_forwarder.py
#
# Angel One SmartAPI — WebSocket live tick forwarder + historical data downloader.
# Replaces breeze_forwarder.py entirely.
#
# TWO JOBS:
#   1. LIVE: Connect SmartWebSocketV2, stream ticks → POST to Node.js /internal/tick
#   2. HISTORICAL: Download 1-minute candle data for training (up to 60 days back)
#
# SETUP (takes 5 minutes):
#   Step 1: Go to smartapi.angelbroking.com → Create App → get API Key
#   Step 2: Go to smartapi.angelbroking.com/enable-totp → scan QR → copy TOTP secret
#   Step 3: Add to .env:
#     ANGELONE_API_KEY=your_api_key
#     ANGELONE_CLIENT_ID=your_client_id   (your Angel One login ID)
#     ANGELONE_MPIN=your_mpin             (4-6 digit MPIN)
#     ANGELONE_TOTP_SECRET=JBSWY3DPEHPK3PXP  (the secret from QR scan)
#
# RUN LIVE FEED:
#   python angelone_forwarder.py
#
# DOWNLOAD HISTORICAL (for training):
#   python angelone_forwarder.py --historical

import os
import sys
import json
import time
import argparse
import requests
import pandas as pd
import ssl
from pathlib import Path
from datetime import datetime, timedelta
from loguru import logger
from dotenv import load_dotenv

load_dotenv(dotenv_path=Path(__file__).parent.parent / ".env")

# Angel One's certificate chain is failing validation in this environment.
# SmartAPI supports disabling verification explicitly via its client option.
# This is required for local/dev workarounds when the broker certificate is not trusted.

# ── Credentials from .env ─────────────────────────────────────────────────
API_KEY      = os.getenv("ANGELONE_API_KEY", "")
CLIENT_ID    = os.getenv("ANGELONE_CLIENT_ID", "")
MPIN         = os.getenv("ANGELONE_MPIN", "")
TOTP_SECRET  = os.getenv("ANGELONE_TOTP_SECRET", "")

# Node.js internal endpoint
NODE_TICK_URL = os.getenv("NODE_TICK_URL", "http://localhost:3001/internal/tick")

# ── NSE Stock tokens for SmartAPI ─────────────────────────────────────────
# Token list from: https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json
# Format: symbol_name: (token_id, exchange_type)
# exchangeType: 1=NSE_CM, 2=NSE_FO, 3=BSE_CM, 4=BSE_FO, 5=MCX_FO
STOCK_TOKENS = {
    "RELIANCE":   ("2885",  1),
    "HDFCBANK":   ("1333",  1),
    "INFY":       ("1594",  1),
    "TCS":        ("11536", 1),
    "ICICIBANK":  ("4963",  1),
    "KOTAKBANK":  ("1922",  1),
    "SBIN":       ("3045",  1),
    "AXISBANK":   ("5900",  1),
    "BAJFINANCE": ("317",   1),
    "WIPRO":      ("3787",  1),
    "ZOMATO":     ("5097",  1),
    "NYKAA":      ("16675", 1),
    "PAYTM":      ("16669", 1),
    "ADANIENT":   ("25",    1),
    "YESBANK":    ("11915", 1),
}

# Reverse lookup: token → symbol
TOKEN_TO_SYMBOL = {v[0]: k for k, v in STOCK_TOKENS.items()}

# ── WebSocket modes ───────────────────────────────────────────────────────
# Mode 1 = LTP only
# Mode 2 = LTP + OHLC
# Mode 3 = Full snapshot (LTP, OHLC, volume, best bid/ask)
WS_MODE = 3


def get_session():
    """
    Authenticate with Angel One SmartAPI and return session objects.
    Returns: (SmartConnect obj, auth_token, feed_token) or raises on failure.
    """
    if not all([API_KEY, CLIENT_ID, MPIN, TOTP_SECRET]):
        raise ValueError(
            "Angel One credentials not set in .env\n"
            "Required: ANGELONE_API_KEY, ANGELONE_CLIENT_ID, "
            "ANGELONE_MPIN, ANGELONE_TOTP_SECRET\n"
            "Setup: smartapi.angelbroking.com → Create App + Enable TOTP"
        )

    try:
        import pyotp
        from SmartApi import SmartConnect
    except ImportError:
        raise ImportError(
            "Install required packages:\n"
            "  pip install smartapi-python pyotp logzero"
        )

    obj = SmartConnect(api_key=API_KEY, disable_ssl=True)
    totp = pyotp.TOTP(TOTP_SECRET).now()

    data = obj.generateSession(CLIENT_ID, MPIN, totp)
    if not data.get("status"):
        raise ConnectionError(f"Login failed: {data.get('message', 'unknown error')}")

    auth_token = data["data"]["jwtToken"]
    feed_token = obj.getfeedToken()

    logger.info(f"Angel One session established for {CLIENT_ID}")
    return obj, auth_token, feed_token


# ══════════════════════════════════════════════════════════════════════════
# LIVE TICK STREAMING via SmartWebSocketV2
# ══════════════════════════════════════════════════════════════════════════

def start_live_feed():
    """
    Connect SmartWebSocketV2 and stream live ticks to Node.js.
    Automatically reconnects on disconnect.
    """
    from SmartApi.smartWebSocketV2 import SmartWebSocketV2

    obj, auth_token, feed_token = get_session()

    # Build token subscription list grouped by exchangeType
    # exchangeType 1 = NSE_CM
    nse_tokens = [tok for tok, (tok_id, exch) in STOCK_TOKENS.items() if exch == 1]
    token_list = [{
        "exchangeType": 1,
        "tokens": [STOCK_TOKENS[sym][0] for sym in nse_tokens],
    }]

    sws = SmartWebSocketV2(auth_token, API_KEY, CLIENT_ID, feed_token)

    def on_data(wsapp, message):
        """Called for every incoming tick from Angel One."""
        try:
            # SmartWebSocketV2 sends binary data decoded as dict
            if isinstance(message, str):
                message = json.loads(message)

            token = str(message.get("token", ""))
            symbol = TOKEN_TO_SYMBOL.get(token, f"TOKEN_{token}")

            ltp     = float(message.get("last_traded_price", 0)) / 100   # SmartAPI sends paise → rupees
            volume  = int(message.get("volume_trade_for_the_day", 0))
            open_p  = float(message.get("open_price_of_the_day", ltp * 100)) / 100
            high_p  = float(message.get("high_price_of_the_day", ltp * 100)) / 100
            low_p   = float(message.get("low_price_of_the_day", ltp * 100)) / 100

            if ltp <= 0:
                return

            tick = {
                "symbol":    symbol,
                "price":     round(ltp, 2),
                "volume":    volume,
                "high":      round(high_p, 2),
                "low":       round(low_p, 2),
                "open":      round(open_p, 2),
                "timestamp": datetime.now().isoformat(),
                "source":    "angelone_ws",
            }

            _forward_to_node(tick)

        except Exception as e:
            logger.error(f"Tick parse error: {e} | raw: {message}")

    def on_open(wsapp):
        logger.info("WebSocket connected — subscribing to tokens...")
        sws.subscribe("stock_detector", WS_MODE, token_list)
        logger.info(f"Subscribed to {len(nse_tokens)} NSE stocks (mode {WS_MODE})")

    def on_error(wsapp, error):
        logger.error(f"WebSocket error: {error}")

    def on_close(wsapp):
        logger.warning("WebSocket closed — will reconnect in 5s")
        time.sleep(5)

    sws.on_open  = on_open
    sws.on_data  = on_data
    sws.on_error = on_error
    sws.on_close = on_close

    logger.info(f"Starting Angel One WebSocket feed → {NODE_TICK_URL}")

    while True:
        try:
            sws.connect()
        except Exception as e:
            logger.error(f"Connection failed: {e} — retrying in 10s")
            time.sleep(10)
            # Refresh session on reconnect
            try:
                obj, auth_token, feed_token = get_session()
                sws = SmartWebSocketV2(auth_token, API_KEY, CLIENT_ID, feed_token)
                sws.on_open  = on_open
                sws.on_data  = on_data
                sws.on_error = on_error
                sws.on_close = on_close
            except Exception as e2:
                logger.error(f"Session refresh failed: {e2}")
                time.sleep(30)


def _forward_to_node(tick: dict):
    """POST a tick to Node.js internal endpoint. Fire-and-forget."""
    try:
        requests.post(NODE_TICK_URL, json=tick, timeout=0.5)
    except requests.exceptions.ConnectionError:
        pass   # Node not running — silently skip
    except requests.exceptions.Timeout:
        pass   # Node busy — skip this tick


# ══════════════════════════════════════════════════════════════════════════
# HISTORICAL CANDLE DATA DOWNLOAD (for training)
# ══════════════════════════════════════════════════════════════════════════
# Angel One gives FREE historical candle data at:
#   ONE_MINUTE, THREE_MINUTE, FIVE_MINUTE, TEN_MINUTE,
#   FIFTEEN_MINUTE, THIRTY_MINUTE, ONE_HOUR, ONE_DAY
# Limit: 60 days per call for intraday intervals

DATA_DIR = Path(__file__).parent / "data"
DATA_DIR.mkdir(exist_ok=True)


def download_historical(
    symbol: str,
    token_id: str,
    interval: str = "ONE_DAY",
    days_back: int = 365,
) -> pd.DataFrame:
    """
    Download historical candle data for one symbol via SmartAPI getCandleData.

    Args:
        symbol:    NSE symbol e.g. "RELIANCE"
        token_id:  SmartAPI token e.g. "2885"
        interval:  "ONE_MINUTE", "FIVE_MINUTE", "ONE_DAY", etc.
        days_back: How many days of history to fetch

    Returns:
        DataFrame with columns: datetime, open, high, low, close, volume
    """
    obj, _, _ = get_session()

    # SmartAPI caps intraday at 60 days per request — chunk if needed
    all_rows = []
    end_dt   = datetime.now()
    chunk_days = 59 if interval != "ONE_DAY" else days_back

    while days_back > 0:
        chunk = min(days_back, chunk_days)
        start_dt = end_dt - timedelta(days=chunk)

        params = {
            "exchange":    "NSE",
            "symboltoken": token_id,
            "interval":    interval,
            "fromdate":    start_dt.strftime("%Y-%m-%d %H:%M"),
            "todate":      end_dt.strftime("%Y-%m-%d %H:%M"),
        }

        try:
            resp = obj.getCandleData(params)
            if resp.get("status") and resp.get("data"):
                rows = resp["data"]
                # Each row: [datetime_str, open, high, low, close, volume]
                df_chunk = pd.DataFrame(rows, columns=["datetime","open","high","low","close","volume"])
                df_chunk["datetime"] = pd.to_datetime(df_chunk["datetime"])
                df_chunk["symbol"] = symbol
                all_rows.append(df_chunk)
                logger.info(f"  {symbol} {interval}: {len(rows)} rows ({start_dt.date()} → {end_dt.date()})")
            else:
                logger.warning(f"  {symbol}: empty response for {start_dt.date()} → {end_dt.date()}")
        except Exception as e:
            logger.error(f"  {symbol}: API error — {e}")

        end_dt = start_dt - timedelta(days=1)
        days_back -= chunk
        time.sleep(0.3)   # Polite rate limiting

    if not all_rows:
        return pd.DataFrame()

    combined = pd.concat(all_rows).drop_duplicates("datetime").sort_values("datetime")
    combined = combined.reset_index(drop=True)
    return combined


def download_all_historical(interval: str = "ONE_DAY", days_back: int = 1825):
    """
    Download historical data for all watchlist symbols.
    Saves to data/angel_{SYMBOL}_{interval}.csv

    Default: ONE_DAY × 5 years = full training dataset
    For intraday: use interval="ONE_MINUTE" days_back=60 (API limit)
    """
    logger.info(f"Downloading {interval} data for {len(STOCK_TOKENS)} symbols...")
    logger.info(f"Days back: {days_back}")

    for symbol, (token_id, _) in STOCK_TOKENS.items():
        out_path = DATA_DIR / f"angel_{symbol}_{interval}.csv"
        if out_path.exists():
            existing = pd.read_csv(out_path)
            logger.info(f"  {symbol}: already exists ({len(existing)} rows) — skipping")
            continue

        df = download_historical(symbol, token_id, interval, days_back)
        if not df.empty:
            df.to_csv(out_path, index=False)
            logger.info(f"  ✅ {symbol}: {len(df)} rows saved → {out_path.name}")
        else:
            logger.warning(f"  ❌ {symbol}: no data returned")

    logger.info("\nDone. Files saved to ml-service/data/")
    logger.info("Next: python trainer/train.py")


# ══════════════════════════════════════════════════════════════════════════
# TOKEN LOOKUP HELPER
# (download fresh token list from Angel One)
# ══════════════════════════════════════════════════════════════════════════

def fetch_token_for_symbol(symbol_name: str) -> str | None:
    """
    Look up Angel One token ID for any NSE equity symbol.
    Downloads the full scrip master JSON (~30MB) and filters.
    """
    url = "https://margincalculator.angelbroking.com/OpenAPI_File/files/OpenAPIScripMaster.json"
    try:
        logger.info(f"Fetching scrip master to find token for {symbol_name}...")
        data = requests.get(url, timeout=30).json()
        df = pd.DataFrame(data)
        # Filter NSE equities
        match = df[(df["exch_seg"] == "NSE") & (df["symbol"] == f"{symbol_name}-EQ")]
        if not match.empty:
            token = match.iloc[0]["token"]
            logger.info(f"  {symbol_name}: token = {token}")
            return str(token)
        logger.warning(f"  {symbol_name}: not found in scrip master")
        return None
    except Exception as e:
        logger.error(f"Scrip master fetch failed: {e}")
        return None


# ══════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Angel One SmartAPI Data Tool")
    parser.add_argument("--historical", action="store_true",
                        help="Download historical data for training")
    parser.add_argument("--interval", default="ONE_DAY",
                        choices=["ONE_MINUTE","FIVE_MINUTE","FIFTEEN_MINUTE",
                                 "THIRTY_MINUTE","ONE_HOUR","ONE_DAY"],
                        help="Candle interval for historical download")
    parser.add_argument("--days", type=int, default=1825,
                        help="Days of history to download (max 60 for intraday)")
    parser.add_argument("--lookup", type=str,
                        help="Look up token ID for a symbol e.g. --lookup TATAMOTORS")
    args = parser.parse_args()

    if args.lookup:
        fetch_token_for_symbol(args.lookup)
    elif args.historical:
        logger.info("=== Angel One Historical Data Download ===")
        if args.interval != "ONE_DAY" and args.days > 60:
            logger.warning(f"Intraday limit is 60 days. Capping to 60.")
            args.days = 60
        download_all_historical(interval=args.interval, days_back=args.days)
    else:
        logger.info("=== Angel One Live Feed ===")
        start_live_feed()
