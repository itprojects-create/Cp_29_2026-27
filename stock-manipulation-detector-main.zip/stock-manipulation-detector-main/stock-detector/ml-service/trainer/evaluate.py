#!/usr/bin/env python3
# ml-service/trainer/evaluate.py
#
# Paper-grade evaluation framework.
# Produces all metrics needed for a technical paper presentation:
#
#   1. Per-model metrics:   Precision, Recall, F1, AUC-ROC
#   2. Ensemble comparison: Baseline (rules only) vs each ablation vs full
#   3. Detection lag:       How many days BEFORE the peak did each model alert?
#   4. False positive rate: On pre-event normal windows
#   5. Cross-case summary:  Table of results per SEBI case
#
# Run: python trainer/evaluate.py
# Outputs: evaluation_report.json + prints LaTeX table for paper

import torch
import sys, json, numpy as np, pandas as pd, joblib
from pathlib import Path
from loguru import logger
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

sys.path.insert(0, str(Path(__file__).parent.parent))

from detector.features       import extract_features, FEATURE_NAMES, WINDOW
from detector.zscore_rules   import detect_zscore
from detector.isolation_forest import detector as if_detector
from detector.lstm_autoencoder import lstm_ae_detector
from detector.collaborative_filter import cf_filter
from detector.ensemble       import compute_ensemble_score
from trainer.download_data   import load_symbol
from trainer.label_events    import MANIPULATION_EVENTS

MODELS_DIR  = Path(__file__).parent.parent / "models"
REPORTS_DIR = Path(__file__).parent.parent / "reports"
REPORTS_DIR.mkdir(exist_ok=True)

# Alert threshold for evaluation
from detector.ensemble import THRESHOLD_MEDIUM as ALERT_THRESHOLD

# Detection evaluation window around each event
PRE_EVENT_DAYS  = 30   # Normal baseline window before event
POST_EVENT_DAYS = 10   # Buffer after event end


def score_single_row(price, volume, high, low, history, symbol) -> dict:
    """Score one data row using all 4 layers."""
    feats = extract_features(price, volume, high, low, history)
    if feats is None:
        return {"ensemble_score": 0.0, "if_score": 0.0, "rf_score": 0.0,
                "lstm_score": 0.0, "rule_score": 0.0, "level": "NONE"}

    feats_dict = {n: float(feats.flatten()[i]) for i, n in enumerate(FEATURE_NAMES)}

    # Layer 1: Z-score rules
    rule = detect_zscore(feats_dict, symbol)
    rule_score = rule["rule_score"] if rule else 0.0

    # Layer 2: Isolation Forest
    if_score = if_detector.score(feats)

    # Layer 3: LSTM-AE (needs sequence — use last SEQ_LEN feature vectors)
    lstm_result = None
    if lstm_ae_detector.loaded and len(history) >= 20:
        seq_rows = []
        for h in history[-20:]:
            hf = extract_features(h["price"], h["volume"],
                                   h.get("high", h["price"]),
                                   h.get("low",  h["price"]),
                                   history[:history.index(h)])
            if hf is not None:
                seq_rows.append(hf.flatten())
        if len(seq_rows) >= 20:
            lstm_result = lstm_ae_detector.score_sequence(np.array(seq_rows))

    # Layer 4: CF
    cf_result = cf_filter.compute_cf_score(symbol, if_score)

    return compute_ensemble_score(if_score, rule_score, symbol, feats,
                                   lstm_result, cf_result)


def evaluate_case(event: dict) -> dict:
    """Evaluate all detection layers on one SEBI manipulation case."""
    symbol = event["symbol"]
    e_start = pd.Timestamp(event["start"])
    e_end   = pd.Timestamp(event["end"])

    try:
        df = load_symbol(symbol).sort_index()
    except FileNotFoundError:
        logger.warning(f"  {symbol}: no data file")
        return None

    win_start = e_start - pd.Timedelta(days=PRE_EVENT_DAYS + 5)
    win_end   = e_end   + pd.Timedelta(days=POST_EVENT_DAYS)
    df_win    = df[(df.index >= win_start) & (df.index <= win_end)]

    if len(df_win) < WINDOW + 5:
        logger.warning(f"  {symbol}: window too small")
        return None

    daily_scores = []
    for i in range(WINDOW + 1, len(df_win)):
        hist_slice = df[df.index < df_win.index[i]].tail(WINDOW)
        history = [{"price": float(r["close"]), "volume": int(r["volume"]),
                    "high":  float(r.get("high", r["close"])),
                    "low":   float(r.get("low",  r["close"]))}
                   for _, r in hist_slice.iterrows()]
        row = df_win.iloc[i]
        result = score_single_row(
            float(row["close"]), int(row["volume"]),
            float(row.get("high", row["close"])),
            float(row.get("low",  row["close"])),
            history, symbol,
        )
        result["date"]     = df_win.index[i]
        result["in_event"] = e_start <= df_win.index[i] <= e_end
        result["label"]    = 1 if result["in_event"] else 0
        daily_scores.append(result)

    sdf = pd.DataFrame(daily_scores)
    if sdf.empty:
        return None

    event_rows  = sdf[sdf["in_event"]]
    normal_rows = sdf[~sdf["in_event"]]

    def metrics_for_score_col(col):
        y_true = sdf["label"].values
        y_pred = (sdf[col].values > ALERT_THRESHOLD).astype(int)
        y_prob = sdf[col].values

        tp = int(((y_pred == 1) & (y_true == 1)).sum())
        fp = int(((y_pred == 1) & (y_true == 0)).sum())
        fn = int(((y_pred == 0) & (y_true == 1)).sum())
        tn = int(((y_pred == 0) & (y_true == 0)).sum())

        precision = tp / (tp + fp + 1e-9)
        recall    = tp / (tp + fn + 1e-9)
        f1        = 2 * precision * recall / (precision + recall + 1e-9)
        fp_rate   = fp / (fp + tn + 1e-9)

        try:
            from sklearn.metrics import roc_auc_score
            auc = float(roc_auc_score(y_true, y_prob))
        except Exception:
            auc = 0.0

        # Detection lag: days from event start to first alert
        event_alerts = sdf[(sdf["in_event"]) & (sdf[col] > ALERT_THRESHOLD)]
        if not event_alerts.empty:
            first_alert = event_alerts["date"].min()
            lag_days    = max(0, (e_end - first_alert).days)
        else:
            lag_days = -1   # Missed

        return {
            "precision": round(precision, 3),
            "recall":    round(recall,    3),
            "f1":        round(f1,        3),
            "auc_roc":   round(auc,       3),
            "fp_rate":   round(fp_rate,   3),
            "lag_days":  lag_days,
            "detected":  lag_days >= 0,
        }

    # Evaluate all score columns
    cols = {
        "rules_only":   "rule_score",
        "if_only":      "if_score",
        "rf_only":      "rf_score",
        "lstm_only":    "lstm_score",
        "ensemble":     "ensemble_score",
    }
    layer_metrics = {name: metrics_for_score_col(col) for name, col in cols.items()}

    return {
        "symbol":        symbol,
        "event_type":    event["type"],
        "event_start":   str(e_start.date()),
        "event_end":     str(e_end.date()),
        "event_days":    len(event_rows),
        "normal_days":   len(normal_rows),
        "max_ensemble":  round(float(event_rows["ensemble_score"].max()) if not event_rows.empty else 0, 3),
        "avg_ensemble":  round(float(event_rows["ensemble_score"].mean()) if not event_rows.empty else 0, 3),
        "layer_metrics": layer_metrics,
        "scores_df":     sdf[["date","ensemble_score","if_score","rf_score",
                               "lstm_score","rule_score","in_event","label"]].to_dict("records"),
    }


def print_latex_table(results: list):
    """Print a LaTeX table for inclusion in the technical paper."""
    print("\n" + "=" * 80)
    print("LaTeX TABLE FOR PAPER (copy directly)")
    print("=" * 80)
    print(r"""\begin{table}[h]
\centering
\caption{Per-Case Detection Performance of 4-Layer Ensemble vs Ablations}
\begin{tabular}{lcccccc}
\hline
\textbf{Case} & \textbf{Rules} & \textbf{IF} & \textbf{RF} & \textbf{LSTM-AE} & \textbf{Ensemble} & \textbf{Lag(d)} \\
              & F1 & F1 & F1 & F1 & F1 (AUC) & \\
\hline""")

    for r in results:
        if r is None: continue
        m = r["layer_metrics"]
        row = (
            f"{r['symbol']} ({r['event_type'][:12]}) & "
            f"{m['rules_only']['f1']:.2f} & "
            f"{m['if_only']['f1']:.2f} & "
            f"{m['rf_only']['f1']:.2f} & "
            f"{m['lstm_only']['f1']:.2f} & "
            f"\\textbf{{{m['ensemble']['f1']:.2f}}} ({m['ensemble']['auc_roc']:.2f}) & "
            f"{m['ensemble']['lag_days']} \\\\"
        )
        print(row)

    # Averages
    valid = [r for r in results if r]
    if valid:
        avgs = {}
        for key in ["rules_only", "if_only", "rf_only", "lstm_only", "ensemble"]:
            avgs[key] = {
                "f1":      np.mean([r["layer_metrics"][key]["f1"]    for r in valid]),
                "auc_roc": np.mean([r["layer_metrics"][key]["auc_roc"] for r in valid]),
                "lag_days":np.mean([r["layer_metrics"][key]["lag_days"] for r in valid
                                    if r["layer_metrics"][key]["lag_days"] >= 0]),
            }
        print(r"\hline")
        print(
            f"\\textbf{{Average}} & "
            f"{avgs['rules_only']['f1']:.2f} & "
            f"{avgs['if_only']['f1']:.2f} & "
            f"{avgs['rf_only']['f1']:.2f} & "
            f"{avgs['lstm_only']['f1']:.2f} & "
            f"\\textbf{{{avgs['ensemble']['f1']:.2f}}} ({avgs['ensemble']['auc_roc']:.2f}) & "
            f"{avgs['ensemble']['lag_days']:.1f} \\\\"
        )
    print(r"""\hline
\end{tabular}
\label{tab:eval}
\end{table}""")


def main():
    logger.info("=" * 60)
    logger.info("PAPER-GRADE EVALUATION — 4-LAYER ENSEMBLE")
    logger.info("=" * 60)

    results = []
    for event in MANIPULATION_EVENTS:
        logger.info(f"\nEvaluating: {event['symbol']} — {event['type']}")
        r = evaluate_case(event)
        results.append(r)
        if r:
            m = r["layer_metrics"]["ensemble"]
            logger.info(f"  Ensemble  F1={m['f1']:.3f}  AUC={m['auc_roc']:.3f}  "
                        f"{'DETECTED' if m['detected'] else 'MISSED'}  lag={m['lag_days']}d")

    # ── Summary ───────────────────────────────────────────────────────
    valid = [r for r in results if r]
    logger.info("\n" + "=" * 60)
    logger.info("ABLATION STUDY RESULTS")
    logger.info("=" * 60)

    for name in ["rules_only", "if_only", "rf_only", "lstm_only", "ensemble"]:
        vals  = [r["layer_metrics"][name] for r in valid]
        avg_f1  = np.mean([v["f1"]      for v in vals])
        avg_auc = np.mean([v["auc_roc"] for v in vals])
        detected = sum(1 for v in vals if v["detected"])
        logger.info(f"  {name:<15}  F1={avg_f1:.3f}  AUC={avg_auc:.3f}  "
                    f"Detected={detected}/{len(valid)}")

    print_latex_table(results)

    # ── Save JSON report ──────────────────────────────────────────────
    report = {
        "generated_at": pd.Timestamp.now().isoformat(),
        "n_cases":      len(valid),
        "threshold":    ALERT_THRESHOLD,
        "cases":        [r for r in results if r],
    }
    out_path = REPORTS_DIR / "evaluation_report.json"
    with open(out_path, "w") as f:
        json.dump(report, f, indent=2, default=str)
    logger.info(f"\nReport saved: {out_path}")
    logger.info("Use this JSON to populate the paper's Table 3 and Figure 4.")


if __name__ == "__main__":
    main()
