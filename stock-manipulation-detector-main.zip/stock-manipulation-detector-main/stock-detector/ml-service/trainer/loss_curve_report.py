#!/usr/bin/env python3
# ml-service/trainer/loss_curve_report.py
#
# Trains the Vanilla Autoencoder once with early_stopping OFF and a generous
# max_iter, so sklearn's internal loss_curve_ captures the FULL trajectory.
# Prints it to terminal every 10 iterations and saves a plot if matplotlib
# is available.
#
# Run: python trainer/loss_curve_report.py

import sys
import numpy as np
from pathlib import Path
from loguru import logger
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

sys.path.insert(0, str(Path(__file__).parent.parent))
from detector.features import extract_features, FEATURE_NAMES, WINDOW
from trainer.download_data import load_all
from trainer.label_events import label_dataframe

REPORTS_DIR = Path(__file__).parent.parent / "reports"
REPORTS_DIR.mkdir(exist_ok=True)

BOTTLENECK_DIM = 6
MAX_ITER = 150


def build_normal_features():
    all_data = load_all()
    if not all_data:
        logger.error("No data. Run: python trainer/download_data.py first")
        sys.exit(1)
    rows = []
    for symbol, raw_df in all_data.items():
        if raw_df is None or len(raw_df) < WINDOW + 10:
            continue
        df = label_dataframe(raw_df, symbol).sort_index()
        for i in range(WINDOW + 1, len(df)):
            if df.iloc[i]["label"] == 1:
                continue
            hist = [
                {"price": float(df.iloc[j]["close"]), "volume": int(df.iloc[j]["volume"]),
                 "high": float(df.iloc[j].get("high", df.iloc[j]["close"])),
                 "low":  float(df.iloc[j].get("low",  df.iloc[j]["close"]))}
                for j in range(max(0, i - WINDOW - 1), i)
            ]
            row = df.iloc[i]
            feats = extract_features(
                float(row["close"]), int(row["volume"]),
                float(row.get("high", row["close"])),
                float(row.get("low",  row["close"])), hist,
            )
            if feats is not None:
                rows.append(feats.flatten())
    return np.array(rows, dtype=np.float32)


def print_curve(name: str, curve: list):
    logger.info(f"\n{name} loss curve (every 10 iterations):")
    logger.info(f"{'Iter':<8}{'Loss':<12}{'Δ vs prev shown':<18}")
    prev = None
    for i in range(0, len(curve), 10):
        delta = f"{(curve[i]-prev)/prev*100:+.1f}%" if prev is not None else "—"
        logger.info(f"{i+1:<8}{curve[i]:<12.6f}{delta:<18}")
        prev = curve[i]
    logger.info(f"{'Final':<8}{curve[-1]:<12.6f}")


if __name__ == "__main__":
    logger.info("=" * 60)
    logger.info(f"VANILLA AUTOENCODER — FULL LOSS CURVE (max_iter={MAX_ITER})")
    logger.info("=" * 60)

    X = build_normal_features()
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    split = int(len(X_scaled) * 0.85)
    X_train = X_scaled[:split]

    encoder = MLPRegressor(
        hidden_layer_sizes=(16,), activation="tanh", solver="adam",
        alpha=1e-4, learning_rate_init=1e-3, max_iter=MAX_ITER,
        random_state=42, early_stopping=False,
    )
    decoder = MLPRegressor(
        hidden_layer_sizes=(16,), activation="tanh", solver="adam",
        alpha=1e-4, learning_rate_init=1e-3, max_iter=MAX_ITER,
        random_state=42, early_stopping=False,
    )

    pca = PCA(n_components=BOTTLENECK_DIM, random_state=42)
    Z_target = pca.fit_transform(X_train)

    logger.info(f"\nTraining encoder on {len(X_train)} normal rows...")
    encoder.fit(X_train, Z_target)
    print_curve("ENCODER", encoder.loss_curve_)

    Z_actual = encoder.predict(X_train)
    logger.info(f"\nTraining decoder...")
    decoder.fit(Z_actual, X_train)
    print_curve("DECODER", decoder.loss_curve_)

    logger.info(f"\nEncoder converged: {encoder.n_iter_} iters, final loss {encoder.loss_:.6f}")
    logger.info(f"Decoder converged: {decoder.n_iter_} iters, final loss {decoder.loss_:.6f}")

    # Optional plot
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.plot(encoder.loss_curve_, label="Encoder loss")
        ax.plot(decoder.loss_curve_, label="Decoder loss")
        ax.set_xlabel("Iteration")
        ax.set_ylabel("MSE Loss")
        ax.set_title("Vanilla Autoencoder — Training Loss Curve")
        ax.legend()
        ax.grid(alpha=0.3)
        out_path = REPORTS_DIR / "vanilla_ae_loss_curve.png"
        fig.savefig(out_path, dpi=120, bbox_inches="tight")
        logger.info(f"\nPlot saved: {out_path}")
    except ImportError:
        logger.warning("\nmatplotlib not installed — skipping plot (terminal table above is sufficient)")