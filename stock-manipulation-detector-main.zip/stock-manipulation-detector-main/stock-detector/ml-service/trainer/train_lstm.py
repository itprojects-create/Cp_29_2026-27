#!/usr/bin/env python3
# ml-service/trainer/train_lstm.py
#
# Trains the LSTM Autoencoder on normal NSE trading sequences.
# Run AFTER train.py (needs features.py and downloaded data).
#
# Usage:
#   python trainer/train_lstm.py
#
# Output:
#   models/lstm_ae.pt          — trained model weights
#   models/lstm_ae_scaler.pkl  — feature scaler
#   models/lstm_ae_threshold.pkl — reconstruction error threshold (95th pct)

import sys, numpy as np, pandas as pd, joblib
from pathlib import Path
from loguru import logger

sys.path.insert(0, str(Path(__file__).parent.parent))
from detector.features import extract_features, FEATURE_NAMES, WINDOW
from trainer.download_data import load_all
from trainer.label_events import label_dataframe

MODELS_DIR = Path(__file__).parent.parent / "models"
MODELS_DIR.mkdir(exist_ok=True)

SEQ_LEN    = 20    # Sequence length for LSTM
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
from detector.features import FEAT_DIM, FEATURE_NAMES, WINDOW    # Must match len(FEATURE_NAMES)
HIDDEN_DIM = 64
LATENT_DIM = 32
NUM_LAYERS = 2
EPOCHS     = 50
BATCH_SIZE = 64
LR         = 1e-3


def build_sequences(all_data: dict) -> np.ndarray:
    """Build (N, SEQ_LEN, FEAT_DIM) array of NORMAL trading sequences."""
    logger.info("Building training sequences from normal trading data...")
    all_features = []

    for symbol, raw_df in all_data.items():
        if raw_df is None or len(raw_df) < WINDOW + SEQ_LEN + 5:
            continue
        df = label_dataframe(raw_df, symbol).sort_index()

        feature_rows = []
        for i in range(WINDOW + 1, len(df)):
            history = [
                {"price": float(df.iloc[j]["close"]),
                 "volume": int(df.iloc[j]["volume"])}
                for j in range(max(0, i - WINDOW - 1), i)
            ]
            row = df.iloc[i]
            feats = extract_features(
                float(row["close"]), int(row["volume"]),
                float(row.get("high", row["close"])),
                float(row.get("low",  row["close"])),
                history,
            )
            if feats is not None:
                feature_rows.append((feats.flatten(), int(row["label"])))

        # Only NORMAL rows for autoencoder training
        normal_rows = [f for f, lbl in feature_rows if lbl == 0]
        if len(normal_rows) < SEQ_LEN + 1:
            continue

        # Slide a window of SEQ_LEN over the normal rows
        arr = np.array(normal_rows, dtype=np.float32)
        for start in range(len(arr) - SEQ_LEN + 1):
            all_features.append(arr[start:start + SEQ_LEN])

        logger.info(f"  {symbol}: {len(normal_rows)} normal rows → {len(arr)-SEQ_LEN+1} sequences")

    if not all_features:
        raise ValueError("No sequences built. Run download_data.py first.")

    sequences = np.array(all_features, dtype=np.float32)
    logger.info(f"Total sequences: {sequences.shape}")
    return sequences


def train():
    try:
        import torch
        import torch.nn as nn
        from torch.utils.data import DataLoader, TensorDataset
        from sklearn.preprocessing import StandardScaler
    except ImportError:
        logger.error("PyTorch not installed. Run: pip install torch")
        sys.exit(1)

    logger.info("=" * 60)
    logger.info("LSTM AUTOENCODER TRAINING")
    logger.info("=" * 60)

    # ── Load data ─────────────────────────────────────────────────────
    all_data = load_all()
    if not all_data:
        logger.error("No data. Run: python trainer/download_data.py")
        sys.exit(1)

    sequences = build_sequences(all_data)   # (N, SEQ_LEN, FEAT_DIM)
    N = len(sequences)

    # ── Scale features ────────────────────────────────────────────────
    scaler = StandardScaler()
    flat   = sequences.reshape(-1, FEAT_DIM)
    scaler.fit(flat)
    seq_scaled = scaler.transform(flat).reshape(N, SEQ_LEN, FEAT_DIM)

    # ── Build model ───────────────────────────────────────────────────
    class Encoder(nn.Module):
        def __init__(self):
            super().__init__()
            self.lstm = nn.LSTM(FEAT_DIM, HIDDEN_DIM, NUM_LAYERS,
                                batch_first=True, dropout=0.2)
            self.fc   = nn.Linear(HIDDEN_DIM, LATENT_DIM)
        def forward(self, x):
            _, (h, _) = self.lstm(x)
            return self.fc(h[-1])

    class Decoder(nn.Module):
        def __init__(self):
            super().__init__()
            self.fc   = nn.Linear(LATENT_DIM, HIDDEN_DIM)
            self.lstm = nn.LSTM(HIDDEN_DIM, HIDDEN_DIM, NUM_LAYERS,
                                batch_first=True, dropout=0.2)
            self.out  = nn.Linear(HIDDEN_DIM, FEAT_DIM)
        def forward(self, z):
            h   = self.fc(z).unsqueeze(1).repeat(1, SEQ_LEN, 1)
            out, _ = self.lstm(h)
            return self.out(out)

    class LSTMAE(nn.Module):
        def __init__(self):
            super().__init__()
            self.enc = Encoder()
            self.dec = Decoder()
        def forward(self, x):
            z = self.enc(x)
            return self.dec(z), z

    model = LSTMAE()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model  = model.to(device)
    logger.info(f"Training on {device}")

    # Parameter count
    n_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    logger.info(f"Model parameters: {n_params:,}")

    # ── Train ─────────────────────────────────────────────────────────
    X      = torch.FloatTensor(seq_scaled)
    loader = DataLoader(TensorDataset(X), batch_size=BATCH_SIZE, shuffle=True)
    optim  = torch.optim.Adam(model.parameters(), lr=LR, weight_decay=1e-5)
    sched  = torch.optim.lr_scheduler.CosineAnnealingLR(optim, EPOCHS)
    crit   = nn.MSELoss()

    best_loss = float("inf")
    for epoch in range(1, EPOCHS + 1):
        model.train()
        epoch_loss = 0.0
        for (batch,) in loader:
            batch = batch.to(device)
            optim.zero_grad()
            recon, _ = model(batch)
            loss = crit(recon, batch)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optim.step()
            epoch_loss += loss.item() * len(batch)
        sched.step()
        avg = epoch_loss / N
        if epoch % 10 == 0 or epoch == 1:
            logger.info(f"  Epoch {epoch:>3}/{EPOCHS}  loss={avg:.6f}  lr={sched.get_last_lr()[0]:.6f}")
        if avg < best_loss:
            best_loss = avg
            torch.save(model.state_dict(), MODELS_DIR / "lstm_ae_best.pt")

    # Load best
    model.load_state_dict(torch.load(MODELS_DIR / "lstm_ae_best.pt",
                                      map_location=device, weights_only=True))

    # ── Compute reconstruction error threshold ────────────────────────
    model.eval()
    all_errors = []
    with torch.no_grad():
        for (batch,) in DataLoader(TensorDataset(X), batch_size=256):
            batch = batch.to(device)
            recon, _ = model(batch)
            errors = torch.mean((batch - recon) ** 2, dim=(1, 2))
            all_errors.extend(errors.cpu().numpy().tolist())

    errors_arr = np.array(all_errors)
    threshold  = float(np.percentile(errors_arr, 95))

    logger.info(f"\nReconstruction error stats:")
    logger.info(f"  Mean:   {errors_arr.mean():.6f}")
    logger.info(f"  Std:    {errors_arr.std():.6f}")
    logger.info(f"  95th%:  {threshold:.6f}  ← anomaly threshold")

    # ── Save ──────────────────────────────────────────────────────────
    model.eval()
    model = model.cpu()
    torch.save(model.state_dict(), MODELS_DIR / "lstm_ae.pt")
    joblib.dump(scaler,    MODELS_DIR / "lstm_ae_scaler.pkl")
    joblib.dump(threshold, MODELS_DIR / "lstm_ae_threshold.pkl")

    logger.info(f"\n✅ LSTM Autoencoder saved:")
    logger.info(f"   models/lstm_ae.pt          ({n_params:,} params)")
    logger.info(f"   models/lstm_ae_scaler.pkl")
    logger.info(f"   models/lstm_ae_threshold.pkl (threshold={threshold:.6f})")
    logger.info("\nNext: python trainer/evaluate.py")
    return model, scaler, threshold


if __name__ == "__main__":
    train()
