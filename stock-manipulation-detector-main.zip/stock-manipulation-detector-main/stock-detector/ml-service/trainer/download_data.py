# ml-service/trainer/download_data.py
#
# ═══════════════════════════════════════════════════════════════════════
# TRAINING DATA — WHAT WE HAVE, WHAT WE DON'T, WHY IT'S FINE
# ═══════════════════════════════════════════════════════════════════════
#
# WHAT WE DOWNLOAD:
#   Source 1 — yfinance (.NS suffix)
#     Daily OHLCV per stock, 2019 to today. Free, no key.
#     ~1200 trading days × 15 stocks = ~18,000 rows.
#
#   Source 2 — NSE Bhavcopy (official NSE end-of-day report)
#     NSE publishes a CSV every trading day at 6pm IST with OHLCV
#     for ALL listed stocks. Free, direct from NSE servers.
#     More reliable than yfinance for Indian stocks.
#
# WHAT WE DON'T HAVE (and why it's okay):
#   ✗ Tick-by-tick historical data
#     Costs money (TickData, etc.). Not needed.
#     The model trains on DAILY features. Breeze gives live ticks.
#     Training granularity ≠ inference granularity — that's fine.
#
#   ✗ Intraday minute bars
#     Breeze gives 3yr history but only while API is running.
#     We accumulate this once deployed.
#
#   ✗ Labeled manipulation data beyond what SEBI published
#     SEBI doesn't publish a labeled dataset. We use 7 confirmed
#     enforcement cases from public SEBI orders.
#
#   ✗ News corpus for ML training
#     We don't train on news at all. LangChain fetches live news
#     at inference time when analyst triggers AI Analyze.
#
# HOW TRAINING WORKS ON DAILY DATA:
#   1. Download 5yr daily bars for 15 NSE stocks
#   2. Compute 14 features per day (rolling 20-day window)
#   3. Label 7 confirmed SEBI manipulation windows
#   4. Train Isolation Forest on NORMAL rows only
#      → learns what a normal NSE trading day looks like
#   5. Train Random Forest on all rows with manipulation labels
#      → learns specific patterns from confirmed cases
#   6. At live inference: Breeze tick arrives → compute same 14
#      features from rolling 20-tick window → score with models
#
# ═══════════════════════════════════════════════════════════════════════

import os, io, time, zipfile, requests, contextlib
import pandas as pd
import yfinance as yf
from pathlib import Path
from datetime import date, timedelta
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from loguru import logger

DATA_DIR = Path(__file__).parent.parent / "data"
DATA_DIR.mkdir(exist_ok=True)

# NSE symbols — yfinance uses .NS suffix
NSE_SYMBOLS = {
    "RELIANCE":   "RELIANCE.NS",
    "HDFCBANK":   "HDFCBANK.NS",
    "INFY":       "INFY.NS",
    "TCS":        "TCS.NS",
    "ICICIBANK":  "ICICIBANK.NS",
    "KOTAKBANK":  "KOTAKBANK.NS",
    "SBIN":       "SBIN.NS",
    "AXISBANK":   "AXISBANK.NS",
    "BAJFINANCE": "BAJFINANCE.NS",
    "WIPRO":      "WIPRO.NS",
    "ZOMATO":     "ZOMATO.NS",
    "NYKAA":      "NYKAA.NS",
    "PAYTM":      "PAYTM.NS",
    "ADANIENT":   "ADANIENT.NS",
    "YESBANK":    "YESBANK.NS",
}

START_DATE = "2019-01-01"
END_DATE   = date.today().strftime("%Y-%m-%d")

NSE_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://www.nseindia.com",
    "Accept": "*/*",
}


# ── Source 1: yfinance ────────────────────────────────────────────────────

def _safe_yfinance_download(ticker: str, start: str, end: str):
    """Download Yahoo history and let yfinance errors print normally."""
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer), contextlib.redirect_stderr(buffer):
        return yf.download(
            ticker,
            start=start,
            end=end,
            auto_adjust=True,
            progress=False,
        )

def download_yfinance(force=False):
    logger.info(f"[yfinance] {len(NSE_SYMBOLS)} symbols ({START_DATE}→{END_DATE})")
    results = {}

    for sym, ticker in NSE_SYMBOLS.items():
        path = DATA_DIR / f"yf_{sym}.csv"
        if path.exists() and not force:
            df = pd.read_csv(path, index_col="Date", parse_dates=True)
            results[sym] = df
            logger.info(f"  {sym}: cached ({len(df)} days)")
            continue

        try:
            df = _safe_yfinance_download(ticker, START_DATE, END_DATE)
            if df.empty:
                continue
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = [c[0] for c in df.columns]
            df.columns = [c.lower() for c in df.columns]
            df.index.name = "Date"
            df["symbol"] = sym
            df.to_csv(path)
            results[sym] = df
            logger.info(f"  {sym}: {len(df)} days downloaded")
        except Exception as e:
            logger.debug(f"  {sym}: {e}")
        time.sleep(0.5)
    return results


# ── Source 2: NSE Bhavcopy ────────────────────────────────────────────────

def _fetch_bhavcopy_day(d: date):
    """Try multiple NSE bhavcopy URL patterns for a single date."""
    dmy = d.strftime("%d%b%Y").upper()     # 17JAN2024
    ymd = d.strftime("%Y%m%d")             # 20240117
    mon = d.strftime("%b").upper()          # JAN

    urls = [
        f"https://nsearchives.nseindia.com/content/historical/EQUITIES/{d.year}/{mon}/cm{dmy}bhav.csv.zip",
        f"https://nsearchives.nseindia.com/content/cm/BhavCopy_NSE_CM_0_0_0_{ymd}_F_0000.csv.zip",
        f"https://www1.nseindia.com/content/historical/EQUITIES/{d.year}/{mon}/cm{dmy}bhav.csv.zip",
    ]

    session = requests.Session()
    retry = Retry(
        total=3,
        connect=3,
        read=3,
        backoff_factor=0.6,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET"]),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    try:
        session.get("https://www.nseindia.com", headers=NSE_HEADERS, timeout=6)
    except Exception:
        pass

    for url in urls:
        try:
            r = session.get(url, headers=NSE_HEADERS, timeout=15)
            if r.status_code != 200:
                continue
            raw = r.content
            if url.endswith(".zip") or raw[:2] == b"PK":
                with zipfile.ZipFile(io.BytesIO(raw)) as zf:
                    with zf.open(zf.namelist()[0]) as f:
                        df = pd.read_csv(f)
            else:
                df = pd.read_csv(io.StringIO(raw.decode("utf-8", errors="ignore")))

            df.columns = [c.strip().upper() for c in df.columns]
            if "SERIES" in df.columns:
                df = df[df["SERIES"].str.strip() == "EQ"]
            rename = {"SYMBOL":"symbol","OPEN":"open","HIGH":"high","LOW":"low",
                      "CLOSE":"close","TOTTRDQTY":"volume","PREVCLOSE":"prev_close"}
            df = df.rename(columns={k:v for k,v in rename.items() if k in df.columns})
            needed = ["symbol","open","high","low","close","volume"]
            if not all(c in df.columns for c in needed):
                continue
            df["date"] = str(d)
            return df[needed + ["date"]]
        except Exception:
            continue
    return None


def download_bhavcopy_range(start: date, end: date, symbols=None):
    """Download NSE bhavcopy for a date range, save per-symbol CSVs."""
    logger.info(f"[bhavcopy] {start} → {end}")
    all_rows, downloaded, skipped = [], 0, 0
    cur = start

    while cur <= end:
        if cur.weekday() >= 5:
            cur += timedelta(days=1)
            continue

        cache = DATA_DIR / f"bhav_raw_{cur.strftime('%Y%m%d')}.csv"
        if cache.exists():
            try:
                df = pd.read_csv(cache)
                if symbols:
                    df = df[df["symbol"].isin(symbols)]
                all_rows.append(df)
                downloaded += 1
                cur += timedelta(days=1)
                continue
            except Exception:
                pass

        df = _fetch_bhavcopy_day(cur)
        if df is None:
            skipped += 1
        else:
            df.to_csv(cache, index=False)
            if symbols:
                df = df[df["symbol"].isin(symbols)]
            all_rows.append(df)
            downloaded += 1
            logger.info(f"  {cur}: {len(df)} rows")

        time.sleep(1.2)
        cur += timedelta(days=1)

    logger.info(f"[bhavcopy] {downloaded} days downloaded, {skipped} skipped")

    if not all_rows:
        return pd.DataFrame()

    combined = pd.concat(all_rows, ignore_index=True)
    for sym in (symbols or combined["symbol"].unique()):
        s = combined[combined["symbol"] == sym].copy().sort_values("date")
        if not s.empty:
            s.to_csv(DATA_DIR / f"bhav_{sym}.csv", index=False)
    return combined


# ── Load helpers ──────────────────────────────────────────────────────────

def load_symbol(symbol: str) -> pd.DataFrame:
    """
    Load all available data for a symbol.
    Priority: Angel One daily > bhavcopy > yfinance
    Returns DataFrame with DatetimeIndex and columns: open,high,low,close,volume,symbol
    """
    # Priority 1: Angel One historical (most accurate, downloaded via angelone_forwarder.py)
    angel_path = DATA_DIR / f"angel_{symbol}_ONE_DAY.csv"
    if angel_path.exists():
        df = pd.read_csv(angel_path)
        df["datetime"] = pd.to_datetime(df["datetime"])
        df = df.set_index("datetime").sort_index()
        df.index.name = "date"
        df["symbol"] = symbol
        for c in ["open","high","low","close","volume"]:
            if c in df.columns:
                df[c] = pd.to_numeric(df[c], errors="coerce")
        return df.dropna(subset=["close","volume"])
    bhav = DATA_DIR / f"bhav_{symbol}.csv"
    yf_  = DATA_DIR / f"yf_{symbol}.csv"

    if bhav.exists():
        df = pd.read_csv(bhav)
        df["date"] = pd.to_datetime(df["date"])
        df = df.set_index("date").sort_index()
        df["symbol"] = symbol
        # Make sure numeric columns are float
        for c in ["open","high","low","close","volume"]:
            if c in df.columns:
                df[c] = pd.to_numeric(df[c], errors="coerce")
        return df.dropna(subset=["close","volume"])

    if yf_.exists():
        df = pd.read_csv(yf_, index_col="Date", parse_dates=True)
        df.index.name = "date"
        df["symbol"] = symbol
        for c in ["open","high","low","close","volume"]:
            if c in df.columns:
                df[c] = pd.to_numeric(df[c], errors="coerce")
        return df.dropna(subset=["close","volume"]).sort_index()

    raise FileNotFoundError(
        f"No data for {symbol}. Run: python trainer/download_data.py"
    )


def load_all() -> dict:
    """Load all symbols that have data files."""
    out = {}
    for sym in NSE_SYMBOLS:
        try:
            out[sym] = load_symbol(sym)
        except FileNotFoundError:
            logger.warning(f"Missing: {sym}")
    return out


# ── Main ──────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    logger.info("=" * 60)
    logger.info("NSE DATA DOWNLOADER")
    logger.info("=" * 60)

    # 1. yfinance — best effort first, but keep failures quiet
    download_yfinance()

    # 2. NSE Bhavcopy — official source
    logger.info("\nDownloading NSE Bhavcopy (last 2 years)...")
    download_bhavcopy_range(
        start=date.today() - timedelta(days=730),
        end=date.today() - timedelta(days=1),
        symbols=list(NSE_SYMBOLS.keys()),
    )

    # 3. Summary
    logger.info("\n" + "=" * 60)
    logger.info("SUMMARY")
    logger.info("=" * 60)
    for sym in NSE_SYMBOLS:
        b = DATA_DIR / f"bhav_{sym}.csv"
        y = DATA_DIR / f"yf_{sym}.csv"
        br = len(pd.read_csv(b)) if b.exists() else 0
        yr = len(pd.read_csv(y)) if y.exists() else 0
        status = "✅" if max(br, yr) > 200 else "⚠️"
        logger.info(f"  {status} {sym:<12} bhavcopy:{br:>4}d  yfinance:{yr:>4}d")

    logger.info("\nNext: python trainer/train.py")
