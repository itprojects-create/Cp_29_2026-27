#!/usr/bin/env python3
# ml-service/trainer/threshold_sweep_proof.py
#
# Generates concrete, self-produced proof of the claim:
#   "Changing the alert threshold does NOT affect the model or AUC-ROC,
#    but DOES change Precision/Recall/F1/alert count."
#
# Sweeps THRESHOLD_MEDIUM across a wide range using the ALREADY-TRAINED
# ensemble (no retraining happens anywhere in this script). For each
# threshold value, recomputes Precision/Recall/F1/alert-count from the
# SAME underlying continuous ensemble scores, and shows AUC is identical
# at every row because AUC never depends on where you cut the line.
#
# Run: python trainer/threshold_sweep_proof.py
# Output: printed table + reports/threshold_sweep_proof.json

import sys, json
import numpy as np
from pathlib import Path
from loguru import logger
from sklearn.metrics import (precision_score, recall_score, f1_score, roc_auc_score)

sys.path.insert(0, str(Path(__file__).parent.parent))
from detector.features           import extract_features, FEATURE_NAMES, WINDOW
from detector.zscore_rules       import detect_zscore
from detector.isolation_forest   import detector as if_detector
from detector.collaborative_filter import cf_filter
from detector.ensemble           import compute_ensemble_score
from trainer.download_data       import load_all
from trainer.label_events        import label_dataframe, MANIPULATION_EVENTS

REPORTS_DIR = Path(__file__).parent.parent / "reports"
REPORTS_DIR.mkdir(exist_ok=True)

# The sweep — deliberately wide, including your old (0.55) and new (0.65) MEDIUM values
THRESHOLDS_TO_TEST = [0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90]


def score_all_data():
    """
    Run the SAME trained ensemble across all historical data ONCE,
    collecting the raw continuous ensemble_score for every row.
    This is computed exactly once — proving every threshold below
    is applied to the identical set of underlying scores.
    """
    logger.info("Scoring all historical data through the trained ensemble (once)...")
    all_data = load_all()
    if not all_data:
        logger.error("No data. Run: python trainer/download_data.py first")
        sys.exit(1)

    y_true, y_scores = [], []

    for symbol, raw_df in all_data.items():
        if raw_df is None or len(raw_df) < WINDOW + 10:
            continue
        df = label_dataframe(raw_df, symbol).sort_index()
        rows = df.to_dict("records")

        for i in range(WINDOW + 1, len(rows)):
            hist = [
                {"price": float(rows[j]["close"]), "volume": int(rows[j]["volume"]),
                 "high": float(rows[j].get("high", rows[j]["close"])),
                 "low":  float(rows[j].get("low",  rows[j]["close"]))}
                for j in range(max(0, i - WINDOW - 1), i)
            ]
            row = rows[i]
            feats = extract_features(
                float(row["close"]), int(row["volume"]),
                float(row.get("high", row["close"])),
                float(row.get("low",  row["close"])), hist,
            )
            if feats is None:
                continue

            fd = {n: float(feats.flatten()[k]) for k, n in enumerate(FEATURE_NAMES)}
            rule_res   = detect_zscore(fd, symbol)
            rule_score = rule_res["rule_score"] if rule_res else 0.0
            if_score   = if_detector.score(feats)
            cf_res     = cf_filter.compute_cf_score(symbol, if_score)

            # NOTE: compute_ensemble_score is called with identical inputs
            # every single time in this script — the continuous score
            # produced here NEVER changes across the threshold sweep below.
            ens = compute_ensemble_score(if_score, rule_score, symbol, feats,
                                          None, cf_res)

            y_true.append(int(row["label"]))
            y_scores.append(ens["ensemble_score"])

    y_true   = np.array(y_true)
    y_scores = np.array(y_scores)
    logger.info(f"Scored {len(y_true)} rows | Normal={sum(y_true==0)} | Manipulation={sum(y_true==1)}")
    return y_true, y_scores


def run_sweep(y_true: np.ndarray, y_scores: np.ndarray):
    logger.info("\n" + "=" * 78)
    logger.info("THRESHOLD SWEEP — same underlying scores, only the cutoff moves")
    logger.info("=" * 78)

    # AUC computed ONCE, from the raw scores — never touched by threshold choice
    try:
        auc_fixed = float(roc_auc_score(y_true, y_scores))
    except Exception:
        auc_fixed = 0.0

    logger.info(f"\nAUC-ROC (computed once, threshold-independent): {auc_fixed:.4f}")
    logger.info("Watch this exact number repeat unchanged on every row below.\n")

    header = f"{'Threshold':<12}{'Alerts Fired':<14}{'Precision':<11}{'Recall':<9}{'F1':<8}{'AUC (same every row)'}"
    logger.info(header)
    logger.info("-" * len(header))

    results = []
    for t in THRESHOLDS_TO_TEST:
        pred = (y_scores >= t).astype(int)
        prec = precision_score(y_true, pred, zero_division=0)
        rec  = recall_score(y_true, pred, zero_division=0)
        f1   = f1_score(y_true, pred, zero_division=0)
        n_alerts = int(pred.sum())

        marker = ""
        if abs(t - 0.55) < 1e-9: marker = "  ← OLD THRESHOLD_MEDIUM"
        if abs(t - 0.65) < 1e-9: marker = "  ← NEW THRESHOLD_MEDIUM"

        logger.info(
            f"{t:<12.2f}{n_alerts:<14}{prec:<11.4f}{rec:<9.4f}{f1:<8.4f}{auc_fixed:.4f}{marker}"
        )
        results.append({
            "threshold": t, "alerts_fired": n_alerts,
            "precision": round(prec, 4), "recall": round(rec, 4),
            "f1": round(f1, 4), "auc_roc": round(auc_fixed, 4),
        })

    logger.info("\n" + "=" * 78)
    logger.info("CONCLUSION")
    logger.info("=" * 78)
    logger.info(f"AUC-ROC identical across all {len(THRESHOLDS_TO_TEST)} thresholds: {auc_fixed:.4f}")
    logger.info("This is direct, self-generated proof that:")
    logger.info("  1. No retraining occurred — same model, same scores, every row")
    logger.info("  2. AUC-ROC is mathematically threshold-independent (Fawcett, 2006)")
    logger.info("  3. Precision/Recall/F1/alert-count DO change — this is the expected")
    logger.info("     operating-point tradeoff (Provost & Fawcett 2001; He & Garcia 2009)")

    old_row = next(r for r in results if abs(r["threshold"] - 0.55) < 1e-9)
    new_row = next(r for r in results if abs(r["threshold"] - 0.65) < 1e-9)
    logger.info(f"\nYour specific change (0.55 → 0.65):")
    logger.info(f"  Alerts fired:  {old_row['alerts_fired']} → {new_row['alerts_fired']}")
    logger.info(f"  Precision:     {old_row['precision']:.4f} → {new_row['precision']:.4f}")
    logger.info(f"  Recall:        {old_row['recall']:.4f} → {new_row['recall']:.4f}")
    logger.info(f"  F1:            {old_row['f1']:.4f} → {new_row['f1']:.4f}")
    logger.info(f"  AUC-ROC:       {old_row['auc_roc']:.4f} → {new_row['auc_roc']:.4f}  (UNCHANGED)")

    return results


if __name__ == "__main__":
    y_true, y_scores = score_all_data()
    results = run_sweep(y_true, y_scores)

    out_path = REPORTS_DIR / "threshold_sweep_proof.json"
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2)
    logger.info(f"\nSaved: {out_path}")
    logger.info("Screenshot the terminal table above — this is your proof artifact.")