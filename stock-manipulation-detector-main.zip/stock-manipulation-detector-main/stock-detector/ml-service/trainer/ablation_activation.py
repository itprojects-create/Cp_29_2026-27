#!/usr/bin/env python3
# ml-service/trainer/ablation_activation.py
#
# Controlled ablation: compares activation functions (tanh, relu, logistic)
# on the Vanilla Autoencoder. Answers the exact defense question:
# "What is the score with X activation vs without it?"
#
# Trains 3 identical autoencoders (same architecture, same data, same seed)
# differing ONLY in activation function. Reports:
#   - Final training loss (encoder + decoder)
#   - Reconstruction error separation (normal vs manipulation days)
#   - Detection F1/AUC on the 10 SEBI cases using each variant
#
# Run: python trainer/ablation_activation.py
# Takes ~3-5 minutes (trains 3 small MLP autoencoders)
 
import sys, json, numpy as np
from pathlib import Path
from loguru import logger
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import roc_auc_score, f1_score, precision_score, recall_score
 
sys.path.insert(0, str(Path(__file__).parent.parent))
from detector.features import extract_features, FEATURE_NAMES, FEAT_DIM, WINDOW
from trainer.download_data import load_all
from trainer.label_events import label_dataframe
 
REPORTS_DIR = Path(__file__).parent.parent / "reports"
REPORTS_DIR.mkdir(exist_ok=True)
 
BOTTLENECK_DIM = 6
ACTIVATIONS = ["tanh", "relu", "logistic"]
 
 
def build_dataset():
    """Build feature matrix with labels (reuse same logic as train_autoencoder.py)."""
    logger.info("Loading data and building feature matrix...")
    all_data = load_all()
    if not all_data:
        logger.error("No data. Run: python trainer/download_data.py first")
        sys.exit(1)
 
    rows, labels = [], []
    for symbol, raw_df in all_data.items():
        if raw_df is None or len(raw_df) < WINDOW + 10:
            continue
        df = label_dataframe(raw_df, symbol).sort_index()
        for i in range(WINDOW + 1, len(df)):
            hist = [
                {"price": float(df.iloc[j]["close"]), "volume": int(df.iloc[j]["volume"]),
                 "high": float(df.iloc[j].get("high", df.iloc[j]["close"])),
                 "low":  float(df.iloc[j].get("low",  df.iloc[j]["close"]))}
                for j in range(max(0, i - WINDOW - 1), i)
            ]
            row = df.iloc[i]
            feats = extract_features(
                float(row["close"]), int(row["volume"]),
                float(row.get("high", row["close"])),
                float(row.get("low",  row["close"])), hist,
            )
            if feats is not None:
                rows.append(feats.flatten())
                labels.append(int(row["label"]))
 
    X = np.array(rows, dtype=np.float32)
    y = np.array(labels)
    logger.info(f"Dataset: {len(X)} rows | Normal={sum(y==0)} | Manipulation={sum(y==1)}")
    return X, y
 
 
def train_variant(activation: str, X_train, X_val):
    """Train one encoder+decoder pair with the given activation. Returns model + metrics."""
    encoder = MLPRegressor(
        hidden_layer_sizes=(16,), activation=activation, solver="adam",
        alpha=1e-4, learning_rate_init=1e-3, max_iter=200, random_state=42,
        early_stopping=True, validation_fraction=0.1, n_iter_no_change=15,
    )
    decoder = MLPRegressor(
        hidden_layer_sizes=(16,), activation=activation, solver="adam",
        alpha=1e-4, learning_rate_init=1e-3, max_iter=300, random_state=42,
        early_stopping=True, validation_fraction=0.1, n_iter_no_change=15,
    )
 
    pca = PCA(n_components=BOTTLENECK_DIM, random_state=42)
    Z_train_target = pca.fit_transform(X_train)
    encoder.fit(X_train, Z_train_target)
    Z_train_actual = encoder.predict(X_train)
    decoder.fit(Z_train_actual, X_train)
 
    Z_val = encoder.predict(X_val)
    X_recon = decoder.predict(Z_val)
    val_errors = np.mean((X_val - X_recon) ** 2, axis=1)
 
    return {
        "encoder": encoder, "decoder": decoder,
        "encoder_final_loss": float(encoder.loss_),
        "decoder_final_loss": float(decoder.loss_),
        "encoder_n_iter": int(encoder.n_iter_),
        "decoder_n_iter": int(decoder.n_iter_),
        "val_errors": val_errors,
    }
 
 
def run_ablation():
    logger.info("=" * 60)
    logger.info("ACTIVATION FUNCTION ABLATION — Vanilla Autoencoder")
    logger.info("=" * 60)
 
    X, y = build_dataset()
    scaler = StandardScaler()
    normal_idx = y == 0
    X_scaled_all = scaler.fit_transform(X)
 
    # Train/val split on normal data only (85/15, time-ordered)
    X_normal = X_scaled_all[normal_idx]
    split = int(len(X_normal) * 0.85)
    X_train, X_val = X_normal[:split], X_normal[split:]
 
    results = {}
    for act in ACTIVATIONS:
        logger.info(f"\n--- Training with activation='{act}' ---")
        r = train_variant(act, X_train, X_val)
        threshold = float(np.percentile(r["val_errors"], 95))
 
        # Score ALL data (normal + manipulation) with this variant
        Z_all = r["encoder"].predict(X_scaled_all)
        X_recon_all = r["decoder"].predict(Z_all)
        all_errors = np.mean((X_scaled_all - X_recon_all) ** 2, axis=1)
        anomaly_scores = np.clip(all_errors / (threshold + 1e-9), 0, 1)
 
        pred = (anomaly_scores > 0.55).astype(int)
        precision = precision_score(y, pred, zero_division=0)
        recall    = recall_score(y, pred, zero_division=0)
        f1        = f1_score(y, pred, zero_division=0)
        try:    auc = roc_auc_score(y, anomaly_scores)
        except: auc = 0.0
 
        normal_mean_score = float(anomaly_scores[y == 0].mean())
        manip_mean_score  = float(anomaly_scores[y == 1].mean())
        separation = manip_mean_score / (normal_mean_score + 1e-9)
 
        results[act] = {
            "encoder_final_loss": r["encoder_final_loss"],
            "decoder_final_loss": r["decoder_final_loss"],
            "encoder_n_iter": r["encoder_n_iter"],
            "decoder_n_iter": r["decoder_n_iter"],
            "threshold": threshold,
            "precision": round(precision, 4),
            "recall": round(recall, 4),
            "f1": round(f1, 4),
            "auc_roc": round(auc, 4),
            "normal_mean_score": round(normal_mean_score, 4),
            "manip_mean_score": round(manip_mean_score, 4),
            "separation_ratio": round(separation, 3),
        }
 
        logger.info(f"  Encoder loss: {r['encoder_final_loss']:.6f} ({r['encoder_n_iter']} iters)")
        logger.info(f"  Decoder loss: {r['decoder_final_loss']:.6f} ({r['decoder_n_iter']} iters)")
        logger.info(f"  F1={f1:.3f}  AUC={auc:.3f}  Precision={precision:.3f}  Recall={recall:.3f}")
        logger.info(f"  Separation ratio (manip/normal score): {separation:.2f}x")
 
    # ── Summary table ──────────────────────────────────────────────────
    logger.info("\n" + "=" * 70)
    logger.info("ABLATION SUMMARY — activation function comparison")
    logger.info("=" * 70)
    logger.info(f"{'Activation':<12}{'Enc Loss':<12}{'Dec Loss':<12}{'F1':<8}{'AUC':<8}{'Separation':<12}")
    for act, r in results.items():
        logger.info(
            f"{act:<12}{r['encoder_final_loss']:<12.5f}{r['decoder_final_loss']:<12.5f}"
            f"{r['f1']:<8.3f}{r['auc_roc']:<8.3f}{r['separation_ratio']:<12.2f}"
        )
 
    best_f1 = max(results, key=lambda k: results[k]["f1"])
    best_auc = max(results, key=lambda k: results[k]["auc_roc"])
    logger.info(f"\nBest F1: {best_f1} ({results[best_f1]['f1']:.3f})")
    logger.info(f"Best AUC: {best_auc} ({results[best_auc]['auc_roc']:.3f})")
 
    out_path = REPORTS_DIR / "activation_ablation.json"
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2)
    logger.info(f"\nSaved: {out_path}")
    logger.info("Use this table directly in your paper/defense as the activation ablation.")
 
    return results
 
 
if __name__ == "__main__":
    run_ablation()
 