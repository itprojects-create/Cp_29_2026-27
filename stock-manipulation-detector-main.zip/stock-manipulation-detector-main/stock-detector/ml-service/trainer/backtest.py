# ml-service/trainer/backtest.py
# Backtests the trained models on confirmed SEBI manipulation events.
# Answers: would the model have detected these real manipulations?
# Run: python trainer/backtest.py

import sys
import numpy as np
import pandas as pd
import joblib
from pathlib import Path
from loguru import logger

sys.path.insert(0, str(Path(__file__).parent.parent))
from detector.features import extract_features, FEATURE_NAMES, WINDOW
from detector.ensemble import compute_ensemble_score
from trainer.download_data import load_symbol
from trainer.label_events import MANIPULATION_EVENTS

MODELS_DIR = Path(__file__).parent.parent / "models"


def load_models():
    """Load trained models. Returns None pair if not trained yet."""
    if_path = MODELS_DIR / "isolation_forest.pkl"
    if_s_path = MODELS_DIR / "if_scaler.pkl"

    if not if_path.exists():
        logger.error("Models not found. Run: python trainer/train.py first")
        return None, None

    return (
        joblib.load(if_path),
        joblib.load(if_s_path),
    )


def score_day(if_model, if_scaler, current_price, current_volume,
              current_high, current_low, history):
    """Score a single trading day using the IF model."""
    feats = extract_features(current_price, current_volume,
                              current_high, current_low, history)
    if feats is None:
        return 0.0

    scaled = if_scaler.transform(feats)
    raw = if_model.score_samples(scaled)[0]
    return float(np.clip(1 - (raw + 0.5), 0, 1))


def run_backtest():
    if_model, if_scaler = load_models()
    if if_model is None:
        return

    logger.info("="*60)
    logger.info("BACKTEST — CONFIRMED NSE MANIPULATION EVENTS")
    logger.info("="*60)

    results = []

    for event in MANIPULATION_EVENTS:
        symbol = event["symbol"]
        event_start = pd.Timestamp(event["start"])
        event_end = pd.Timestamp(event["end"])

        try:
            df = load_symbol(symbol)
        except FileNotFoundError:
            logger.warning(f"  {symbol}: no data file — skipping")
            continue

        df = df.sort_index()

        # Score every day in a 45-day window around the event
        window_start = event_start - pd.Timedelta(days=30)
        window_end   = event_end   + pd.Timedelta(days=15)
        window_df    = df[(df.index >= window_start) & (df.index <= window_end)]

        if len(window_df) < WINDOW + 5:
            logger.warning(f"  {symbol}: insufficient data window")
            continue

        daily_scores = []
        for i in range(WINDOW + 1, len(window_df)):
            history_slice = df[df.index < window_df.index[i]].tail(WINDOW)
            history = [
                {"price": float(r["close"]), "volume": int(r["volume"])}
                for _, r in history_slice.iterrows()
            ]
            row = window_df.iloc[i]
            score = score_day(
                if_model, if_scaler,
                float(row["close"]), int(row["volume"]),
                float(row.get("high", row["close"])),
                float(row.get("low", row["close"])),
                history,
            )
            daily_scores.append({
                "date": window_df.index[i],
                "score": score,
                "price": float(row["close"]),
                "in_event": event_start <= window_df.index[i] <= event_end,
            })

        if not daily_scores:
            continue

        scores_df = pd.DataFrame(daily_scores)
        event_scores   = scores_df[scores_df["in_event"]]["score"]
        pre_event_scores = scores_df[~scores_df["in_event"]]["score"]

        ALERT_THRESHOLD = 0.55
        event_alerts = (event_scores > ALERT_THRESHOLD).sum()
        pre_event_fps = (pre_event_scores > ALERT_THRESHOLD).sum()

        # First alert date
        alert_days = scores_df[scores_df["score"] > ALERT_THRESHOLD]
        event_alert_days = alert_days[
            (alert_days["date"] >= event_start) &
            (alert_days["date"] <= event_end)
        ]

        detected = event_alerts > 0
        first_alert = event_alert_days["date"].min() if not event_alert_days.empty else None
        days_before_peak = (event_end - first_alert).days if first_alert else 0
        max_score = float(event_scores.max()) if len(event_scores) > 0 else 0.0
        fp_rate = float(pre_event_fps) / max(len(pre_event_scores), 1)

        status = "✅ DETECTED" if detected else "❌ MISSED"
        logger.info(f"\n  {status} | {symbol} — {event['type']}")
        logger.info(f"    Period: {event['start']} to {event['end']}")
        logger.info(f"    Max anomaly score during event: {max_score:.3f}")
        logger.info(f"    Alert days in event window: {event_alerts}/{len(event_scores)}")
        if first_alert:
            logger.info(f"    First alert: {first_alert.date()} ({days_before_peak}d before peak)")
        logger.info(f"    Pre-event false positive rate: {fp_rate*100:.1f}%")

        results.append({
            "symbol": symbol,
            "type": event["type"],
            "detected": detected,
            "max_score": round(max_score, 3),
            "alert_days": int(event_alerts),
            "total_event_days": len(event_scores),
            "first_alert": str(first_alert.date()) if first_alert else "MISSED",
            "days_before_peak": days_before_peak,
            "pre_event_fp_rate": round(fp_rate * 100, 1),
        })

    # Summary
    if results:
        detected_count = sum(1 for r in results if r["detected"])
        total = len(results)
        avg_fp = np.mean([r["pre_event_fp_rate"] for r in results])
        avg_score = np.mean([r["max_score"] for r in results if r["detected"]])

        logger.info("\n" + "="*60)
        logger.info("BACKTEST SUMMARY")
        logger.info("="*60)
        logger.info(f"  Events detected:      {detected_count}/{total} ({detected_count/total*100:.0f}%)")
        logger.info(f"  Avg max score:        {avg_score:.3f}")
        logger.info(f"  Avg false pos. rate:  {avg_fp:.1f}% (pre-event window)")
        logger.info("\n  Interpretation:")
        logger.info("    Detection rate >60% = acceptable for unsupervised model")
        logger.info("    False positive rate <15% = acceptable for operator review")
        logger.info("    Run train.py again if results are poor (more data needed)")

    return results


if __name__ == "__main__":
    run_backtest()
