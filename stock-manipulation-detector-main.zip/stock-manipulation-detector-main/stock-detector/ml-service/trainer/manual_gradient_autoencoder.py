#!/usr/bin/env python3
# ml-service/trainer/manual_gradient_autoencoder.py
#
# sklearn's MLPRegressor computes gradients internally in compiled code —
# there is no way to inspect them. This script implements the SAME
# architecture (20 -> 6 -> 20, tanh hidden, linear output) from scratch
# in NumPy, with manually-derived backpropagation, so the gradient is a
# real, printed number every epoch.
#
# Architecture:
#   Encoder: X (20) -> tanh(X @ W1 + b1) -> Z (6)
#   Decoder: Z (6)  -> Z @ W2 + b2        -> X_hat (20)   [linear output]
#
# Loss:  L = (1/2N) * sum((X_hat - X)^2) + (alpha/2N) * (||W1||^2 + ||W2||^2)
# Gradient norm: ||concat(dW1, db1, dW2, db2)||_2  — a single scalar
#                summarizing total gradient magnitude at that epoch.
#
# Run: python trainer/manual_gradient_autoencoder.py

import sys
import numpy as np
from pathlib import Path
from loguru import logger
from sklearn.preprocessing import StandardScaler

sys.path.insert(0, str(Path(__file__).parent.parent))
from detector.features import extract_features, FEATURE_NAMES, FEAT_DIM, WINDOW
from trainer.download_data import load_all
from trainer.label_events import label_dataframe

REPORTS_DIR = Path(__file__).parent.parent / "reports"
REPORTS_DIR.mkdir(exist_ok=True)

HIDDEN_DIM = 16
BOTTLENECK_DIM = 6
EPOCHS = 150
LR = 1e-2
ALPHA = 1e-4   # L2 weight decay, matches sklearn's alpha


def build_normal_features():
    all_data = load_all()
    if not all_data:
        logger.error("No data. Run: python trainer/download_data.py first")
        sys.exit(1)
    rows = []
    for symbol, raw_df in all_data.items():
        if raw_df is None or len(raw_df) < WINDOW + 10:
            continue
        df = label_dataframe(raw_df, symbol).sort_index()
        for i in range(WINDOW + 1, len(df)):
            if df.iloc[i]["label"] == 1:
                continue
            hist = [
                {"price": float(df.iloc[j]["close"]), "volume": int(df.iloc[j]["volume"]),
                 "high": float(df.iloc[j].get("high", df.iloc[j]["close"])),
                 "low":  float(df.iloc[j].get("low",  df.iloc[j]["close"]))}
                for j in range(max(0, i - WINDOW - 1), i)
            ]
            row = df.iloc[i]
            feats = extract_features(
                float(row["close"]), int(row["volume"]),
                float(row.get("high", row["close"])),
                float(row.get("low",  row["close"])), hist,
            )
            if feats is not None:
                rows.append(feats.flatten())
    return np.array(rows, dtype=np.float64)


def init_weights(rng):
    """Xavier/Glorot initialization — standard for tanh activations."""
    W1 = rng.normal(0, np.sqrt(1.0 / FEAT_DIM), (FEAT_DIM, HIDDEN_DIM))
    b1 = np.zeros(HIDDEN_DIM)
    W2 = rng.normal(0, np.sqrt(1.0 / HIDDEN_DIM), (HIDDEN_DIM, BOTTLENECK_DIM))
    b2 = np.zeros(BOTTLENECK_DIM)
    W3 = rng.normal(0, np.sqrt(1.0 / BOTTLENECK_DIM), (BOTTLENECK_DIM, HIDDEN_DIM))
    b3 = np.zeros(HIDDEN_DIM)
    W4 = rng.normal(0, np.sqrt(1.0 / HIDDEN_DIM), (HIDDEN_DIM, FEAT_DIM))
    b4 = np.zeros(FEAT_DIM)
    return W1, b1, W2, b2, W3, b3, W4, b4


def forward(X, W1, b1, W2, b2, W3, b3, W4, b4):
    """
    Full forward pass through: 20 -> tanh(16) -> 6 (bottleneck) -> tanh(16) -> 20 (linear out)
    Returns all intermediate activations (needed for manual backprop).
    """
    h1_pre = X @ W1 + b1
    h1 = np.tanh(h1_pre)
    z = h1 @ W2 + b2                    # bottleneck — linear, no activation (preserves magnitude)
    h2_pre = z @ W3 + b3
    h2 = np.tanh(h2_pre)
    x_hat = h2 @ W4 + b4                 # output — linear (unbounded standardized features)
    return h1_pre, h1, z, h2_pre, h2, x_hat


def backward(X, h1_pre, h1, z, h2_pre, h2, x_hat, W2, W3, W4, alpha):
    """
    Manual backpropagation via the chain rule. Every line here is the
    literal derivative of the loss with respect to that layer's weights.
    """
    N = X.shape[0]

    # dL/dx_hat  (derivative of 0.5*MSE)
    d_xhat = (x_hat - X) / N

    # Output layer: x_hat = h2 @ W4 + b4
    dW4 = h2.T @ d_xhat + (alpha / N) * W4
    db4 = d_xhat.sum(axis=0)
    d_h2 = d_xhat @ W4.T

    # tanh derivative: d/dx tanh(x) = 1 - tanh(x)^2
    d_h2_pre = d_h2 * (1 - h2 ** 2)

    # h2_pre = z @ W3 + b3
    dW3 = z.T @ d_h2_pre + (alpha / N) * W3
    db3 = d_h2_pre.sum(axis=0)
    d_z = d_h2_pre @ W3.T

    # Bottleneck: z = h1 @ W2 + b2  (linear, derivative passes straight through)
    dW2 = h1.T @ d_z + (alpha / N) * W2
    db2 = d_z.sum(axis=0)
    d_h1 = d_z @ W2.T

    d_h1_pre = d_h1 * (1 - h1 ** 2)

    # h1_pre = X @ W1 + b1
    dW1 = X.T @ d_h1_pre + (alpha / N) * W1
    db1 = d_h1_pre.sum(axis=0)

    return dW1, db1, dW2, db2, dW3, db3, dW4, db4


def gradient_norm(*grads):
    """L2 norm of ALL gradients concatenated — a single scalar per epoch."""
    flat = np.concatenate([g.flatten() for g in grads])
    return float(np.linalg.norm(flat))


def compute_loss(X, x_hat, W1, W2, W3, W4, alpha):
    N = X.shape[0]
    recon = 0.5 * np.sum((x_hat - X) ** 2) / N
    reg = (alpha / (2 * N)) * (np.sum(W1**2) + np.sum(W2**2) + np.sum(W3**2) + np.sum(W4**2))
    return recon + reg


if __name__ == "__main__":
    logger.info("=" * 70)
    logger.info("MANUAL BACKPROP AUTOENCODER — explicit loss AND gradient per epoch")
    logger.info(f"Architecture: {FEAT_DIM} -> tanh({HIDDEN_DIM}) -> {BOTTLENECK_DIM} "
                f"-> tanh({HIDDEN_DIM}) -> {FEAT_DIM}")
    logger.info("=" * 70)

    X_raw = build_normal_features()
    scaler = StandardScaler()
    X = scaler.fit_transform(X_raw)
    split = int(len(X) * 0.85)
    X_train = X[:split]
    logger.info(f"Training on {len(X_train)} normal rows\n")

    rng = np.random.RandomState(42)
    W1, b1, W2, b2, W3, b3, W4, b4 = init_weights(rng)

    logger.info(f"{'Epoch':<8}{'Loss':<14}{'Gradient Norm':<16}{'Loss Δ':<12}")
    prev_loss = None
    loss_history, grad_history = [], []

    for epoch in range(1, EPOCHS + 1):
        h1_pre, h1, z, h2_pre, h2, x_hat = forward(X_train, W1, b1, W2, b2, W3, b3, W4, b4)
        loss = compute_loss(X_train, x_hat, W1, W2, W3, W4, ALPHA)

        dW1, db1, dW2, db2, dW3, db3, dW4, db4 = backward(
            X_train, h1_pre, h1, z, h2_pre, h2, x_hat, W2, W3, W4, ALPHA
        )
        gnorm = gradient_norm(dW1, db1, dW2, db2, dW3, db3, dW4, db4)

        # Plain gradient descent update
        W1 -= LR * dW1; b1 -= LR * db1
        W2 -= LR * dW2; b2 -= LR * db2
        W3 -= LR * dW3; b3 -= LR * db3
        W4 -= LR * dW4; b4 -= LR * db4

        loss_history.append(loss)
        grad_history.append(gnorm)

        if epoch % 10 == 0 or epoch == 1:
            delta = f"{(loss-prev_loss)/prev_loss*100:+.2f}%" if prev_loss else "—"
            logger.info(f"{epoch:<8}{loss:<14.6f}{gnorm:<16.6f}{delta:<12}")
            prev_loss = loss

    logger.info(f"\nFinal loss: {loss_history[-1]:.6f}")
    logger.info(f"Final gradient norm: {grad_history[-1]:.6f}")
    logger.info(f"Gradient shrank {grad_history[0]/grad_history[-1]:.1f}x from epoch 1 to {EPOCHS}")
    logger.info("(A shrinking gradient norm alongside a shrinking loss is direct,")
    logger.info(" first-principles evidence of genuine convergence — not just a")
    logger.info(" library reporting 'done'.)")

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.5))
        ax1.plot(loss_history); ax1.set_title("Loss per epoch")
        ax1.set_xlabel("Epoch"); ax1.set_ylabel("Loss"); ax1.grid(alpha=0.3)
        ax2.plot(grad_history, color="darkorange"); ax2.set_title("Gradient norm per epoch")
        ax2.set_xlabel("Epoch"); ax2.set_ylabel("||∇L||"); ax2.grid(alpha=0.3)
        out_path = REPORTS_DIR / "manual_loss_and_gradient.png"
        fig.savefig(out_path, dpi=120, bbox_inches="tight")
        logger.info(f"\nPlot saved: {out_path}")
    except ImportError:
        logger.warning("matplotlib not installed — terminal table above is the record")