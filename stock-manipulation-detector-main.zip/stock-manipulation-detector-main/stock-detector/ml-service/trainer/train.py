#!/usr/bin/env python3
# ml-service/trainer/train.py
# Trains Isolation Forest (unsupervised) + Random Forest (supervised).
# Uses 20-feature vectors computed from NSE historical OHLCV data.
# Run: python trainer/train.py

import sys, numpy as np, pandas as pd, joblib
from pathlib import Path
from loguru import logger
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import (classification_report, roc_auc_score,
                              precision_score, recall_score, f1_score)

sys.path.insert(0, str(Path(__file__).parent.parent))
from detector.features   import extract_features, FEATURE_NAMES, FEAT_DIM, WINDOW
from trainer.download_data import load_all
from trainer.label_events  import label_dataframe

MODELS_DIR = Path(__file__).parent.parent / "models"
MODELS_DIR.mkdir(exist_ok=True)


def build_dataset(all_data):
    logger.info(f"Building {FEAT_DIM}-feature dataset...")
    rows = []
    for symbol, raw_df in all_data.items():
        if raw_df is None or len(raw_df) < WINDOW + 10:
            continue
        df = label_dataframe(raw_df, symbol).sort_index()
        for i in range(WINDOW + 1, len(df)):
            hist = [{"price": float(df.iloc[j]["close"]),
                     "volume": int(df.iloc[j]["volume"]),
                     "high": float(df.iloc[j].get("high", df.iloc[j]["close"])),
                     "low":  float(df.iloc[j].get("low",  df.iloc[j]["close"]))}
                    for j in range(max(0, i-WINDOW-1), i)]
            row = df.iloc[i]
            feats = extract_features(
                float(row["close"]), int(row["volume"]),
                float(row.get("high", row["close"])),
                float(row.get("low",  row["close"])),
                hist,
            )
            if feats is None: continue
            d = {n: float(feats.flatten()[k]) for k, n in enumerate(FEATURE_NAMES)}
            d.update({"symbol": symbol, "date": row.name,
                      "label": int(row["label"]),
                      "event_type": row.get("event_type", "NORMAL")})
            rows.append(d)
        logger.info(f"  {symbol}: {len([r for r in rows if r['symbol']==symbol])} rows "
                    f"({df['label'].sum()} manipulation days)")

    ds = pd.DataFrame(rows).dropna(subset=FEATURE_NAMES)
    logger.info(f"\nDataset: {len(ds)} rows | "
                f"Normal={( ds['label']==0).sum()} | "
                f"Manipulation={(ds['label']==1).sum()}")
    return ds


def train_isolation_forest(ds):
    logger.info("\n[1/2] Training Isolation Forest (unsupervised, 20 features)...")
    normal = ds[ds["label"] == 0][FEATURE_NAMES]
    sc = StandardScaler()
    Xn = sc.fit_transform(normal)

    # ── Plateau check: does 200 trees give stable scores? ──────────────
    logger.info("\nChecking score stability across n_estimators (plateau check)...")
    oob_scores = []
    for n in [50, 100, 150, 200, 300]:
        m_test = IsolationForest(n_estimators=n, contamination=0.05, random_state=42)
        m_test.fit(Xn)
        mean_score = m_test.score_samples(Xn).mean()
        oob_scores.append(mean_score)
        logger.info(f"  n_estimators={n:<4}  mean score_samples={mean_score:.6f}")
    logger.info(f"Full curve: {oob_scores}")
    logger.info("(Should plateau by n=200 — later values barely differ from earlier ones)")
    # ─────────────────────────────────────────────────────────────────

    model = IsolationForest(n_estimators=200, contamination=0.05,
                             max_features=FEAT_DIM, random_state=42, n_jobs=-1)
    model.fit(Xn)

    X_all = sc.transform(ds[FEATURE_NAMES])
    raw   = model.score_samples(X_all)
    mn, mx = raw.min(), raw.max()
    scores = 1 - (raw - mn) / (mx - mn + 1e-9)

    y     = ds["label"].values
    pred  = (scores > 0.55).astype(int)
    p = precision_score(y, pred, zero_division=0)
    r = recall_score(y, pred, zero_division=0)
    f = f1_score(y, pred, zero_division=0)
    try:    auc = roc_auc_score(y, scores)
    except: auc = 0.0

    logger.info(f"  Precision={p:.3f}  Recall={r:.3f}  F1={f:.3f}  AUC={auc:.3f}")

    joblib.dump(model, MODELS_DIR / "isolation_forest.pkl")
    joblib.dump(sc,    MODELS_DIR / "if_scaler.pkl")
    logger.info("  ✅ Saved: isolation_forest.pkl + if_scaler.pkl")
    return model, sc


def train_random_forest(ds):
    logger.info("\n[2/2] Training Random Forest (supervised, 10 SEBI cases)...")
    X = ds[FEATURE_NAMES].values
    y = ds["label"].values
    sc = StandardScaler()
    Xs = sc.fit_transform(X)

    tscv = TimeSeriesSplit(n_splits=5)
    all_true, all_pred, all_prob = [], [], []
    for fold, (tr, val) in enumerate(tscv.split(Xs)):
        if y[tr].sum() == 0: continue
        clf = RandomForestClassifier(n_estimators=200, class_weight="balanced",
                                      max_depth=8, min_samples_leaf=5,
                                      random_state=42, n_jobs=-1)
        clf.fit(Xs[tr], y[tr])
        all_true.extend(y[val].tolist())
        all_pred.extend(clf.predict(Xs[val]).tolist())
        all_prob.extend(clf.predict_proba(Xs[val])[:,1].tolist())

    at, ap = np.array(all_true), np.array(all_pred)
    if len(at) > 0 and at.sum() > 0:
        logger.info(classification_report(at, ap,
            target_names=["Normal","Manipulation"], digits=3, zero_division=0))
        try: logger.info(f"  AUC-ROC: {roc_auc_score(at, all_prob):.4f}")
        except: pass

    final = RandomForestClassifier(n_estimators=300, class_weight="balanced",
                                    max_depth=8, min_samples_leaf=5,
                                    random_state=42, n_jobs=-1)
    final.fit(Xs, y)

    # Feature importance
    logger.info("\n  Top-5 features by importance:")
    pairs = sorted(zip(FEATURE_NAMES, final.feature_importances_),
                   key=lambda x: x[1], reverse=True)[:5]
    for name, imp in pairs:
        logger.info(f"    {name:<30} {'█'*int(imp*50)} {imp:.4f}")

    joblib.dump(final, MODELS_DIR / "random_forest.pkl")
    joblib.dump(sc,    MODELS_DIR / "rf_scaler.pkl")
    logger.info("  ✅ Saved: random_forest.pkl + rf_scaler.pkl")
    return final, sc


if __name__ == "__main__":
    logger.info("=" * 60)
    logger.info(f"MODEL TRAINING — {FEAT_DIM} FEATURES")
    logger.info("=" * 60)

    all_data = load_all()
    if not all_data:
        logger.error("No data. Run: python trainer/download_data.py")
        sys.exit(1)

    ds = build_dataset(all_data)
    if len(ds) < 100:
        logger.error("Insufficient data for training.")
        sys.exit(1)

    train_isolation_forest(ds)
    train_random_forest(ds)

    logger.info("\n" + "=" * 60)
    logger.info("TRAINING COMPLETE")
    logger.info("Next: python trainer/train_lstm.py")
    logger.info("Then: python trainer/evaluate.py")
    logger.info("=" * 60)


def save_shap_background(ds: pd.DataFrame):
    """Save normal data samples as SHAP background dataset."""
    try:
        import shap as _shap
        from sklearn.preprocessing import StandardScaler
        normal = ds[ds["label"] == 0][FEATURE_NAMES].values
        sc     = StandardScaler()
        Xn     = sc.fit_transform(normal)
        # Save 500 random samples as background
        rng  = np.random.RandomState(42)
        idx  = rng.choice(len(Xn), min(500, len(Xn)), replace=False)
        joblib.dump(Xn[idx], MODELS_DIR / "shap_background.pkl")
        logger.info(f"  ✅ SHAP background saved ({len(idx)} samples)")
    except Exception as e:
        logger.warning(f"  SHAP background skipped: {e}")
