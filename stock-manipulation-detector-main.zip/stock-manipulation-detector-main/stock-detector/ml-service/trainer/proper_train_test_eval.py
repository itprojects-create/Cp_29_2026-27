#!/usr/bin/env python3
# ml-service/trainer/proper_train_test_eval.py
#
# Fixes the in-sample evaluation gap: refits Isolation Forest + Random Forest
# on ONLY the earliest 80% of chronological data, evaluates on the strictly
# later 20% the models have never seen — including whichever confirmed SEBI
# events fall after the cutoff. This is genuine walk-forward, out-of-sample
# evaluation, not the model re-grading its own training set.
#
# Also reports imbalance-appropriate metrics (Davis & Goadrich 2006;
# Saito & Rehmsmeier 2015; Chicco & Jurman 2020) alongside ROC-AUC.
#
# Run: python trainer/proper_train_test_eval.py

import sys, json
import numpy as np
import pandas as pd
from pathlib import Path
from loguru import logger
from sklearn.ensemble import IsolationForest, RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (roc_auc_score, average_precision_score,
                              matthews_corrcoef, balanced_accuracy_score,
                              fbeta_score, precision_score, recall_score,
                              f1_score, confusion_matrix)

sys.path.insert(0, str(Path(__file__).parent.parent))
from detector.features   import extract_features, FEATURE_NAMES, WINDOW
from trainer.download_data import load_all
from trainer.label_events  import label_dataframe, MANIPULATION_EVENTS

REPORTS_DIR = Path(__file__).parent.parent / "reports"
REPORTS_DIR.mkdir(exist_ok=True)

TRAIN_FRACTION = 0.80   # earliest 80% by date = train, latest 20% = test


def build_dataset_with_dates():
    """Build feature rows tagged with their actual date, for chronological split."""
    logger.info("Building dataset with date tags for chronological split...")
    all_data = load_all()
    if not all_data:
        logger.error("No data. Run: python trainer/download_data.py first")
        sys.exit(1)

    rows = []
    for symbol, raw_df in all_data.items():
        if raw_df is None or len(raw_df) < WINDOW + 10:
            continue
        df = label_dataframe(raw_df, symbol).sort_index()
        for i in range(WINDOW + 1, len(df)):
            hist = [
                {"price": float(df.iloc[j]["close"]), "volume": int(df.iloc[j]["volume"]),
                 "high": float(df.iloc[j].get("high", df.iloc[j]["close"])),
                 "low":  float(df.iloc[j].get("low",  df.iloc[j]["close"]))}
                for j in range(max(0, i - WINDOW - 1), i)
            ]
            row = df.iloc[i]
            feats = extract_features(
                float(row["close"]), int(row["volume"]),
                float(row.get("high", row["close"])),
                float(row.get("low",  row["close"])), hist,
            )
            if feats is None:
                continue
            d = {n: float(feats.flatten()[k]) for k, n in enumerate(FEATURE_NAMES)}
            d.update({"symbol": symbol, "date": row.name, "label": int(row["label"])})
            rows.append(d)

    ds = pd.DataFrame(rows).dropna(subset=FEATURE_NAMES).sort_values("date")
    logger.info(f"Total dataset: {len(ds)} rows spanning "
                f"{ds['date'].min().date()} to {ds['date'].max().date()}")
    return ds


def chronological_split(ds: pd.DataFrame):
    """Split by DATE, not randomly — train = earliest 80%, test = latest 20%."""
    cutoff_idx = int(len(ds) * TRAIN_FRACTION)
    cutoff_date = ds.iloc[cutoff_idx]["date"]

    train = ds[ds["date"] < cutoff_date]
    test  = ds[ds["date"] >= cutoff_date]

    train_events = sorted(set(
        e["symbol"] + " " + e["type"] for e in MANIPULATION_EVENTS
        if pd.Timestamp(e["start"]) < cutoff_date
    ))
    test_events = sorted(set(
        e["symbol"] + " " + e["type"] for e in MANIPULATION_EVENTS
        if pd.Timestamp(e["start"]) >= cutoff_date
    ))

    logger.info(f"\nCutoff date: {cutoff_date.date()}")
    logger.info(f"TRAIN set: {len(train)} rows ({train['date'].min().date()} to {train['date'].max().date()})")
    logger.info(f"  Normal: {sum(train['label']==0)}  Manipulation: {sum(train['label']==1)}")
    logger.info(f"  Events in TRAIN period: {train_events if train_events else 'none'}")
    logger.info(f"\nTEST set:  {len(test)} rows ({test['date'].min().date()} to {test['date'].max().date()})")
    logger.info(f"  Normal: {sum(test['label']==0)}  Manipulation: {sum(test['label']==1)}")
    logger.info(f"  Events in TEST period (genuinely held-out): {test_events if test_events else 'none'}")

    return train, test, cutoff_date


def train_and_evaluate(train: pd.DataFrame, test: pd.DataFrame):
    X_train, y_train = train[FEATURE_NAMES].values, train["label"].values
    X_test,  y_test  = test[FEATURE_NAMES].values,  test["label"].values

    # ── Isolation Forest — trained ONLY on train-normal rows ──────────
    logger.info("\nRefitting Isolation Forest on TRAIN period only (normal rows)...")
    if_scaler = StandardScaler()
    X_train_normal = X_train[y_train == 0]
    Xn_scaled = if_scaler.fit_transform(X_train_normal)
    if_model = IsolationForest(n_estimators=200, contamination=0.05, random_state=42, n_jobs=-1)
    if_model.fit(Xn_scaled)

    X_test_scaled = if_scaler.transform(X_test)
    raw = if_model.score_samples(X_test_scaled)
    if_scores_test = 1 - (raw - raw.min()) / (raw.max() - raw.min() + 1e-9)

    # ── Random Forest — trained ONLY on train period ───────────────────
    logger.info("Refitting Random Forest on TRAIN period only...")
    rf_scaler = StandardScaler()
    Xt_scaled = rf_scaler.fit_transform(X_train)
    rf_model = RandomForestClassifier(n_estimators=300, class_weight="balanced",
                                       max_depth=8, min_samples_leaf=5,
                                       random_state=42, n_jobs=-1)
    rf_model.fit(Xt_scaled, y_train)

    Xte_scaled = rf_scaler.transform(X_test)
    rf_scores_test = rf_model.predict_proba(Xte_scaled)[:, 1]

    return if_scores_test, rf_scores_test, y_test


def compute_all_metrics(y_true, y_scores, threshold=0.55, name="Model"):
    pred = (y_scores >= threshold).astype(int)

    roc_auc = float(roc_auc_score(y_true, y_scores)) if len(set(y_true)) > 1 else 0.0
    pr_auc  = float(average_precision_score(y_true, y_scores)) if len(set(y_true)) > 1 else 0.0
    mcc     = float(matthews_corrcoef(y_true, pred))
    bal_acc = float(balanced_accuracy_score(y_true, pred))
    f1      = float(f1_score(y_true, pred, zero_division=0))
    f2      = float(fbeta_score(y_true, pred, beta=2, zero_division=0))
    prec    = float(precision_score(y_true, pred, zero_division=0))
    rec     = float(recall_score(y_true, pred, zero_division=0))
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()

    logger.info(f"\n--- {name} (genuinely held-out test set) ---")
    logger.info(f"  ROC-AUC:            {roc_auc:.4f}")
    logger.info(f"  PR-AUC (Avg Prec):  {pr_auc:.4f}   ← more informative under 99%/1% imbalance")
    logger.info(f"  MCC:                {mcc:.4f}")
    logger.info(f"  Balanced Accuracy:  {bal_acc:.4f}")
    logger.info(f"  Precision:          {prec:.4f}")
    logger.info(f"  Recall:             {rec:.4f}")
    logger.info(f"  F1:                 {f1:.4f}")
    logger.info(f"  F2 (recall-weighted): {f2:.4f}")
    logger.info(f"  Confusion: TP={tp} FP={fp} FN={fn} TN={tn}")

    return {
        "roc_auc": round(roc_auc, 4), "pr_auc": round(pr_auc, 4),
        "mcc": round(mcc, 4), "balanced_accuracy": round(bal_acc, 4),
        "precision": round(prec, 4), "recall": round(rec, 4),
        "f1": round(f1, 4), "f2": round(f2, 4),
        "tp": int(tp), "fp": int(fp), "fn": int(fn), "tn": int(tn),
    }


if __name__ == "__main__":
    logger.info("=" * 78)
    logger.info("PROPER CHRONOLOGICAL TRAIN/TEST SPLIT — genuine held-out evaluation")
    logger.info("=" * 78)

    ds = build_dataset_with_dates()
    train, test, cutoff = chronological_split(ds)

    if sum(test["label"] == 1) == 0:
        logger.warning(
            "\n⚠️  No manipulation events fall in the TEST period with an 80/20 split. "
            "Consider lowering TRAIN_FRACTION so at least 1-2 confirmed events land "
            "in the held-out test set — otherwise Recall/F1 on manipulation cases "
            "cannot be computed out-of-sample."
        )

    if_scores, rf_scores, y_test = train_and_evaluate(train, test)

    results = {
        "cutoff_date": str(cutoff.date()),
        "train_rows": len(train), "test_rows": len(test),
        "isolation_forest": compute_all_metrics(y_test, if_scores, name="Isolation Forest"),
        "random_forest": compute_all_metrics(y_test, rf_scores, name="Random Forest"),
    }

    out_path = REPORTS_DIR / "proper_train_test_eval.json"
    with open(out_path, "w") as f:
        json.dump(results, f, indent=2)
    logger.info(f"\nSaved: {out_path}")
    logger.info("These numbers are genuinely out-of-sample — use these, not the")
    logger.info("all-data-refit numbers, as your headline reported metrics.")