# ml-service/social/scanner.py
# Standalone social media scanner.
# Used by LangChain tools.py — same logic, extracted for reuse.

import os
import requests
from loguru import logger


def scan_stocktwits(symbol: str) -> dict:
    """
    Scan StockTwits for a symbol. 100% free, no key needed.
    Returns: { post_count, bullish_pct, pump_posts, watchlist_count, score }
    """
    try:
        url = f"https://api.stocktwits.com/api/2/streams/symbol/{symbol}.json"
        r = requests.get(url, timeout=8)
        if r.status_code != 200:
            return {"error": f"HTTP {r.status_code}", "score": 0}

        data = r.json()
        messages = data.get("messages", [])
        sym_info = data.get("symbol", {})

        total = len(messages)
        if total == 0:
            return {"post_count": 0, "score": 0}

        bullish = sum(1 for m in messages
                      if m.get("entities", {}).get("sentiment", {}).get("basic") == "Bullish")
        pump_kw = ["moon","rocket","squeeze","buy now","load","100x","yolo","calls"]
        pump = sum(1 for m in messages
                   if any(k in m.get("body","").lower() for k in pump_kw))

        bullish_pct = bullish / total * 100
        score = 0
        if bullish_pct > 80 and total > 20: score += 35
        elif bullish_pct > 65: score += 15
        if pump > 5: score += min(25, pump * 3)
        if total > 50: score += 15
        watchlist = sym_info.get("watchlist_count", 0)
        if watchlist > 10000: score += 10

        return {
            "post_count": total,
            "bullish_pct": round(bullish_pct, 1),
            "pump_posts": pump,
            "watchlist_count": watchlist,
            "score": min(100, score),
        }
    except Exception as e:
        return {"error": str(e), "score": 0}


def scan_twitter(symbol: str) -> dict:
    """
    Scan Twitter/X via twitterapi.io.
    Pay-as-you-go: ~₹0.01 per search. Free credits on signup.
    Returns: { tweet_count, pump_tweets, author_diversity, score }
    """
    key = os.getenv("TWITTERAPI_IO_KEY", "")
    if not key:
        return {"error": "TWITTERAPI_IO_KEY not set", "score": 0}

    try:
        url = "https://api.twitterapi.io/twitter/tweet/advanced_search"
        params = {
            "query": f"${symbol} OR #{symbol}NSE lang:en -is:retweet",
            "queryType": "Latest",
            "count": "50",
        }
        headers = {"X-API-Key": key}
        r = requests.get(url, params=params, headers=headers, timeout=10)

        if r.status_code == 429:
            return {"error": "rate_limited", "score": 0}
        if r.status_code != 200:
            return {"error": f"HTTP {r.status_code}", "score": 0}

        tweets = r.json().get("tweets", [])
        total = len(tweets)
        if total == 0:
            return {"tweet_count": 0, "score": 0}

        authors = set(t.get("author", {}).get("userName", "") for t in tweets)
        diversity = len(authors) / total

        pump_kw = ["moon","rocket","squeeze","pump","buy","load","target","calls","yolo"]
        pump_tweets = sum(1 for t in tweets
                          if any(k in t.get("text","").lower() for k in pump_kw))

        score = 0
        if diversity < 0.3: score += 30   # Low diversity = bots
        if pump_tweets > 10: score += min(30, pump_tweets * 2)
        if total > 100: score += 15

        return {
            "tweet_count": total,
            "pump_tweets": pump_tweets,
            "author_diversity": round(diversity, 2),
            "score": min(100, score),
        }
    except Exception as e:
        return {"error": str(e), "score": 0}


def composite_social_score(symbol: str) -> dict:
    """Run all social scanners and return weighted composite score."""
    st = scan_stocktwits(symbol)
    tw = scan_twitter(symbol)

    # Weights: StockTwits 60%, Twitter 40%
    # (Reddit is handled directly in langchain tools)
    st_score = st.get("score", 0)
    tw_score = tw.get("score", 0)

    composite = st_score * 0.6 + tw_score * 0.4

    return {
        "composite_score": round(composite, 1),
        "stocktwits": st,
        "twitter": tw,
    }
