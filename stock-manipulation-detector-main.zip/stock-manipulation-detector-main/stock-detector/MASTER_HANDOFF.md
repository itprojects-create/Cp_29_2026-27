# STOCK MANIPULATION DETECTOR — MASTER HANDOFF v5

# Give this file to any AI (ChatGPT / Claude) to continue the project.

# Say: "Read this file and continue from SESSION STATUS below."

---

## WHAT THIS IS

Real-time NSE India stock manipulation detection system.
6-layer ML pipeline + LangChain AI investigation + React dashboard.

## CORE FLOW

Angel One SmartAPI WebSocket
→ Node.js (tick normalise)
→ Redis Pub/Sub
→ Python FastAPI (6-layer ML)
→ if anomaly: Redis alert:new
→ Node.js → Supabase → Socket.IO → React
→ Analyst clicks AI Analyze → LangChain (6 tools)

---

## COMPLETE FILE STRUCTURE

```
stock-detector/
├── MASTER_HANDOFF.md          ← YOU ARE HERE
├── DEMO_GUIDE.md              ← how to run demo scenarios
├── PAPER_DRAFT.md             ← full paper abstract + outline + references
├── .env.example               ← all environment variables
├── docker-compose.yml         ← Redis only
│
├── ml-service/
│   ├── main.py                ← FastAPI v3.0 — all endpoints
│   ├── requirements.txt       ← all Python deps
│   ├── angelone_forwarder.py  ← Angel One WebSocket → Node.js
│   ├── breeze_forwarder.py    ← (legacy, use angelone_forwarder instead)
│   │
│   ├── detector/
│   │   ├── features.py           ← 20 features (Groups A-D)
│   │   ├── zscore_rules.py       ← Layer 1: rule-based (instant)
│   │   ├── isolation_forest.py   ← Layer 2: IF (unsupervised)
│   │   ├── lstm_autoencoder.py   ← Layer 3: LSTM-AE (sequential)
│   │   ├── collaborative_filter.py ← Layer 4: CF (cross-asset)
│   │   ├── ensemble.py           ← Dempster-Shafer combination
│   │   ├── shap_explainer.py     ← SHAP TreeExplainer (paper Fig 3)
│   │   ├── concept_drift.py      ← ADWIN per-symbol drift detection
│   │   ├── fno_presignal.py      ← F&O options PCR + OI signal
│   │   └── social_video_signal.py ← YouTube + Google Trends
│   │
│   ├── trainer/
│   │   ├── download_data.py      ← yfinance + NSE Bhavcopy download
│   │   ├── label_events.py       ← 10 confirmed SEBI cases
│   │   ├── train.py              ← trains IF + RF (20 features)
│   │   ├── train_lstm.py         ← trains LSTM Autoencoder
│   │   ├── backtest.py           ← validate on SEBI cases
│   │   ├── evaluate.py           ← ablation study + LaTeX Table 3
│   │   └── statistical_eval.py   ← McNemar + DeLong + CI (Table 5)
│   │
│   ├── langchain_agent/
│   │   ├── agent.py              ← LangChain agent (Groq free / Ollama)
│   │   └── tools.py              ← 6 tools: news, SEBI, social,
│   │                               patterns, F&O, YouTube/Trends
│   ├── social/
│   │   └── scanner.py            ← standalone social scanner
│   │
│   ├── replay/
│   │   ├── fetch_manipulation_cases.py ← download SEBI case data
│   │   └── data/                 ← case CSVs (generated at runtime)
│   │
│   └── demo/
│       └── demo_runner.py        ← 4 demo scenarios (pump/dump etc.)
│
├── server/                    ← Node.js backend
│   ├── index.js               ← Express + Socket.IO entry
│   ├── package.json
│   ├── services/
│   │   ├── redisClient.js     ← pub/sub, sorted sets, hash state
│   │   ├── supabaseClient.js  ← all DB operations
│   │   ├── priceIngestion.js  ← Angel One mode + simulation fallback
│   │   ├── mlBridge.js        ← HTTP to Python ML service
│   │   └── logger.js
│   ├── routes/
│   │   ├── alerts.js          ← GET /api/alerts
│   │   └── stocks.js          ← GET /api/stocks, POST /api/analyze
│   └── socket/
│       └── socketHandler.js   ← Redis → Socket.IO bridge
│
└── client/                    ← React frontend
    ├── package.json
    ├── vite.config.js
    ├── index.html
    └── src/
        ├── App.jsx
        ├── main.jsx
        ├── store/useStore.js        ← Zustand state
        ├── hooks/useSocket.js       ← Socket.IO connection
        ├── services/api.js          ← REST API calls
        ├── pages/
        │   ├── Dashboard.jsx        ← main trading dashboard
        │   └── ReplayPage.jsx       ← historical SEBI case replay
        └── components/
            ├── Topbar.jsx
            ├── Watchlist.jsx
            ├── StatsBar.jsx
            ├── PriceChart.jsx       ← Canvas chart + crosshair
            ├── AlertFeed.jsx        ← anomaly feed + AI Analyze btn
            └── AIAnalysisPanel.jsx  ← full evidence panel + SHAP
```

---

## ENVIRONMENT VARIABLES (.env)

```env
# Angel One (NSE live data — free with demat account)
ANGELONE_API_KEY=
ANGELONE_CLIENT_ID=
ANGELONE_MPIN=
ANGELONE_TOTP_SECRET=
NODE_TICK_URL=http://localhost:3001/internal/tick

# Redis
REDIS_URL=redis://localhost:6379

# Supabase (free tier)
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_KEY=

# ML Service
ML_SERVICE_URL=http://localhost:8000

# LangChain LLM — choose one:
LLM_PROVIDER=groq
GROQ_API_KEY=              # free at console.groq.com
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=llama3.2

# Social scanning
TWITTERAPI_IO_KEY=         # twitterapi.io — pay-per-use ~₹0.01/query
REDDIT_CLIENT_ID=          # reddit.com/prefs/apps (free)
REDDIT_CLIENT_SECRET=

# YouTube (free, 10k units/day)
YOUTUBE_API_KEY=           # console.cloud.google.com → YouTube Data API v3

# Node
PORT=3001
NODE_ENV=development
CLIENT_URL=http://localhost:5173
```

---

## SUPABASE SCHEMA (run in Supabase SQL editor)

```sql
CREATE TABLE alerts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  symbol TEXT NOT NULL,
  alert_type TEXT NOT NULL,
  severity FLOAT NOT NULL,
  level TEXT NOT NULL,
  price_at_alert FLOAT,
  volume_at_alert BIGINT,
  if_score FLOAT, rf_score FLOAT, lstm_score FLOAT,
  ensemble_score FLOAT,
  raw_features JSONB,
  social_score FLOAT,
  social_evidence JSONB,
  langchain_analysis TEXT,
  shap_drivers JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE price_ticks (
  id BIGSERIAL PRIMARY KEY,
  symbol TEXT NOT NULL,
  price FLOAT NOT NULL,
  volume BIGINT NOT NULL,
  high FLOAT, low FLOAT,
  timestamp TIMESTAMPTZ NOT NULL
);
CREATE TABLE watchlist (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  symbol TEXT UNIQUE NOT NULL,
  company_name TEXT,
  added_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_alerts_symbol ON alerts(symbol);
CREATE INDEX idx_alerts_created ON alerts(created_at DESC);
CREATE INDEX idx_ticks_symbol_time ON price_ticks(symbol, timestamp DESC);
```

---

## REDIS KEY DESIGN

```
tick:SYMBOL     → Pub/Sub — every normalised tick
alert:new       → Pub/Sub — every ML anomaly alert
prices:SYMBOL   → Sorted Set (last 100 ticks, scored by timestamp ms)
state:SYMBOL    → Hash: { price, volume, high, low, last_updated }
```

---

## 20 FEATURES (FEAT_DIM=20, do NOT change names)

Group A — Price momentum:
returns_1d, returns_3d, returns_5d, returns_10d,
price_zscore, price_acceleration, intraday_range_pct

Group B — Volume:
volume_zscore, volume_ratio, volume_acceleration

Group C — Cross (most important):
price_vol_interaction, ← KEY: price_z × vol_z
vol_confirmed_momentum, drawdown_from_recent_high, return_consistency

Group D — Microstructure (NEW, paper contribution):
amihud_illiquidity, ← Amihud (2002)
price_efficiency_ratio, ← Kaufman (1995)
vol_concentration, high_low_ratio,
close_to_high_ratio, momentum_reversal

---

## DETECTION THRESHOLDS

ensemble_score > 0.85 → CRITICAL
ensemble_score > 0.70 → HIGH
ensemble_score > 0.55 → MEDIUM ← alert fires
ensemble_score > 0.40 → LOW

DS Weights: rule=0.15 if=0.30 rf=0.25 lstm=0.20 cf=0.10

---

## WATCHLIST (15 NSE stocks)

RELIANCE, HDFCBANK, INFY, TCS, ICICIBANK,
KOTAKBANK, SBIN, AXISBANK, BAJFINANCE, WIPRO,
ZOMATO, NYKAA, PAYTM, ADANIENT, YESBANK

---

## 10 SEBI MANIPULATION CASES (for training labels)

1. YESBANK 2020-03-05 → 2020-03-09 COORDINATED_DUMP ₹10.85cr penalty
2. ADANIENT 2023-01-24 → 2023-02-08 SHORT_ATTACK SCN issued
3. ZOMATO 2021-07-23 → 2021-07-27 IPO_PUMP Surveillance circular
4. PAYTM 2021-11-18 → 2021-11-22 IPO_DUMP Worst NSE listing
5. NYKAA 2022-11-10 → 2022-11-15 BONUS_DUMP New disclosure norms
6. YESBANK 2019-09-20 → 2019-09-27 COORDINATED_DUMP ₹10.85cr (same order)
7. SBIN 2020-03-12 → 2020-03-19 COORDINATED_DUMP 14 entities
8. ADANIENT 2022-04-05 → 2022-04-12 COORDINATED_PUMP ASM listing
9. YESBANK 2018-09-21 → 2018-09-28 COORDINATED_DUMP ₹25cr penalty
10. BAJFINANCE 2020-03-23 → 2020-03-27 INTRADAY_PUMP NSE surveillance

---

## COMPLETE RUN ORDER

```bash
# ONE-TIME SETUP
docker-compose up -d                              # Redis
cd server && npm install
cd client && npm install
cd ml-service && .\.venv\Scripts\python.exe -m pip install -r requirements.txt

# ONE-TIME DATA + TRAINING
python trainer/download_data.py                  # ~10 min, NSE historical data
python trainer/train.py                          # ~3 min, IF + RF + SHAP background
python trainer/train_lstm.py                     # ~5 min, LSTM Autoencoder
python trainer/evaluate.py                       # paper Table 3 + LaTeX
python trainer/statistical_eval.py               # paper Table 5 + significance

# DOWNLOAD SEBI CASE DATA (for Replay page)
python replay/fetch_manipulation_cases.py

# DAILY RUN (start all 4)
.\.venv\Scripts\python.exe -m uvicorn main:app --port 8000 --reload # ML service
cd server && npm run dev                         # Node backend
cd client && npm run dev                         # React frontend
python angelone_forwarder.py                     # live data (market hours only)

# DEMO (for presentation)
python demo/demo_runner.py --scenario pump_dump --analyze
python demo/demo_runner.py --scenario all        # all 4 scenarios
```

---

## API ENDPOINTS (FastAPI v3.0 at localhost:8000)

POST /ingest ← tick scoring (Node.js calls this per-tick)
POST /analyze ← LangChain 6-tool investigation + SHAP + YouTube
GET /shap/global ← global feature importance (paper Table 4)
POST /shap/explain ← explain custom feature vector
GET /replay/cases ← list 7 SEBI cases
GET /replay/cases/{id} ← fetch case data
POST /replay/score/{id} ← run 4-layer model on historical case
GET /drift ← ADWIN drift status all symbols
GET /correlations ← cross-asset correlation matrix
POST /retrain/{symbol} ← trigger IF retraining
GET /health ← all layer statuses

---

## SESSION STATUS (update after each session)

✅ SESSION 1: Server (Node.js) — complete
✅ SESSION 2: ML service (IF + RF) — complete
✅ SESSION 3: LangChain (Groq/Ollama) + twitterapi.io — complete
✅ SESSION 4: LSTM-AE + Collaborative Filter + DS ensemble — complete
✅ SESSION 5: SHAP + ADWIN + YouTube/Trends + F&O signal — complete
✅ SESSION 6: Sadhna case + 6 LangChain tools + paper draft — complete

❌ NOT STARTED: Nothing critical remaining
⚠️ NEEDS TESTING: Full pipeline test with real Angel One credentials
⚠️ NEEDS RUNNING: trainer/download_data.py → train.py → train_lstm.py

---

## DO NOT CHANGE THESE (other AIs must respect)

- FEAT_DIM = 20
- FEATURE_NAMES order in features.py
- Redis key names (tick:SYMBOL, alert:new, prices:SYMBOL, state:SYMBOL)
- Supabase column names
- Detection thresholds (0.85/0.70/0.55/0.40)
- PORT 3001 (Node.js), PORT 8000 (FastAPI)
