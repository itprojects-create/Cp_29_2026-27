# STOCK MANIPULATION DETECTOR — DEMO GUIDE

## Quick Start (5 minutes)

### Step 1: Start all services (4 terminals)

```bash
# Terminal 1 — Redis
docker-compose up -d

# Terminal 2 — ML service
cd ml-service
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m uvicorn main:app --port 8000 --reload

# Terminal 3 — Node backend
cd server && npm install && npm run dev

# Terminal 4 — React frontend
cd client && npm install && npm run dev
# Open http://localhost:5173
```

### Step 2: (Optional) Train models

```bash
cd ml-service
python trainer/download_data.py    # ~10 min, downloads 5yr NSE data
python trainer/train.py            # ~3 min, trains IF + RF
python trainer/train_lstm.py       # ~5 min, trains LSTM-AE
python trainer/evaluate.py         # prints paper metrics + LaTeX table
```

### Step 3: Run a demo scenario

```bash
# In a new terminal
cd ml-service
python demo/demo_runner.py --scenario pump_dump --analyze
```

Watch the dashboard — alerts appear in real time as the pump unfolds.

---

## Demo Scenarios

| Command                      | What it shows                              |
| ---------------------------- | ------------------------------------------ |
| `--scenario pump_dump`       | ZOMATO pump then dump — alerts at tick ~35 |
| `--scenario coordinated_buy` | YESBANK sustained buying + CF co-movement  |
| `--scenario short_attack`    | ADANIENT coordinated selling               |
| `--scenario normal`          | RELIANCE quiet day — should NOT alert      |
| `--scenario all`             | All scenarios in sequence                  |

Add `--analyze` to auto-trigger LangChain AI investigation on first alert.

---

## How to show "reasons it was flagged"

1. System fires alert → appears in right panel on dashboard
2. Click **AI ANALYZE** button on the alert
3. Panel expands showing:
   - ML scores per layer (IF / RF / LSTM-AE / Z-score / CF)
   - News scan result (did yfinance + gnews find a legitimate catalyst?)
   - SEBI status (is it on ASM list? delivery %?)
   - Social media scan (StockTwits + Reddit pump signal score)
   - Historical pattern match (which SEBI case it resembles)
   - Final verdict with probability and recommended action

---

## Social Media — what works without API keys

| Source        | Needs key?     | What you get                                                    |
| ------------- | -------------- | --------------------------------------------------------------- |
| StockTwits    | ❌ No          | Bullish/bearish counts, pump-language posts, watchlist count    |
| Reddit        | ❌ No          | Posts from IndiaInvestments, DalalStreetTalks, IndianStreetBets |
| Twitter/X     | ✅ Yes (cheap) | twitterapi.io — free credits on signup, ~₹0.01/query            |
| yfinance news | ❌ No          | Recent news articles for NSE stocks                             |
| gnews         | ❌ No          | Google News articles in English + Hindi                         |

Reddit works without OAuth — the public search endpoint accepts just a User-Agent.

---

## Why this is better than existing systems

| Feature           | SEBI ASM   | NSE Stock Watch | Our System           |
| ----------------- | ---------- | --------------- | -------------------- |
| Detection latency | Days-weeks | Hours           | **<600ms**           |
| Social media      | ❌         | ❌              | ✅                   |
| Explainability    | ❌         | ❌              | ✅ Full evidence     |
| Cost              | ₹1cr+/yr   | ₹1cr+/yr        | **₹0**               |
| Indian stocks     | ✅         | ✅              | ✅                   |
| ML models         | Rule-based | Rule-based      | **4-layer ensemble** |
| Cross-asset       | ❌         | ❌              | ✅ CF layer          |

---

## Paper evaluation metrics

After training, run:

```bash
python trainer/evaluate.py
```

Output:

- Precision, Recall, F1, AUC-ROC per model per SEBI case
- Ablation study: Rules → IF → RF → LSTM-AE → Full ensemble
- Detection lag: how many days before the peak did first alert fire
- LaTeX table ready to paste into paper
